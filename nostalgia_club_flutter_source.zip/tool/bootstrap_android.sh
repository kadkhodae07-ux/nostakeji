#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK is required." >&2
  exit 1
fi

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PACKAGE_ORG="${PACKAGE_ORG:-com.example}"
PROJECT_NAME="${PROJECT_NAME:-nostalgia_club}"
APP_LABEL="${APP_LABEL:-باشگاه نوستالژی}"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

flutter create \
  --platforms=android \
  --org "$PACKAGE_ORG" \
  --project-name "$PROJECT_NAME" \
  "$TMP_DIR/scaffold"

rm -rf "$PROJECT_ROOT/android"
cp -R "$TMP_DIR/scaffold/android" "$PROJECT_ROOT/android"
cp "$TMP_DIR/scaffold/.metadata" "$PROJECT_ROOT/.metadata"

MANIFEST="$PROJECT_ROOT/android/app/src/main/AndroidManifest.xml"
python3 - "$MANIFEST" "$APP_LABEL" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
label = sys.argv[2]
text = path.read_text(encoding='utf-8')
text = text.replace('android:label="nostalgia_club"', f'android:label="{label}"')
path.write_text(text, encoding='utf-8')
PY

for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  source_icon="$PROJECT_ROOT/assets/launcher/ic_launcher_${density}.png"
  target_dir="$PROJECT_ROOT/android/app/src/main/res/mipmap-${density}"
  mkdir -p "$target_dir"
  cp "$source_icon" "$target_dir/ic_launcher.png"
done

printf '%s\n' \
  "Android scaffold generated successfully." \
  "Application ID: ${PACKAGE_ORG}.${PROJECT_NAME}" \
  "Application label: ${APP_LABEL}"
