#!/usr/bin/env python3
from __future__ import annotations
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

required = [
    'pubspec.yaml', 'lib/main.dart', 'lib/app.dart',
    'lib/features/chess/domain/chess_engine.dart',
    'lib/features/nine_mens_morris/domain/nine_mens_morris_engine.dart',
    'lib/features/tic_tac_toe/domain/tic_tac_toe_engine.dart',
    'lib/features/game_2048/domain/game_2048_engine.dart',
    'lib/features/snakes_and_ladders/domain/snakes_ladders_engine.dart',
    'lib/features/ludo/domain/ludo_engine.dart',
    '.github/workflows/build-android.yml',
]
for item in required:
    if not (ROOT / item).exists():
        errors.append(f'Missing required file: {item}')

for path in list((ROOT / 'lib').rglob('*.dart')) + list((ROOT / 'test').rglob('*.dart')):
    text = path.read_text(encoding='utf-8')
    if 'Icons.' in text:
        errors.append(f'Forbidden Material/Cupertino icon usage: {path.relative_to(ROOT)}')
    if re.search(r'\b(TODO|FIXME|PLACEHOLDER)\b', text):
        errors.append(f'Unresolved marker: {path.relative_to(ROOT)}')
    balance = 0
    for char in re.sub(r"'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\"", '', text):
        if char == '{': balance += 1
        elif char == '}': balance -= 1
        if balance < 0:
            errors.append(f'Brace closes early: {path.relative_to(ROOT)}')
            break
    if balance != 0:
        errors.append(f'Brace imbalance ({balance}): {path.relative_to(ROOT)}')

asset_refs: set[str] = set()
for path in (ROOT / 'lib').rglob('*.dart'):
    text = path.read_text(encoding='utf-8')
    asset_refs.update(re.findall(r"AppIcon\('([^']+)'", text))
for name in sorted(asset_refs):
    if '$' in name:
        continue
    if not (ROOT / 'assets' / 'icons' / f'{name}.svg').exists():
        errors.append(f'Missing SVG asset for AppIcon: {name}')

if len(list((ROOT / 'assets/icons').glob('*.svg'))) < 40:
    errors.append('Icon set is unexpectedly incomplete.')
if len(list((ROOT / 'test').glob('*_test.dart'))) < 7:
    errors.append('Core test suite is incomplete.')

if errors:
    print('\n'.join(f'ERROR: {e}' for e in errors))
    sys.exit(1)
print('Quality checks passed.')
print(f'Dart files: {len(list((ROOT / "lib").rglob("*.dart")))}')
print(f'Test files: {len(list((ROOT / "test").rglob("*_test.dart")))}')
print(f'SVG icons: {len(list((ROOT / "assets/icons").glob("*.svg")))}')
