# باشگاه نوستالژی — Nostalgia Club

مجموعه آفلاین بازی‌های کلاسیک با Flutter، معماری Feature-first Clean Architecture، موتور قوانین مستقل و رابط کاربری RTL.

## بازی‌های نسخه 0.1.3+4

- شطرنج با حرکت قانونی، کیش/مات، پات، قلعه، آن‌پاسان، ارتقا، FEN، PGN و قوانین مساوی
- دوز ۹ مهره‌ای با مراحل چیدن، حرکت، پرواز و حذف قانونی
- XOX با مسابقه چندراندی و Minimax شکست‌ناپذیر
- 2048 با Undo، Random Seed و ادغام استاندارد
- مار و پله ۱۰۰ خانه‌ای با مسیر رفت‌وبرگشتی و رتبه‌بندی ۲ تا ۴
- منچ با مسیر داده‌محور، خانه امن، Capture، Stack، Home Lane و رتبه‌بندی

## وضعیت آنلاین

دوستان، چت، اعلان‌ها، رتبه‌بندی و پروفایل آنلاین با Mock Repository پیاده‌سازی شده‌اند. `RemoteMatchRepository` و قراردادهای API/Socket وجود دارند، اما هیچ Base URL یا اتصال شبکه واقعی در این نسخه فعال نیست.

## اجرای پروژه

این بسته در محیطی تولید شده که Flutter SDK نداشت؛ برای جلوگیری از درج Android template ناسازگار، Android scaffold با Flutter نصب‌شده روی سیستم شما تولید می‌شود:

```bash
./tool/bootstrap_android.sh
flutter pub get
dart run build_runner build --delete-conflicting-outputs
flutter run
```

روی Windows، معادل دستور Bootstrap را اجرا کنید:

```powershell
flutter create --platforms=android --org com.example --project-name nostalgia_club .
flutter pub get
dart run build_runner build --delete-conflicting-outputs
flutter run
```

## تست و کنترل کیفیت

```bash
python3 tool/quality_check.py
dart format lib test
flutter analyze --fatal-warnings
flutter test --coverage
```

Golden Test به‌صورت opt-in تعریف شده است. پس از تولید Baseline تأییدشده روی Flutter Stable:

```bash
flutter test --update-goldens --dart-define=RUN_GOLDENS=true test/golden
flutter test --dart-define=RUN_GOLDENS=true test/golden
```

## ساخت APK

```bash
flutter build apk --release \
  --dart-define=APP_ENV=release \
  --dart-define=MOCK_MODE=false
```

Workflow آماده در `.github/workflows/build-android.yml` تمام مراحل Bootstrap، Code Generation، Format، Analyze، Test و Build را اجرا می‌کند.

## تغییر نام و Package Name

1. مقادیر `AppConfig` در `lib/core/config/app_config.dart` را تغییر دهید.
2. در `tool/bootstrap_android.sh` مقدار `--org` و `--project-name` را تغییر دهید.
3. Android scaffold را دوباره بسازید.
4. لوگو و آیکن‌ها در `assets/icons/` قرار دارند و از SVG استفاده می‌کنند.
5. نسخه برنامه در `pubspec.yaml` و `AppConfig.version` همگام شود.

## ساختار

```text
lib/
  core/                 # Design System، Game Core، Storage، Networking، Audio
  features/             # هر قابلیت و هر بازی به‌صورت مستقل
  shared/               # Widget، Icon، Mock Model و Repository مشترک
assets/
  icons/                # SVGهای اختصاصی
  audio/                # افکت‌های WAV اختصاصی
...docs/                 # معماری، قوانین، Design System و قراردادها
```

## نکات امنیتی

- هیچ Secret، کلید امضا، Base URL آزمایشی یا Token در سورس وجود ندارد.
- نسخه آنلاین آینده باید Server Authoritative باشد.
- State Hash و Snapshot برای تشخیص اختلاف وضعیت در قرارداد مسابقه در نظر گرفته شده‌اند.
