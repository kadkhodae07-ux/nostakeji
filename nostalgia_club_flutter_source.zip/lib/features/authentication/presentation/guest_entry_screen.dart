import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/storage/local_profile_repository.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_background.dart';
import 'package:nostalgia_club/shared/widgets/app_button.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';
import 'package:nostalgia_club/shared/widgets/mock_badge.dart';

class GuestEntryScreen extends ConsumerStatefulWidget {
  const GuestEntryScreen({super.key});

  @override
  ConsumerState<GuestEntryScreen> createState() => _GuestEntryScreenState();
}

class _GuestEntryScreenState extends ConsumerState<GuestEntryScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController(text: 'بازیکن مهمان');
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    unawaited(_loadExisting());
  }

  Future<void> _loadExisting() async {
    final profile = await ref.read(localProfileRepositoryProvider).load();
    if (profile != null && mounted) {
      _name.text = profile.displayName;
      _name.selection = TextSelection.collapsed(offset: _name.text.length);
    }
  }

  Future<void> _continueAsGuest() async {
    if (!_formKey.currentState!.validate() || _submitting) {return;}
    setState(() => _submitting = true);
    try {
      await ref.read(localProfileRepositoryProvider).createOrUpdate(_name.text);
      ref.invalidate(localGuestProfileProvider);
      if (mounted) {context.go('/home');}
    } catch (error) {
      if (!mounted) {return;}
      setState(() => _submitting = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('ذخیره پروفایل انجام نشد: $error')),
      );
    }
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 480),
                child: GildedPanel(
                  padding: const EdgeInsets.all(24),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        const Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            MockBadge(),
                            AppIcon('profile', size: 34, color: AppColors.brassBright),
                          ],
                        ),
                        const SizedBox(height: 20),
                        Text('ورود مهمان', style: Theme.of(context).textTheme.headlineMedium),
                        const SizedBox(height: 8),
                        const Text(
                          'اطلاعات این نسخه فقط روی دستگاه ذخیره می‌شود.',
                          style: TextStyle(color: AppColors.muted),
                        ),
                        const SizedBox(height: 24),
                        TextFormField(
                          controller: _name,
                          enabled: !_submitting,
                          decoration: const InputDecoration(labelText: 'نام بازیکن'),
                          validator: (value) {
                            final text = value?.trim() ?? '';
                            if (text.length < 2) {return 'نام باید حداقل دو نویسه داشته باشد.';}
                            if (text.length > 24) {return 'نام نباید بیشتر از ۲۴ نویسه باشد.';}
                            return null;
                          },
                        ),
                        const SizedBox(height: 18),
                        AppButton(
                          label: _submitting ? 'در حال ذخیره پروفایل' : 'ادامه به‌عنوان مهمان',
                          icon: _submitting ? 'history' : 'play',
                          onPressed: _submitting ? null : () => unawaited(_continueAsGuest()),
                        ),
                        const SizedBox(height: 12),
                        AppButton(
                          label: 'ورود با ایمیل یا شماره',
                          icon: 'lock',
                          secondary: true,
                          onPressed: () => _showDisabled(context),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showDisabled(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('نسخه آفلاین'),
        content: const Text(
          'فرم و قرارداد احراز هویت آماده است، اما اتصال واقعی به سرور در این نسخه عمداً غیرفعال شده است.',
        ),
        actions: [
          TextButton(onPressed: () => context.pop(), child: const Text('متوجه شدم')),
        ],
      ),
    );
  }
}
