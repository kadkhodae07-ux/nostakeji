import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/features/game_catalog/domain/game_definition.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';
import 'package:nostalgia_club/shared/widgets/mock_badge.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: CustomScrollView(
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 0),
            sliver: SliverToBoxAdapter(
              child: Row(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.brass.withValues(alpha: 0.12),
                      border: Border.all(
                        color: AppColors.brass.withValues(alpha: 0.38),
                      ),
                    ),
                    alignment: Alignment.center,
                    child: const AppIcon(
                      'profile',
                      color: AppColors.brassBright,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'سلام، بازیکن مهمان',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        const SizedBox(height: 2),
                        const Row(
                          children: [
                            AppIcon(
                              'offline',
                              size: 15,
                              color: AppColors.success,
                            ),
                            SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                'حالت آفلاین فعال',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: AppColors.success,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Semantics(
                    button: true,
                    label: 'اعلان‌ها',
                    child: InkWell(
                      onTap: () => context.push('/notifications'),
                      borderRadius: BorderRadius.circular(22),
                      child: Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppColors.raised,
                          border: Border.all(
                            color: AppColors.brass.withValues(alpha: 0.24),
                          ),
                        ),
                        alignment: Alignment.center,
                        child: const AppIcon('notification', size: 20),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 22, 18, 0),
            sliver: SliverToBoxAdapter(
              child: _HeroFeature(
                onTap: () => context.push('/game-detail/chess'),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 22, 18, 0),
            sliver: SliverToBoxAdapter(
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'بازی‌های باشگاه',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                  ),
                  const SizedBox(width: 8),
                  TextButton(
                    onPressed: () => context.go('/games'),
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 8,
                      ),
                      minimumSize: Size.zero,
                      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                    child: const Text(
                      'مشاهده همه',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 0),
            sliver: SliverGrid.builder(
              itemCount: GameCatalog.all.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                mainAxisExtent: 160,
              ),
              itemBuilder: (context, index) => _CompactGameCard(
                game: GameCatalog.all[index],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(18, 24, 18, 24),
            sliver: SliverToBoxAdapter(
              child: GildedPanel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        MockBadge(),
                        AppIcon('online', color: AppColors.info),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'باشگاه آنلاین',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'دوستان، مسابقات، رتبه‌بندی و اتاق خصوصی با داده‌های نمایشی آماده بررسی رابط کاربری هستند.',
                      style: TextStyle(color: AppColors.muted, height: 1.6),
                    ),
                    const SizedBox(height: 14),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _FeatureChip(
                          icon: 'friends',
                          label: 'دوستان',
                          onTap: () => context.push('/friends'),
                        ),
                        _FeatureChip(
                          icon: 'leaderboard',
                          label: 'رتبه‌بندی',
                          onTap: () => context.push('/leaderboard'),
                        ),
                        _FeatureChip(
                          icon: 'history',
                          label: 'تاریخچه',
                          onTap: () => context.push('/history'),
                        ),
                        _FeatureChip(
                          icon: 'settings',
                          label: 'تنظیمات',
                          onTap: () => context.push('/settings'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HeroFeature extends StatelessWidget {
  const _HeroFeature({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GildedPanel(
      onTap: onTap,
      padding: EdgeInsets.zero,
      accent: AppColors.chess,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 340;
          return Stack(
            children: [
              Positioned.fill(
                child: CustomPaint(painter: _ChessMotifPainter()),
              ),
              Padding(
                padding: EdgeInsets.all(compact ? 18 : 22),
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    minHeight: compact ? 180 : 190,
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text(
                              'پیشنهاد امشب',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: AppColors.brassBright,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'یک نبرد شطرنجی',
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: Theme.of(context).textTheme.headlineMedium,
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              'ربات متوسط • بدون ساعت',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: AppColors.muted),
                            ),
                            const SizedBox(height: 16),
                            const Row(
                              children: [
                                AppIcon(
                                  'play',
                                  size: 18,
                                  color: AppColors.brassBright,
                                ),
                                SizedBox(width: 8),
                                Flexible(
                                  child: Text(
                                    'آماده‌سازی مسابقه',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: AppColors.brassBright,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: compact ? 10 : 16),
                      AppIcon(
                        'chess',
                        size: compact ? 60 : 82,
                        color: AppColors.brassBright,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _ChessMotifPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppColors.chess.withValues(alpha: 0.08);
    const cell = 36.0;
    for (var row = 0; row < 6; row++) {
      for (var col = 0; col < 12; col++) {
        if ((row + col).isEven) {
          canvas.drawRect(
            Rect.fromLTWH(col * cell, row * cell, cell, cell),
            paint,
          );
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _CompactGameCard extends StatelessWidget {
  const _CompactGameCard({required this.game});

  final GameDefinition game;

  @override
  Widget build(BuildContext context) {
    return GildedPanel(
      onTap: () => context.push('/game-detail/${game.key}'),
      accent: game.accent,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: game.accent.withValues(alpha: 0.15),
                ),
                alignment: Alignment.center,
                child: AppIcon(game.icon, size: 25, color: game.accent),
              ),
              const AppIcon('continue', size: 18, color: AppColors.muted),
            ],
          ),
          const Spacer(),
          Text(
            game.title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 2),
          Text(
            game.subtitle,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: AppColors.muted, fontSize: 11),
          ),
        ],
      ),
    );
  }
}

class _FeatureChip extends StatelessWidget {
  const _FeatureChip({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final String icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(999),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(999),
          color: AppColors.voidBlack.withValues(alpha: 0.35),
          border: Border.all(
            color: AppColors.brass.withValues(alpha: 0.22),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            AppIcon(icon, size: 16, color: AppColors.brassBright),
            const SizedBox(width: 7),
            Text(
              label,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
