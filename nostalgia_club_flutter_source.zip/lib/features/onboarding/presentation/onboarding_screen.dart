import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/storage/local_profile_repository.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_background.dart';
import 'package:nostalgia_club/shared/widgets/app_button.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';

class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});
  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  final _controller = PageController();
  int _page = 0;
  static const _slides = [
    ('games', 'شش بازی، یک باشگاه', 'شطرنج، منچ، مار و پله، دوز ۹ مهره‌ای، XOX و ۲۰۴۸ در یک هویت بصری یکپارچه.'),
    ('offline', 'بدون اینترنت، کاملاً واقعی', 'تمام موتورهای بازی در دستگاه اجرا می‌شوند و بازی نیمه‌تمام به‌صورت محلی ذخیره می‌شود.'),
    ('friends', 'رقابت محلی', 'با دوستان روی یک گوشی بازی کنید یا سطح ربات را متناسب با مهارت خودتان انتخاب کنید.'),
    ('online', 'آماده آینده آنلاین', 'چت، دوستان، رتبه‌بندی و اتاق خصوصی اکنون نمایشی‌اند و معماری آن‌ها آماده اتصال امن به سرور است.'),
  ];

  Future<void> _finish() async {
    await ref.read(localProfileRepositoryProvider).markOnboardingSeen();
    if (mounted) context.go('/guest');
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton(
                    onPressed: () => unawaited(_finish()),
                    child: const Text('رد کردن'),
                  ),
                ),
                Expanded(
                  child: PageView.builder(
                    controller: _controller,
                    itemCount: _slides.length,
                    onPageChanged: (value) => setState(() => _page = value),
                    itemBuilder: (context, index) {
                      final slide = _slides[index];
                      return Center(
                        child: GildedPanel(
                          padding: const EdgeInsets.all(28),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 116,
                                height: 116,
                                decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.brass.withValues(alpha: 0.13)),
                                alignment: Alignment.center,
                                child: AppIcon(slide.$1, size: 56, color: AppColors.brassBright),
                              ),
                              const SizedBox(height: 30),
                              Text(slide.$2, style: Theme.of(context).textTheme.headlineMedium, textAlign: TextAlign.center),
                              const SizedBox(height: 14),
                              Text(slide.$3, style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: AppColors.muted), textAlign: TextAlign.center),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    for (var i = 0; i < _slides.length; i++)
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 220),
                        margin: const EdgeInsets.all(4),
                        width: i == _page ? 26 : 8,
                        height: 8,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(99),
                          color: i == _page ? AppColors.brassBright : AppColors.panel,
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 20),
                AppButton(
                  label: _page == _slides.length - 1 ? 'ورود به باشگاه' : 'ادامه',
                  icon: _page == _slides.length - 1 ? 'play' : 'continue',
                  onPressed: () {
                    if (_page == _slides.length - 1) {
                      unawaited(_finish());
                    } else {
                      _controller.nextPage(duration: const Duration(milliseconds: 320), curve: Curves.easeOutCubic);
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
