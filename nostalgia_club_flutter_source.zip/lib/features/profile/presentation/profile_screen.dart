import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/storage/local_profile_repository.dart';
import 'package:nostalgia_club/core/storage/match_history_repository.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';
import 'package:nostalgia_club/shared/widgets/mock_badge.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(localGuestProfileProvider);
    final history = ref.watch(matchHistoryProvider).asData?.value ?? const <LocalMatchHistoryItem>[];
    final wins = history.where((item) => item.outcome == LocalMatchOutcome.win).length;
    final draws = history.where((item) => item.outcome == LocalMatchOutcome.draw).length;
    final losses = history.where((item) => item.outcome == LocalMatchOutcome.loss).length;
    final favorite = _favoriteGame(history);
    final ratedGames = wins + losses + draws;
    final winRate = ratedGames == 0 ? 0 : (wins * 100 / ratedGames).round();
    final level = 1 + history.length ~/ 5;

    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
        children: [
          Row(
            children: [
              Expanded(
                child: Text('پروفایل محلی', style: Theme.of(context).textTheme.headlineMedium),
              ),
              const MockBadge(),
              const SizedBox(width: 8),
              _Action(icon: 'settings', onTap: () => context.push('/settings')),
            ],
          ),
          const SizedBox(height: 18),
          GildedPanel(
            child: Column(
              children: [
                Stack(
                  children: [
                    Container(
                      width: 108,
                      height: 108,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: const LinearGradient(
                          colors: [AppColors.brassBright, AppColors.chess],
                        ),
                        border: Border.all(
                          color: AppColors.parchment.withValues(alpha: 0.65),
                          width: 2,
                        ),
                      ),
                      alignment: Alignment.center,
                      child: const AppIcon('profile', size: 55, color: AppColors.voidBlack),
                    ),
                    Positioned(
                      left: 0,
                      bottom: 0,
                      child: InkWell(
                        onTap: () => _editProfile(context, ref, profile.asData?.value),
                        customBorder: const CircleBorder(),
                        child: Container(
                          width: 34,
                          height: 34,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: AppColors.raised,
                          ),
                          alignment: Alignment.center,
                          child: const AppIcon('edit', size: 16, color: AppColors.brassBright),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Text(
                  profile.asData?.value?.displayName ?? 'بازیکن مهمان',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                Text(
                  '#${profile.asData?.value?.localId ?? 'LOCAL'} • بازی محبوب: $favorite',
                  style: const TextStyle(color: AppColors.muted),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(child: _Stat(label: 'بازی', value: '${history.length}')),
                    Expanded(child: _Stat(label: 'برد', value: '$wins')),
                    Expanded(child: _Stat(label: 'باخت', value: '$losses')),
                    Expanded(child: _Stat(label: 'مساوی', value: '$draws')),
                  ],
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(child: _Stat(label: 'سطح محلی', value: '$level')),
                    Expanded(child: _Stat(label: 'درصد برد', value: '$winRate٪')),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          GildedPanel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('دستاوردها', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _Achievement(
                        icon: 'chess',
                        label: wins > 0 ? 'اولین برد' : 'اولین برد قفل است',
                        unlocked: wins > 0,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _Achievement(
                        icon: '2048',
                        label: history.any((item) => item.gameKey == '2048')
                            ? 'بازیکن ۲۰۴۸'
                            : '۲۰۴۸ قفل است',
                        unlocked: history.any((item) => item.gameKey == '2048'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _Achievement(
                        icon: 'win',
                        label: wins >= 10 ? '۱۰ برد' : '${10 - wins} برد تا نشان',
                        unlocked: wins >= 10,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _MenuRow(
            icon: 'history',
            title: 'تاریخچه مسابقات',
            onTap: () => context.push('/history'),
          ),
          const SizedBox(height: 10),
          _MenuRow(
            icon: 'leaderboard',
            title: 'رتبه‌بندی نمایشی',
            onTap: () => context.push('/leaderboard'),
          ),
          const SizedBox(height: 10),
          _MenuRow(
            icon: 'edit',
            title: 'ویرایش پروفایل محلی',
            onTap: () => _editProfile(context, ref, profile.asData?.value),
          ),
          const SizedBox(height: 10),
          _MenuRow(
            icon: 'logout',
            title: 'خروج از نشست مهمان',
            onTap: () => unawaited(_signOut(context, ref)),
          ),
        ],
      ),
    );
  }

  static String _favoriteGame(List<LocalMatchHistoryItem> history) {
    if (history.isEmpty) return 'ثبت نشده';
    final counts = <String, int>{};
    for (final item in history) {
      counts[item.gameKey] = (counts[item.gameKey] ?? 0) + 1;
    }
    final key = counts.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
    return switch (key) {
      'chess' => 'شطرنج',
      'morris' => 'دوز ۹ مهره‌ای',
      'xox' => 'XOX',
      '2048' => '۲۰۴۸',
      'snakes' => 'مار و پله',
      'ludo' => 'منچ',
      _ => key,
    };
  }

  Future<void> _editProfile(
    BuildContext context,
    WidgetRef ref,
    LocalGuestProfile? profile,
  ) async {
    final controller = TextEditingController(text: profile?.displayName ?? 'بازیکن مهمان');
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('ویرایش پروفایل محلی'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 24,
          decoration: const InputDecoration(labelText: 'نام بازیکن'),
        ),
        actions: [
          TextButton(onPressed: () => context.pop(), child: const Text('انصراف')),
          TextButton(
            onPressed: () {
              final name = controller.text.trim();
              if (name.length >= 2) context.pop(name);
            },
            child: const Text('ذخیره'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (value == null) return;
    await ref.read(localProfileRepositoryProvider).createOrUpdate(value);
    ref.invalidate(localGuestProfileProvider);
  }

  Future<void> _signOut(BuildContext context, WidgetRef ref) async {
    await ref.read(localProfileRepositoryProvider).signOut();
    if (context.mounted) context.go('/guest');
  }
}

class _Action extends StatelessWidget {
  const _Action({required this.icon, required this.onTap});
  final String icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.raised,
            border: Border.all(color: AppColors.brass.withValues(alpha: 0.24)),
          ),
          alignment: Alignment.center,
          child: AppIcon(icon, size: 20),
        ),
      );
}

class _Stat extends StatelessWidget {
  const _Stat({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Column(
        children: [
          Text(
            value,
            style: const TextStyle(
              fontSize: 19,
              fontWeight: FontWeight.w900,
              color: AppColors.brassBright,
            ),
          ),
          Text(label, style: const TextStyle(fontSize: 11, color: AppColors.muted)),
        ],
      );
}

class _Achievement extends StatelessWidget {
  const _Achievement({
    required this.icon,
    required this.label,
    required this.unlocked,
  });
  final String icon;
  final String label;
  final bool unlocked;

  @override
  Widget build(BuildContext context) => Opacity(
        opacity: unlocked ? 1 : 0.48,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 4),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: AppColors.voidBlack.withValues(alpha: 0.28),
          ),
          child: Column(
            children: [
              AppIcon(icon, size: 28, color: AppColors.brassBright),
              const SizedBox(height: 6),
              Text(
                label,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800),
              ),
            ],
          ),
        ),
      );
}

class _MenuRow extends StatelessWidget {
  const _MenuRow({required this.icon, required this.title, required this.onTap});
  final String icon;
  final String title;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => GildedPanel(
        onTap: onTap,
        child: Row(
          children: [
            AppIcon(icon, color: AppColors.brassBright),
            const SizedBox(width: 12),
            Expanded(
              child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            ),
            const AppIcon('continue', size: 18, color: AppColors.muted),
          ],
        ),
      );
}
