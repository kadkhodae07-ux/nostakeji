import 'package:flutter/material.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_background.dart';
import 'package:nostalgia_club/shared/widgets/app_top_bar.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';
import 'package:nostalgia_club/shared/widgets/mock_badge.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    const items = [
      ('invite', 'دعوت به بازی', 'آرمان شما را به شطرنج دعوت کرده است.', 'همین حالا'),
      ('friends', 'درخواست دوستی', 'هلیا درخواست دوستی فرستاد.', '۱۰ دقیقه پیش'),
      ('win', 'دستاورد تازه', 'دستاورد «اولین مات» باز شد.', 'امروز'),
      ('notification', 'اعلان سیستمی', 'ذخیره خودکار بازی‌ها فعال است.', 'دیروز'),
    ];
    return AppBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Column(children: [
          const AppTopBar(title: 'اعلان‌ها', subtitle: 'Mock Notification Repository', actions: [MockBadge()]),
          Expanded(child: ListView.separated(padding: const EdgeInsets.fromLTRB(18, 0, 18, 24), itemCount: items.length, separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (context, index) {
            final item = items[index];
            return GildedPanel(child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Container(width: 46, height: 46, decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.info.withValues(alpha: 0.13)), alignment: Alignment.center, child: AppIcon(item.$1, size: 22, color: AppColors.info)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(item.$2, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(item.$3, style: const TextStyle(color: AppColors.muted)), const SizedBox(height: 5), Text(item.$4, style: const TextStyle(color: AppColors.muted, fontSize: 10))])), if (index < 2) Container(width: 8, height: 8, decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.brass))]));
          })),
        ]),
      ),
    );
  }
}
