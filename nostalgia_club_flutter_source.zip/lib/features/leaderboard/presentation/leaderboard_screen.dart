import 'package:flutter/material.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/mock/social_mock_data.dart';
import 'package:nostalgia_club/shared/widgets/app_background.dart';
import 'package:nostalgia_club/shared/widgets/app_top_bar.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';
import 'package:nostalgia_club/shared/widgets/mock_badge.dart';

class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key});
  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen> {
  String _tab = 'کلی';
  @override
  Widget build(BuildContext context) {
    final users = [...SocialMockData.users]..sort((a, b) => b.level.compareTo(a.level));
    return AppBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Column(children: [
          const AppTopBar(title: 'رتبه‌بندی', subtitle: 'داده نمایشی قابل جایگزینی با API', actions: [MockBadge()]),
          SizedBox(height: 48, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 18), children: [for (final tab in const ['کلی', 'دوستان', 'هفتگی', 'ماهانه', 'شطرنج', 'منچ']) Padding(padding: const EdgeInsets.only(left: 8), child: ChoiceChip(label: Text(tab), selected: _tab == tab, showCheckmark: false, onSelected: (_) => setState(() => _tab = tab), selectedColor: AppColors.brass.withValues(alpha: 0.2), backgroundColor: AppColors.raised, side: BorderSide(color: _tab == tab ? AppColors.brass : AppColors.brass.withValues(alpha: 0.16))))])),
          const SizedBox(height: 12),
          Expanded(child: ListView.separated(padding: const EdgeInsets.fromLTRB(18, 0, 18, 24), itemCount: users.length + 1, separatorBuilder: (_, __) => const SizedBox(height: 9), itemBuilder: (context, index) {
            if (index == users.length) {return const _MyRank();}
            final user = users[index];
            return GildedPanel(child: Row(children: [SizedBox(width: 34, child: Text('${index + 1}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: index < 3 ? AppColors.brassBright : AppColors.muted))), Container(width: 44, height: 44, decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.info.withValues(alpha: 0.12)), alignment: Alignment.center, child: const AppIcon('profile', size: 22, color: AppColors.info)), const SizedBox(width: 11), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(user.name, style: const TextStyle(fontWeight: FontWeight.w900)), Text('${user.favoriteGame} • سطح ${user.level}', style: const TextStyle(fontSize: 11, color: AppColors.muted))])), Text('${1200 + user.level * 17}', style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.brassBright))]));
          })),
        ]),
      ),
    );
  }
}

class _MyRank extends StatelessWidget {
  const _MyRank();
  @override
  Widget build(BuildContext context) => const GildedPanel(accent: AppColors.success, child: Row(children: [SizedBox(width: 34, child: Text('۱۲', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppColors.success))), AppIcon('profile', color: AppColors.success), SizedBox(width: 12), Expanded(child: Text('بازیکن مهمان (شما)', style: TextStyle(fontWeight: FontWeight.w900))), Text('۱۱۰۴', style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.success))]));
}
