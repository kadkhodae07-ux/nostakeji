import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:nostalgia_club/core/game/game_models.dart';

enum TicMark { x, o }
enum TicStatus { playing, won, draw }

class TicMove implements GameMove {
  const TicMove(this.index);
  final int index;
}

class TicTacToeState implements SerializableGameState {
  const TicTacToeState({
    required this.board,
    required this.turn,
    required this.status,
    this.winner,
    this.winningLine,
    this.round = 1,
    this.scoreX = 0,
    this.scoreO = 0,
  });

  factory TicTacToeState.initial({TicMark starter = TicMark.x}) => TicTacToeState(
        board: List<TicMark?>.filled(9, null),
        turn: starter,
        status: TicStatus.playing,
      );

  final List<TicMark?> board;
  final TicMark turn;
  final TicStatus status;
  final TicMark? winner;
  final List<int>? winningLine;
  final int round;
  final int scoreX;
  final int scoreO;

  TicTacToeState copyWith({
    List<TicMark?>? board,
    TicMark? turn,
    TicStatus? status,
    TicMark? winner,
    bool clearWinner = false,
    List<int>? winningLine,
    bool clearWinningLine = false,
    int? round,
    int? scoreX,
    int? scoreO,
  }) =>
      TicTacToeState(
        board: board ?? this.board,
        turn: turn ?? this.turn,
        status: status ?? this.status,
        winner: clearWinner ? null : winner ?? this.winner,
        winningLine: clearWinningLine ? null : winningLine ?? this.winningLine,
        round: round ?? this.round,
        scoreX: scoreX ?? this.scoreX,
        scoreO: scoreO ?? this.scoreO,
      );

  Map<String, Object?> toJson() => {
        'board': board.map((e) => e?.name).toList(),
        'turn': turn.name,
        'status': status.name,
        'winner': winner?.name,
        'winningLine': winningLine,
        'round': round,
        'scoreX': scoreX,
        'scoreO': scoreO,
      };

  factory TicTacToeState.fromJson(Map<String, dynamic> json) => TicTacToeState(
        board: (json['board'] as List).map((e) => e == null ? null : TicMark.values.byName(e as String)).toList(),
        turn: TicMark.values.byName(json['turn'] as String),
        status: TicStatus.values.byName(json['status'] as String),
        winner: json['winner'] == null ? null : TicMark.values.byName(json['winner'] as String),
        winningLine: (json['winningLine'] as List?)?.cast<int>(),
        round: json['round'] as int? ?? 1,
        scoreX: json['scoreX'] as int? ?? 0,
        scoreO: json['scoreO'] as int? ?? 0,
      );

  @override
  String serialize() => jsonEncode(toJson());

  @override
  String stateHash() => sha256.convert(utf8.encode(serialize())).toString();
}

class TicTacToeEngine implements GameEngine<TicTacToeState, TicMove> {
  TicTacToeEngine([TicTacToeState? initial]) : _state = initial ?? TicTacToeState.initial();
  TicTacToeState _state;
  final List<TicTacToeState> _history = [];

  static const _lines = <List<int>>[
    [0, 1, 2], [3, 4, 5], [6, 7, 8],
    [0, 3, 6], [1, 4, 7], [2, 5, 8],
    [0, 4, 8], [2, 4, 6],
  ];

  @override
  TicTacToeState get state => _state;

  @override
  List<TicMove> legalMoves() => _state.status == TicStatus.playing
      ? [for (var i = 0; i < 9; i++) if (_state.board[i] == null) TicMove(i)]
      : const [];

  @override
  bool isLegal(TicMove move) => move.index >= 0 && move.index < 9 &&
      _state.status == TicStatus.playing && _state.board[move.index] == null;

  @override
  TicTacToeState apply(TicMove move) {
    if (!isLegal(move)) throw StateError('Illegal Tic-Tac-Toe move: ${move.index}');
    _history.add(_state);
    final board = List<TicMark?>.from(_state.board)..[move.index] = _state.turn;
    final line = _winningLine(board, _state.turn);
    if (line != null) {
      _state = _state.copyWith(
        board: board,
        status: TicStatus.won,
        winner: _state.turn,
        winningLine: line,
        scoreX: _state.scoreX + (_state.turn == TicMark.x ? 1 : 0),
        scoreO: _state.scoreO + (_state.turn == TicMark.o ? 1 : 0),
      );
    } else if (board.every((cell) => cell != null)) {
      _state = _state.copyWith(board: board, status: TicStatus.draw);
    } else {
      _state = _state.copyWith(board: board, turn: _state.turn == TicMark.x ? TicMark.o : TicMark.x);
    }
    return _state;
  }

  List<int>? _winningLine(List<TicMark?> board, TicMark mark) {
    for (final line in _lines) {
      if (line.every((index) => board[index] == mark)) return line;
    }
    return null;
  }

  TicTacToeState nextRound({TicMark? starter}) {
    final nextStarter = starter ?? (_state.round.isOdd ? TicMark.o : TicMark.x);
    _history.clear();
    _state = TicTacToeState(
      board: List<TicMark?>.filled(9, null),
      turn: nextStarter,
      status: TicStatus.playing,
      round: _state.round + 1,
      scoreX: _state.scoreX,
      scoreO: _state.scoreO,
    );
    return _state;
  }

  @override
  TicTacToeState undo() {
    if (_history.isEmpty) throw StateError('Nothing to undo');
    _state = _history.removeLast();
    return _state;
  }

  @override
  void restore(TicTacToeState state) {
    _history.clear();
    _state = state;
  }
}

class TicTacToeBot implements GameBot<TicTacToeState, TicMove> {
  const TicTacToeBot();

  @override
  Future<TicMove> chooseMove(TicTacToeState state, BotDifficulty difficulty) async {
    final legal = [for (var i = 0; i < 9; i++) if (state.board[i] == null) i];
    if (legal.isEmpty) throw StateError('No legal move');
    switch (difficulty) {
      case BotDifficulty.easy:
        return TicMove(legal[Random(state.stateHash().hashCode).nextInt(legal.length)]);
      case BotDifficulty.medium:
        final winning = _findImmediate(state.board, state.turn);
        if (winning != null) return TicMove(winning);
        final block = _findImmediate(state.board, state.turn == TicMark.x ? TicMark.o : TicMark.x);
        return TicMove(block ?? legal[Random(state.round + legal.length).nextInt(legal.length)]);
      case BotDifficulty.hard:
        var bestScore = -1000;
        var bestMove = legal.first;
        for (final move in legal) {
          final board = List<TicMark?>.from(state.board)..[move] = state.turn;
          final score = _minimax(board, state.turn == TicMark.x ? TicMark.o : TicMark.x, state.turn);
          if (score > bestScore) {
            bestScore = score;
            bestMove = move;
          }
        }
        return TicMove(bestMove);
    }
  }

  int? _findImmediate(List<TicMark?> board, TicMark mark) {
    for (var i = 0; i < 9; i++) {
      if (board[i] != null) continue;
      final copy = List<TicMark?>.from(board)..[i] = mark;
      if (TicTacToeEngine._lines.any((line) => line.every((index) => copy[index] == mark))) return i;
    }
    return null;
  }

  int _minimax(List<TicMark?> board, TicMark turn, TicMark maximizingMark) {
    final opponent = maximizingMark == TicMark.x ? TicMark.o : TicMark.x;
    if (TicTacToeEngine._lines.any((line) => line.every((index) => board[index] == maximizingMark))) return 10;
    if (TicTacToeEngine._lines.any((line) => line.every((index) => board[index] == opponent))) return -10;
    if (board.every((cell) => cell != null)) return 0;
    final scores = <int>[];
    for (var i = 0; i < 9; i++) {
      if (board[i] != null) continue;
      final copy = List<TicMark?>.from(board)..[i] = turn;
      scores.add(_minimax(copy, turn == TicMark.x ? TicMark.o : TicMark.x, maximizingMark));
    }
    return turn == maximizingMark
        ? scores.reduce((a, b) => a > b ? a : b)
        : scores.reduce((a, b) => a < b ? a : b);
  }
}
