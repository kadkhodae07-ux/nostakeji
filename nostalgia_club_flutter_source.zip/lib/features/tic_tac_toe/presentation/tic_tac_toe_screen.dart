import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nostalgia_club/core/audio/audio_service.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/game/game_models.dart';
import 'package:nostalgia_club/core/storage/game_autosave_mixin.dart';
import 'package:nostalgia_club/core/storage/match_history_repository.dart';
import 'package:nostalgia_club/features/game_catalog/domain/game_setup.dart';
import 'package:nostalgia_club/features/tic_tac_toe/domain/tic_tac_toe_engine.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_button.dart';
import 'package:nostalgia_club/shared/widgets/game_screen_frame.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';

class TicTacToeScreen extends ConsumerStatefulWidget {
  const TicTacToeScreen({super.key});
  @override
  ConsumerState<TicTacToeScreen> createState() => _TicTacToeScreenState();
}

class _TicTacToeScreenState extends ConsumerState<TicTacToeScreen> with GameAutosaveMixin<TicTacToeScreen> {
  late TicTacToeEngine _engine;
  final _bot = const TicTacToeBot();
  late final GameSetupConfig _setup;
  bool _botThinking = false;
  DateTime _startedAt = DateTime.now();

  @override
  void initState() {
    super.initState();
    _setup = ref.read(gameSetupProvider.notifier).read('xox');
    _engine = TicTacToeEngine();
    Future<void>.microtask(_restore);
  }

  Future<void> _restore() async {
    try {
      final raw = await loadAutosave('xox');
      if (raw == null || !mounted) return;
      final restored = TicTacToeState.fromJson(jsonDecode(raw) as Map<String, dynamic>);
      setState(() => _engine = TicTacToeEngine(restored));
      if (_setup.withBot && _engine.state.status == TicStatus.playing && _engine.state.turn == TicMark.o) {
        await _playBotTurn();
      }
    } catch (_) {
      deleteAutosave('xox');
    }
  }

  void _persist() {
    persistAutosave('xox', _engine.state);
    final state = _engine.state;
    if (state.status != TicStatus.playing) {
      recordMatchHistory(
        gameKey: 'xox',
        state: state,
        result: state.status == TicStatus.draw
            ? 'مساوی راند ${state.round}'
            : state.winner == TicMark.x
                ? 'برد بازیکن'
                : _setup.withBot
                    ? 'برد ربات'
                    : 'برد ${_playerName(1)}',
        outcome: state.status == TicStatus.draw
            ? LocalMatchOutcome.draw
            : state.winner == TicMark.x
                ? LocalMatchOutcome.win
                : LocalMatchOutcome.loss,
        opponent: _setup.withBot ? 'ربات ${_difficultyLabel(_setup.difficulty)}' : _playerName(1),
        startedAt: _startedAt,
      );
    }
  }

  Future<void> _playBotTurn() async {
    setState(() => _botThinking = true);
    await Future<void>.delayed(const Duration(milliseconds: 280));
    final move = await _bot.chooseMove(_engine.state, _setup.difficulty);
    if (!mounted) return;
    setState(() {
      _engine.apply(move);
      _botThinking = false;
    });
    _persist();
  }

  Future<void> _tap(int index) async {
    if (_botThinking || !_engine.isLegal(TicMove(index))) return;
    if (_setup.withBot && _engine.state.turn == TicMark.o) return;
    AudioService.instance.playMove();
    setState(() => _engine.apply(TicMove(index)));
    _persist();
    if (_setup.withBot && _engine.state.status == TicStatus.playing && _engine.state.turn == TicMark.o) {
      await _playBotTurn();
    }
  }

  String _playerName(int index) => index < _setup.playerNames.length
      ? _setup.playerNames[index]
      : 'بازیکن ${index + 1}';

  String _difficultyLabel(BotDifficulty value) => switch (value) {
        BotDifficulty.easy => 'آسان',
        BotDifficulty.medium => 'متوسط',
        BotDifficulty.hard => 'سخت',
      };

  @override
  Widget build(BuildContext context) {
    final state = _engine.state;
    final status = switch (state.status) {
      TicStatus.playing => _botThinking
          ? 'ربات در حال تصمیم‌گیری است'
          : 'نوبت ${state.turn == TicMark.x ? _playerName(0) : (_setup.withBot ? 'ربات' : _playerName(1))} (${state.turn.name.toUpperCase()})',
      TicStatus.won => '${state.winner == TicMark.x ? _playerName(0) : (_setup.withBot ? 'ربات' : _playerName(1))} این راند را برد',
      TicStatus.draw => 'راند مساوی شد',
    };
    return GameScreenFrame(
      title: 'XOX',
      subtitle: _setup.withBot ? 'مسابقه چندراندی با Minimax' : 'مسابقه چندراندی دونفره محلی',
      child: Column(
        children: [
          GameStatusStrip(
            leading: const AppIcon('xox', color: AppColors.xox),
            title: status,
            trailing: Text('${state.scoreX} — ${state.scoreO}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppColors.brassBright)),
            accent: AppColors.xox,
          ),
          const SizedBox(height: 18),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: AspectRatio(
              aspectRatio: 1,
              child: GildedPanel(
                accent: AppColors.xox,
                padding: const EdgeInsets.all(14),
                child: Stack(
                  children: [
                    Positioned.fill(child: CustomPaint(painter: _TicBoardPainter(winningLine: state.winningLine))),
                    GridView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
                      itemCount: 9,
                      itemBuilder: (context, index) => Semantics(
                        button: true,
                        label: 'خانه ${index + 1}',
                        child: InkWell(
                          onTap: () => _tap(index),
                          borderRadius: BorderRadius.circular(14),
                          child: Center(
                            child: AnimatedScale(
                              duration: const Duration(milliseconds: 180),
                              scale: state.board[index] == null ? 0.5 : 1,
                              child: Text(
                                state.board[index] == TicMark.x ? 'X' : state.board[index] == TicMark.o ? 'O' : '',
                                style: TextStyle(
                                  fontSize: 54,
                                  fontWeight: FontWeight.w900,
                                  color: state.board[index] == TicMark.x ? AppColors.brassBright : AppColors.xox,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: AppButton(label: 'Undo', icon: 'back', secondary: true, onPressed: _botThinking ? null : () { try { setState(_engine.undo); _persist(); } catch (_) {} })),
              const SizedBox(width: 10),
              Expanded(
                child: AppButton(
                  label: 'راند بعد',
                  icon: 'replay',
                  onPressed: state.status == TicStatus.playing
                      ? null
                      : () async {
                          _startedAt = DateTime.now();
                          setState(_engine.nextRound);
                          _persist();
                          if (_setup.withBot && _engine.state.turn == TicMark.o) {
                            await _playBotTurn();
                          }
                        },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _TicBoardPainter extends CustomPainter {
  const _TicBoardPainter({required this.winningLine});
  final List<int>? winningLine;
  @override
  void paint(Canvas canvas, Size size) {
    final linePaint = Paint()..color = AppColors.brass.withValues(alpha: 0.32)..strokeWidth = 2;
    for (var i = 1; i < 3; i++) {
      canvas.drawLine(Offset(size.width * i / 3, 8), Offset(size.width * i / 3, size.height - 8), linePaint);
      canvas.drawLine(Offset(8, size.height * i / 3), Offset(size.width - 8, size.height * i / 3), linePaint);
    }
    if (winningLine != null) {
      Offset center(int index) => Offset((index % 3 + 0.5) * size.width / 3, (index ~/ 3 + 0.5) * size.height / 3);
      final winPaint = Paint()..color = AppColors.success..strokeWidth = 7..strokeCap = StrokeCap.round;
      canvas.drawLine(center(winningLine!.first), center(winningLine!.last), winPaint);
    }
  }
  @override
  bool shouldRepaint(covariant _TicBoardPainter oldDelegate) => oldDelegate.winningLine != winningLine;
}
