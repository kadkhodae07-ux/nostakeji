import 'package:flutter/material.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/mock/social_mock_data.dart';
import 'package:nostalgia_club/shared/widgets/app_background.dart';
import 'package:nostalgia_club/shared/widgets/app_top_bar.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';
import 'package:nostalgia_club/shared/widgets/mock_badge.dart';

class FriendsScreen extends StatefulWidget {
  const FriendsScreen({super.key});
  @override
  State<FriendsScreen> createState() => _FriendsScreenState();
}

class _FriendsScreenState extends State<FriendsScreen> {
  final _search = TextEditingController();
  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    final query = _search.text.trim();
    final users = SocialMockData.users.where((user) => query.isEmpty || user.name.contains(query)).toList();
    return AppBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Column(children: [
          const AppTopBar(title: 'دوستان', subtitle: 'داده‌های نمایشی آماده اتصال', actions: [MockBadge()]),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 18), child: TextField(controller: _search, onChanged: (_) => setState(() {}), decoration: const InputDecoration(prefixIcon: Padding(padding: EdgeInsets.all(14), child: AppIcon('search', size: 20, color: AppColors.muted)), hintText: 'جست‌وجوی کاربر'))),
          const SizedBox(height: 12),
          Expanded(child: ListView.separated(padding: const EdgeInsets.fromLTRB(18, 0, 18, 24), itemCount: users.length, separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (context, index) => _FriendCard(user: users[index]))),
        ]),
      ),
    );
  }
}

class _FriendCard extends StatelessWidget {
  const _FriendCard({required this.user});
  final MockUser user;
  @override
  Widget build(BuildContext context) => GildedPanel(
        child: Row(children: [
          Stack(children: [Container(width: 50, height: 50, decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.brass.withValues(alpha: 0.13)), alignment: Alignment.center, child: const AppIcon('profile', color: AppColors.brassBright)), Positioned(left: 1, bottom: 1, child: Container(width: 12, height: 12, decoration: BoxDecoration(shape: BoxShape.circle, color: user.online ? AppColors.success : AppColors.muted, border: Border.all(color: AppColors.raised, width: 2))))]),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(user.name, style: const TextStyle(fontWeight: FontWeight.w900)), Text('سطح ${user.level} • ${user.favoriteGame}', style: const TextStyle(color: AppColors.muted, fontSize: 12))])),
          _MiniAction(icon: 'invite', label: 'دعوت', onTap: () => _show(context, 'دعوت نمایشی برای ${user.name} ثبت شد.')),
          const SizedBox(width: 7),
          _MiniAction(icon: 'close', label: 'حذف', onTap: () => _show(context, 'عملیات حذف در Mock Repository ثبت می‌شود.')),
        ]),
      );
  void _show(BuildContext context, String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
}

class _MiniAction extends StatelessWidget {
  const _MiniAction({required this.icon, required this.label, required this.onTap});
  final String icon;
  final String label;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Semantics(label: label, button: true, child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(14), child: Container(width: 40, height: 40, decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), color: AppColors.voidBlack.withValues(alpha: 0.32)), alignment: Alignment.center, child: AppIcon(icon, size: 18, color: AppColors.brassBright))));
}
