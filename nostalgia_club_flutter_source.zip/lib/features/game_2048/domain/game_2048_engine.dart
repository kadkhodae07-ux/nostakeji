import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:nostalgia_club/core/game/deterministic_random.dart';
import 'package:nostalgia_club/core/game/game_models.dart';

enum SwipeDirection { up, down, left, right }
enum Game2048Status { playing, reached2048, gameOver }

class Game2048Move implements GameMove {
  const Game2048Move(this.direction);
  final SwipeDirection direction;
}

class Game2048State implements SerializableGameState {
  const Game2048State({
    required this.cells,
    required this.score,
    required this.bestScore,
    required this.seed,
    required this.status,
    required this.undoRemaining,
    this.wonAcknowledged = false,
  });

  final List<int> cells;
  final int score;
  final int bestScore;
  final int seed;
  final Game2048Status status;
  final int undoRemaining;
  final bool wonAcknowledged;

  Game2048State copyWith({
    List<int>? cells,
    int? score,
    int? bestScore,
    int? seed,
    Game2048Status? status,
    int? undoRemaining,
    bool? wonAcknowledged,
  }) =>
      Game2048State(
        cells: cells ?? this.cells,
        score: score ?? this.score,
        bestScore: bestScore ?? this.bestScore,
        seed: seed ?? this.seed,
        status: status ?? this.status,
        undoRemaining: undoRemaining ?? this.undoRemaining,
        wonAcknowledged: wonAcknowledged ?? this.wonAcknowledged,
      );

  Map<String, Object?> toJson() => {
        'cells': cells,
        'score': score,
        'bestScore': bestScore,
        'seed': seed,
        'status': status.name,
        'undoRemaining': undoRemaining,
        'wonAcknowledged': wonAcknowledged,
      };

  factory Game2048State.fromJson(Map<String, dynamic> json) => Game2048State(
        cells: (json['cells'] as List).cast<int>(),
        score: json['score'] as int,
        bestScore: json['bestScore'] as int,
        seed: json['seed'] as int,
        status: Game2048Status.values.byName(json['status'] as String),
        undoRemaining: json['undoRemaining'] as int,
        wonAcknowledged: json['wonAcknowledged'] as bool? ?? false,
      );

  @override
  String serialize() => jsonEncode(toJson());

  @override
  String stateHash() => sha256.convert(utf8.encode(serialize())).toString();
}

class Game2048Engine implements GameEngine<Game2048State, Game2048Move> {
  Game2048Engine({int seed = 2048, int bestScore = 0, int undoLimit = 3})
      : _state = Game2048State(
          cells: List<int>.filled(16, 0),
          score: 0,
          bestScore: bestScore,
          seed: seed,
          status: Game2048Status.playing,
          undoRemaining: undoLimit,
          wonAcknowledged: false,
        ) {
    _state = _spawn(_spawn(_state));
  }

  Game2048Engine.fromState(this._state);

  Game2048State _state;
  final List<Game2048State> _history = [];

  @override
  Game2048State get state => _state;

  @override
  List<Game2048Move> legalMoves() => [
        for (final d in SwipeDirection.values)
          if (_simulate(_state.cells, d).changed) Game2048Move(d),
      ];

  @override
  bool isLegal(Game2048Move move) => _state.status == Game2048Status.playing &&
      _simulate(_state.cells, move.direction).changed;

  @override
  Game2048State apply(Game2048Move move) {
    final simulated = _simulate(_state.cells, move.direction);
    if (!simulated.changed || _state.status != Game2048Status.playing) {return _state;}
    _history.add(_state);
    var next = _state.copyWith(
      cells: simulated.cells,
      score: _state.score + simulated.gained,
      bestScore: (_state.score + simulated.gained) > _state.bestScore
          ? _state.score + simulated.gained
          : _state.bestScore,
    );
    next = _spawn(next);
    final reached = next.cells.any((v) => v >= 2048);
    final noMoves = SwipeDirection.values.every((d) => !_simulate(next.cells, d).changed);
    next = next.copyWith(
      status: noMoves
          ? Game2048Status.gameOver
          : reached && !next.wonAcknowledged
              ? Game2048Status.reached2048
              : Game2048Status.playing,
    );
    _state = next;
    return _state;
  }

  Game2048State continueAfter2048() {
    if (_state.status == Game2048Status.reached2048) {
      _state = _state.copyWith(status: Game2048Status.playing, wonAcknowledged: true);
    }
    return _state;
  }

  _MergeResult _simulate(List<int> source, SwipeDirection direction) {
    final output = List<int>.filled(16, 0);
    var gained = 0;
    for (var line = 0; line < 4; line++) {
      final values = <int>[];
      for (var offset = 0; offset < 4; offset++) {
        final index = _indexFor(direction, line, offset);
        if (source[index] != 0) {values.add(source[index]);}
      }
      final merged = <int>[];
      var i = 0;
      while (i < values.length) {
        if (i + 1 < values.length && values[i] == values[i + 1]) {
          final value = values[i] * 2;
          merged.add(value);
          gained += value;
          i += 2;
        } else {
          merged.add(values[i]);
          i++;
        }
      }
      for (var offset = 0; offset < 4; offset++) {
        output[_indexFor(direction, line, offset)] = offset < merged.length ? merged[offset] : 0;
      }
    }
    return _MergeResult(output, gained, !_listEquals(source, output));
  }

  int _indexFor(SwipeDirection direction, int line, int offset) {
    return switch (direction) {
      SwipeDirection.left => line * 4 + offset,
      SwipeDirection.right => line * 4 + (3 - offset),
      SwipeDirection.up => offset * 4 + line,
      SwipeDirection.down => (3 - offset) * 4 + line,
    };
  }

  bool _listEquals(List<int> a, List<int> b) {
    for (var i = 0; i < a.length; i++) {
      if (a[i] != b[i]) {return false;}
    }
    return true;
  }

  Game2048State _spawn(Game2048State state) {
    final empty = [for (var i = 0; i < 16; i++) if (state.cells[i] == 0) i];
    if (empty.isEmpty) {return state;}
    final random = DeterministicRandom(state.seed);
    final index = empty[random.nextInt(empty.length)];
    final value = random.nextInt(10) == 0 ? 4 : 2;
    final cells = List<int>.from(state.cells)..[index] = value;
    return state.copyWith(cells: cells, seed: random.state);
  }

  @override
  Game2048State undo() {
    if (_history.isEmpty || _state.undoRemaining <= 0) {return _state;}
    final previous = _history.removeLast();
    _state = previous.copyWith(undoRemaining: _state.undoRemaining - 1);
    return _state;
  }

  @override
  void restore(Game2048State state) {
    _history.clear();
    _state = state;
  }

  static List<int> mergeRowForTest(List<int> row) {
    if (row.length != 4) {throw ArgumentError('A row must contain four cells');}
    final engine = Game2048Engine.fromState(Game2048State(
      cells: [...row, ...List<int>.filled(12, 0)],
      score: 0,
      bestScore: 0,
      seed: 1,
      status: Game2048Status.playing,
      undoRemaining: 0,
      wonAcknowledged: false,
    ));
    return engine._simulate(engine.state.cells, SwipeDirection.left).cells.take(4).toList();
  }
}

class _MergeResult {
  const _MergeResult(this.cells, this.gained, this.changed);
  final List<int> cells;
  final int gained;
  final bool changed;
}
