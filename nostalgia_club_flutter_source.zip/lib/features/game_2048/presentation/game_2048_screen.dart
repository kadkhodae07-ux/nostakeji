import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/storage/game_autosave_mixin.dart';
import 'package:nostalgia_club/core/storage/match_history_repository.dart';
import 'package:nostalgia_club/features/game_2048/domain/game_2048_engine.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_button.dart';
import 'package:nostalgia_club/shared/widgets/game_screen_frame.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';

class Game2048Screen extends ConsumerStatefulWidget {
  const Game2048Screen({super.key});
  @override
  ConsumerState<Game2048Screen> createState() => _Game2048ScreenState();
}

class _Game2048ScreenState extends ConsumerState<Game2048Screen> with GameAutosaveMixin<Game2048Screen> {
  late Game2048Engine _engine;
  Offset _drag = Offset.zero;
  DateTime _startedAt = DateTime.now();

  @override
  void initState() {
    super.initState();
    _engine = Game2048Engine(seed: DateTime.now().millisecondsSinceEpoch);
    Future<void>.microtask(_restore);
  }

  Future<void> _restore() async {
    try {
      final raw = await loadAutosave('2048');
      if (raw == null || !mounted) {return;}
      final restored = Game2048State.fromJson(jsonDecode(raw) as Map<String, dynamic>);
      setState(() => _engine = Game2048Engine.fromState(restored));
    } catch (_) {
      deleteAutosave('2048');
    }
  }

  void _persist() {
    if (_engine.state.status == Game2048Status.gameOver) {
      deleteAutosave('2048');
      recordMatchHistory(
        gameKey: '2048',
        state: _engine.state,
        result: '${_engine.state.score} امتیاز',
        outcome: LocalMatchOutcome.score,
        opponent: 'تک‌نفره',
        startedAt: _startedAt,
      );
    } else {
      persistAutosave('2048', _engine.state);
    }
  }

  void _move(SwipeDirection direction) {
    setState(() => _engine.apply(Game2048Move(direction)));
    _persist();
  }

  @override
  Widget build(BuildContext context) {
    final state = _engine.state;
    return GameScreenFrame(
      title: '۲۰۴۸',
      subtitle: 'حرکت دهید، ترکیب کنید، رکورد بزنید',
      child: Column(
        children: [
          Row(
            children: [
              Expanded(child: _ScoreCard(label: 'امتیاز', value: state.score)),
              const SizedBox(width: 10),
              Expanded(child: _ScoreCard(label: 'بهترین', value: state.bestScore)),
            ],
          ),
          const SizedBox(height: 16),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: AspectRatio(
              aspectRatio: 1,
              child: GestureDetector(
                onPanStart: (_) => _drag = Offset.zero,
                onPanUpdate: (details) => _drag += details.delta,
                onPanEnd: (_) {
                  if (_drag.distance < 24) {return;}
                  if (_drag.dx.abs() > _drag.dy.abs()) {
                    _move(_drag.dx > 0 ? SwipeDirection.right : SwipeDirection.left);
                  } else {
                    _move(_drag.dy > 0 ? SwipeDirection.down : SwipeDirection.up);
                  }
                },
                child: GildedPanel(
                  accent: AppColors.game2048,
                  padding: const EdgeInsets.all(10),
                  child: GridView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, crossAxisSpacing: 8, mainAxisSpacing: 8),
                    itemCount: 16,
                    itemBuilder: (context, index) => _Tile(value: state.cells[index]),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          GameStatusStrip(
            leading: const AppIcon('2048', color: AppColors.game2048),
            title: state.status == Game2048Status.gameOver
                ? 'حرکت قانونی باقی نمانده است'
                : state.status == Game2048Status.reached2048
                    ? 'به ۲۰۴۸ رسیدید؛ می‌توانید ادامه دهید'
                    : 'برای حرکت، صفحه را در چهار جهت بکشید',
            trailing: Text('${state.undoRemaining} Undo', style: const TextStyle(color: AppColors.muted, fontSize: 11)),
            accent: AppColors.game2048,
          ),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: AppButton(label: 'Undo', icon: 'back', secondary: true, onPressed: state.undoRemaining > 0 ? () { setState(_engine.undo); _persist(); } : null)),
            const SizedBox(width: 10),
            Expanded(child: AppButton(label: 'شروع تازه', icon: 'replay', onPressed: () { _startedAt = DateTime.now(); setState(() => _engine = Game2048Engine(seed: DateTime.now().millisecondsSinceEpoch, bestScore: state.bestScore)); _persist(); })),
          ]),
          if (state.status == Game2048Status.reached2048) ...[
            const SizedBox(height: 10),
            AppButton(label: 'ادامه بعد از ۲۰۴۸', icon: 'continue', secondary: true, onPressed: () { setState(_engine.continueAfter2048); _persist(); }),
          ],
        ],
      ),
    );
  }
}

class _ScoreCard extends StatelessWidget {
  const _ScoreCard({required this.label, required this.value});
  final String label;
  final int value;
  @override
  Widget build(BuildContext context) => GildedPanel(
        accent: AppColors.game2048,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(label, style: const TextStyle(color: AppColors.muted)), Text('$value', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.brassBright))]),
      );
}

class _Tile extends StatelessWidget {
  const _Tile({required this.value});
  final int value;

  Color _color() {
    if (value == 0) {return AppColors.voidBlack.withValues(alpha: 0.36);}
    final level = value.bitLength.clamp(1, 15);
    return Color.lerp(AppColors.game2048.withValues(alpha: 0.35), AppColors.brassBright, level / 15)!;
  }

  @override
  Widget build(BuildContext context) {
    final digits = value.toString().length;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: _color(), border: Border.all(color: AppColors.parchment.withValues(alpha: value == 0 ? 0.04 : 0.15))),
      alignment: Alignment.center,
      child: AnimatedScale(
        duration: const Duration(milliseconds: 160),
        scale: value == 0 ? 0.7 : 1,
        child: Text(value == 0 ? '' : '$value', style: TextStyle(fontSize: digits <= 3 ? 27 : digits <= 5 ? 20 : 15, fontWeight: FontWeight.w900, color: value <= 4 ? AppColors.parchment : AppColors.voidBlack)),
      ),
    );
  }
}
