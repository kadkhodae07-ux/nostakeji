import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nostalgia_club/core/config/app_config.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/storage/database_provider.dart';
import 'package:nostalgia_club/features/settings/domain/settings_controller.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_background.dart';
import 'package:nostalgia_club/shared/widgets/app_top_bar.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final controller = ref.read(settingsProvider.notifier);
    return AppBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Column(children: [
          const AppTopBar(title: 'تنظیمات', subtitle: 'صدا، دسترس‌پذیری و داده محلی'),
          Expanded(child: ListView(padding: const EdgeInsets.fromLTRB(18, 0, 18, 24), children: [
            _Section(title: 'صدا و بازخورد', children: [
              _SwitchRow(icon: 'sound', title: 'صدای بازی', value: settings.sound, onChanged: controller.setSound),
              _SwitchRow(icon: 'music', title: 'موسیقی محیطی', value: settings.music, onChanged: controller.setMusic),
              _SwitchRow(icon: 'vibration', title: 'لرزش و Haptic', value: settings.vibration, onChanged: controller.setVibration),
            ]),
            const SizedBox(height: 12),
            _Section(title: 'نمایش و دسترس‌پذیری', children: [
              _SwitchRow(icon: 'theme', title: 'کاهش حرکت', subtitle: 'Transitionها و Animationهای غیرضروری کاهش می‌یابند.', value: settings.reducedMotion, onChanged: controller.setReducedMotion),
              _ChoiceRow(icon: 'difficulty', title: 'کیفیت انیمیشن', value: settings.animationQuality, options: const {'low': 'کم', 'medium': 'متوسط', 'high': 'زیاد'}, onChanged: controller.setAnimationQuality),
              _ChoiceRow(icon: 'theme', title: 'تم رابط', value: settings.themeVariant, options: const {'classic': 'کلاسیک', 'highContrast': 'کنتراست بالا'}, onChanged: controller.setThemeVariant),
              _ChoiceRow(icon: 'language', title: 'زبان', value: settings.language, options: const {'fa': 'فارسی', 'en': 'English'}, onChanged: controller.setLanguage),
            ]),
            const SizedBox(height: 12),
            _Section(title: 'اعلان و حریم خصوصی', children: [
              _SwitchRow(icon: 'notification', title: 'اعلان‌ها', value: settings.notifications, onChanged: controller.setNotifications),
              _ActionRow(icon: 'lock', title: 'حریم خصوصی نمایشی', subtitle: 'قرارداد Remote آماده است.'),
            ]),
            const SizedBox(height: 12),
            _Section(title: 'داده و برنامه', children: [
              _ActionRow(
                icon: 'delete',
                title: 'پاک‌کردن داده محلی',
                subtitle: 'پروفایل، تاریخچه، تنظیمات و بازی‌های ذخیره‌شده',
                onTap: () async {
                  await ref.read(appDatabaseProvider).clearLocalData();
                  await ref.read(settingsProvider.notifier).resetDefaults();
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('تمام داده‌های محلی پاک شدند.')),
                    );
                  }
                },
              ),
              _ActionRow(icon: 'rules', title: 'قوانین و شرایط'),
              _ActionRow(icon: 'info', title: 'درباره ما', subtitle: '${AppConfig.appNameEn} • ${AppConfig.version}'),
            ]),
          ])),
        ]),
      ),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title, required this.children});
  final String title;
  final List<Widget> children;
  @override
  Widget build(BuildContext context) => GildedPanel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: Theme.of(context).textTheme.titleMedium), const SizedBox(height: 8), for (var i = 0; i < children.length; i++) ...[children[i], if (i != children.length - 1) const Divider(height: 18)]]));
}

class _SwitchRow extends StatelessWidget {
  const _SwitchRow({required this.icon, required this.title, this.subtitle, required this.value, required this.onChanged});
  final String icon;
  final String title;
  final String? subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  @override
  Widget build(BuildContext context) => SwitchListTile(contentPadding: EdgeInsets.zero, value: value, onChanged: onChanged, secondary: AppIcon(icon, color: AppColors.brassBright), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: subtitle == null ? null : Text(subtitle!, style: const TextStyle(color: AppColors.muted, fontSize: 11)));
}

class _ChoiceRow extends StatelessWidget {
  const _ChoiceRow({required this.icon, required this.title, required this.value, required this.options, required this.onChanged});
  final String icon;
  final String title;
  final String value;
  final Map<String, String> options;
  final ValueChanged<String> onChanged;
  @override
  Widget build(BuildContext context) => Row(children: [AppIcon(icon, color: AppColors.brassBright), const SizedBox(width: 12), Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800))), DropdownButton<String>(value: value, underline: const SizedBox.shrink(), dropdownColor: AppColors.panel, items: [for (final entry in options.entries) DropdownMenuItem(value: entry.key, child: Text(entry.value))], onChanged: (value) { if (value != null) onChanged(value); })]);
}

class _ActionRow extends StatelessWidget {
  const _ActionRow({required this.icon, required this.title, this.subtitle, this.onTap});
  final String icon;
  final String title;
  final String? subtitle;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap ?? () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$title در لایه محلی/Mock آماده است.'))), borderRadius: BorderRadius.circular(12), child: Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Row(children: [AppIcon(icon, color: AppColors.brassBright), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), if (subtitle != null) Text(subtitle!, style: const TextStyle(fontSize: 11, color: AppColors.muted))])), const AppIcon('continue', size: 17, color: AppColors.muted)])));
}
