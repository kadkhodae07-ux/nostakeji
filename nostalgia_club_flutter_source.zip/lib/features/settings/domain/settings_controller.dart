import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nostalgia_club/core/audio/audio_service.dart';
import 'package:nostalgia_club/core/storage/app_database.dart';
import 'package:nostalgia_club/core/storage/database_provider.dart';

class AppSettingsState {
  const AppSettingsState({
    this.sound = true,
    this.music = true,
    this.vibration = true,
    this.notifications = true,
    this.reducedMotion = false,
    this.language = 'fa',
    this.animationQuality = 'high',
    this.themeVariant = 'classic',
    this.loaded = false,
  });

  final bool sound;
  final bool music;
  final bool vibration;
  final bool notifications;
  final bool reducedMotion;
  final String language;
  final String animationQuality;
  final String themeVariant;
  final bool loaded;

  AppSettingsState copyWith({
    bool? sound,
    bool? music,
    bool? vibration,
    bool? notifications,
    bool? reducedMotion,
    String? language,
    String? animationQuality,
    String? themeVariant,
    bool? loaded,
  }) =>
      AppSettingsState(
        sound: sound ?? this.sound,
        music: music ?? this.music,
        vibration: vibration ?? this.vibration,
        notifications: notifications ?? this.notifications,
        reducedMotion: reducedMotion ?? this.reducedMotion,
        language: language ?? this.language,
        animationQuality: animationQuality ?? this.animationQuality,
        themeVariant: themeVariant ?? this.themeVariant,
        loaded: loaded ?? this.loaded,
      );
}

class SettingsController extends StateNotifier<AppSettingsState> {
  SettingsController(this._database) : super(const AppSettingsState()) {
    unawaited(_load());
  }

  final AppDatabase _database;

  Future<void> _load() async {
    try {
      final values = await Future.wait([
        _database.readSetting('sound'),
        _database.readSetting('music'),
        _database.readSetting('vibration'),
        _database.readSetting('notifications'),
        _database.readSetting('reducedMotion'),
        _database.readSetting('language'),
        _database.readSetting('animationQuality'),
        _database.readSetting('themeVariant'),
      ]);
      state = state.copyWith(
        sound: _readBool(values[0], fallback: true),
        music: _readBool(values[1], fallback: true),
        vibration: _readBool(values[2], fallback: true),
        notifications: _readBool(values[3], fallback: true),
        reducedMotion: _readBool(values[4], fallback: false),
        language: values[5] ?? 'fa',
        animationQuality: values[6] ?? 'high',
        themeVariant: values[7] ?? 'classic',
        loaded: true,
      );
      await AudioService.instance.setEffectsEnabled(state.sound);
      await AudioService.instance.setMusicEnabled(state.music);
      await AudioService.instance.setHapticsEnabled(state.vibration);
    } catch (_) {
      state = state.copyWith(loaded: true);
    }
  }

  bool _readBool(String? raw, {required bool fallback}) => raw == null ? fallback : raw == 'true';

  void setSound(bool value) {
    state = state.copyWith(sound: value);
    unawaited(AudioService.instance.setEffectsEnabled(value));
    unawaited(_database.writeSetting('sound', '$value'));
  }

  void setMusic(bool value) {
    state = state.copyWith(music: value);
    unawaited(AudioService.instance.setMusicEnabled(value));
    unawaited(_database.writeSetting('music', '$value'));
  }

  void setVibration(bool value) {
    state = state.copyWith(vibration: value);
    unawaited(AudioService.instance.setHapticsEnabled(value));
    unawaited(_database.writeSetting('vibration', '$value'));
  }

  void setNotifications(bool value) {
    state = state.copyWith(notifications: value);
    unawaited(_database.writeSetting('notifications', '$value'));
  }

  void setReducedMotion(bool value) {
    state = state.copyWith(reducedMotion: value);
    unawaited(_database.writeSetting('reducedMotion', '$value'));
  }

  void setLanguage(String value) {
    state = state.copyWith(language: value);
    unawaited(_database.writeSetting('language', value));
  }

  void setAnimationQuality(String value) {
    state = state.copyWith(animationQuality: value);
    unawaited(_database.writeSetting('animationQuality', value));
  }

  void setThemeVariant(String value) {
    state = state.copyWith(themeVariant: value);
    unawaited(_database.writeSetting('themeVariant', value));
  }

  Future<void> resetDefaults() async {
    state = const AppSettingsState(loaded: true);
    await AudioService.instance.setEffectsEnabled(true);
    await AudioService.instance.setMusicEnabled(true);
    await AudioService.instance.setHapticsEnabled(true);
  }
}

final settingsProvider = StateNotifierProvider<SettingsController, AppSettingsState>(
  (ref) => SettingsController(ref.watch(appDatabaseProvider)),
);
