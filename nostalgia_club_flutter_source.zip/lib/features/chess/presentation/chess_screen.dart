import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nostalgia_club/core/audio/audio_service.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/game/game_models.dart';
import 'package:nostalgia_club/core/storage/game_autosave_mixin.dart';
import 'package:nostalgia_club/core/storage/match_history_repository.dart';
import 'package:nostalgia_club/features/chess/domain/chess_engine.dart';
import 'package:nostalgia_club/features/game_catalog/domain/game_setup.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_button.dart';
import 'package:nostalgia_club/shared/widgets/game_screen_frame.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';

class ChessScreen extends ConsumerStatefulWidget {
  const ChessScreen({super.key});
  @override
  ConsumerState<ChessScreen> createState() => _ChessScreenState();
}

class _ChessScreenState extends ConsumerState<ChessScreen> with GameAutosaveMixin<ChessScreen> {
  late ChessEngine _engine;
  final _bot = const ChessBot();
  late final GameSetupConfig _setup;
  int? _selected;
  bool _thinking = false;
  DateTime _startedAt = DateTime.now();

  @override
  void initState() {
    super.initState();
    _setup = ref.read(gameSetupProvider.notifier).read('chess');
    _engine = ChessEngine();
    Future<void>.microtask(_restore);
  }

  Future<void> _restore() async {
    try {
      final raw = await loadAutosave('chess');
      if (raw == null || !mounted) {return;}
      final restored = ChessState.fromJson(jsonDecode(raw) as Map<String, dynamic>);
      setState(() => _engine = ChessEngine(restored));
      if (_setup.withBot && _engine.state.result == ChessResult.playing && _engine.state.turn == ChessColor.black) {
        await _playBot();
      }
    } catch (_) {
      deleteAutosave('chess');
    }
  }

  void _persist() {
    final state = _engine.state;
    if (state.result == ChessResult.playing) {
      persistAutosave('chess', state);
    } else {
      deleteAutosave('chess');
      recordMatchHistory(
        gameKey: 'chess',
        state: state,
        result: switch (state.result) {
          ChessResult.whiteWin => 'برد ${_setup.playerNames.first}',
          ChessResult.blackWin => _setup.withBot
              ? 'برد ربات'
              : 'برد ${_setup.playerNames.length > 1 ? _setup.playerNames[1] : 'بازیکن دوم'}',
          ChessResult.draw => 'مساوی • ${state.resultReason ?? ''}',
          ChessResult.playing => 'در حال بازی',
        },
        outcome: switch (state.result) {
          ChessResult.whiteWin => LocalMatchOutcome.win,
          ChessResult.blackWin => LocalMatchOutcome.loss,
          ChessResult.draw => LocalMatchOutcome.draw,
          ChessResult.playing => LocalMatchOutcome.ranking,
        },
        opponent: _setup.withBot ? 'ربات ${_difficultyLabel(_setup.difficulty)}' : (_setup.playerNames.length > 1 ? _setup.playerNames[1] : 'بازیکن محلی'),
        startedAt: _startedAt,
      );
    }
  }

  List<ChessMove> get _selectedMoves => _selected == null ? const [] : _engine.legalMovesFrom(_selected!);

  Future<void> _tapSquare(int square) async {
    if (_thinking || _engine.state.result != ChessResult.playing) {return;}
    if (_setup.withBot && _engine.state.turn != ChessColor.white) {return;}
    final piece = _engine.state.board[square];
    if (_selected == null) {
      if (piece?.color == _engine.state.turn) {setState(() => _selected = square);}
      return;
    }
    final candidates = _selectedMoves.where((move) => move.to == square).toList();
    if (candidates.isEmpty) {
      setState(() => _selected = piece?.color == _engine.state.turn ? square : null);
      return;
    }
    ChessMove selectedMove;
    if (candidates.length > 1) {
      final promotion = await _choosePromotion();
      if (promotion == null || !mounted) {return;}
      selectedMove = candidates.firstWhere((move) => move.promotion == promotion);
    } else {
      selectedMove = candidates.single;
    }
    AudioService.instance.playMove();
    setState(() {
      _engine.apply(selectedMove);
      _selected = null;
    });
    _persist();
    if (_setup.withBot && _engine.state.result == ChessResult.playing && _engine.state.turn == ChessColor.black) {await _playBot();}
  }

  Future<ChessPieceType?> _choosePromotion() => showDialog<ChessPieceType>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('انتخاب مهره ارتقا'),
          content: Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final type in const [ChessPieceType.queen, ChessPieceType.rook, ChessPieceType.bishop, ChessPieceType.knight])
                InkWell(
                  onTap: () => Navigator.of(context).pop(type),
                  borderRadius: BorderRadius.circular(14),
                  child: Container(width: 62, height: 62, decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), color: AppColors.raised, border: Border.all(color: AppColors.brass.withValues(alpha: 0.4))), alignment: Alignment.center, child: AppIcon('piece_${type.name}', size: 38, color: AppColors.brassBright)),
                ),
            ],
          ),
        ),
      );

  Future<void> _playBot() async {
    setState(() => _thinking = true);
    await Future<void>.delayed(const Duration(milliseconds: 280));
    final move = await _bot.chooseMove(_engine.state, _setup.difficulty);
    if (!mounted) {return;}
    setState(() {
      _engine.apply(move);
      _thinking = false;
    });
    _persist();
  }

  String _difficultyLabel(BotDifficulty value) => switch (value) {
        BotDifficulty.easy => 'آسان',
        BotDifficulty.medium => 'متوسط',
        BotDifficulty.hard => 'سخت',
      };

  @override
  Widget build(BuildContext context) {
    final state = _engine.state;
    final inCheck = _engine.isKingInCheck(state, state.turn);
    final status = switch (state.result) {
      ChessResult.playing => _thinking
          ? 'ربات در حال جست‌وجوی حرکت است'
          : '${state.turn == ChessColor.white ? _setup.playerNames.first : (_setup.withBot ? 'ربات' : (_setup.playerNames.length > 1 ? _setup.playerNames[1] : 'بازیکن دوم'))} در نوبت است${inCheck ? ' • کیش' : ''}',
      ChessResult.whiteWin => 'کیش‌ومات؛ شما برنده شدید',
      ChessResult.blackWin => 'کیش‌ومات؛ ربات برنده شد',
      ChessResult.draw => 'مساوی • ${state.resultReason ?? ''}',
    };
    return GameScreenFrame(
      title: 'شطرنج',
      subtitle: _setup.withBot ? 'قوانین کامل • شما سفید هستید' : 'قوانین کامل • دونفره محلی',
      child: Column(
        children: [
          GameStatusStrip(
            leading: const AppIcon('chess', color: AppColors.chess),
            title: status,
            trailing: Text('${state.fullmoveNumber}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: AppColors.brassBright)),
            accent: AppColors.chess,
          ),
          const SizedBox(height: 14),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 640),
            child: AspectRatio(
              aspectRatio: 1,
              child: GildedPanel(
                accent: AppColors.chess,
                padding: const EdgeInsets.all(7),
                child: GridView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 8),
                  itemCount: 64,
                  itemBuilder: (context, square) => _ChessSquare(
                    square: square,
                    piece: state.board[square],
                    selected: _selected == square,
                    legalTarget: _selectedMoves.any((move) => move.to == square),
                    lastMove: state.lastMove?.from == square || state.lastMove?.to == square,
                    inCheck: state.board[square]?.type == ChessPieceType.king && state.board[square]?.color == state.turn && inCheck,
                    onTap: () => _tapSquare(square),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: AppButton(label: 'Undo دو حرکت', icon: 'back', secondary: true, onPressed: _thinking || state.history.isEmpty ? null : () {
              try {
                setState(() {
                  _engine.undo();
                  if (_engine.state.turn == ChessColor.black) {_engine.undo();}
                  _selected = null;
                });
              } catch (_) {}
              _persist();
            })),
            const SizedBox(width: 10),
            Expanded(child: AppButton(label: 'FEN / PGN', icon: 'info', secondary: true, onPressed: () => _showNotation(context))),
          ]),
          const SizedBox(height: 10),
          AppButton(label: 'شروع مسابقه تازه', icon: 'replay', onPressed: () { _startedAt = DateTime.now(); setState(() { _engine = ChessEngine(); _selected = null; }); _persist(); }),
        ],
      ),
    );
  }

  void _showNotation(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.charcoal,
      builder: (context) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('FEN', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              SelectableText(_engine.state.fen, style: const TextStyle(color: AppColors.muted, height: 1.6)),
              const SizedBox(height: 20),
              Text('PGN', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              SelectableText(_engine.exportPgn(white: 'بازیکن مهمان', black: 'ربات محلی'), style: const TextStyle(color: AppColors.muted, height: 1.6)),
            ],
          ),
        ),
      ),
    );
  }
}

class _ChessSquare extends StatelessWidget {
  const _ChessSquare({required this.square, required this.piece, required this.selected, required this.legalTarget, required this.lastMove, required this.inCheck, required this.onTap});
  final int square;
  final ChessPiece? piece;
  final bool selected;
  final bool legalTarget;
  final bool lastMove;
  final bool inCheck;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final row = ChessEngine.rowOf(square);
    final col = ChessEngine.colOf(square);
    final dark = (row + col).isOdd;
    final base = dark ? const Color(0xFF6A5541) : const Color(0xFFD5BE96);
    return Semantics(
      button: true,
      label: '${ChessEngine.squareName(square)} ${piece?.type.name ?? 'خالی'}',
      child: InkWell(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          decoration: BoxDecoration(
            color: inCheck
                ? AppColors.danger.withValues(alpha: 0.85)
                : selected
                    ? AppColors.success.withValues(alpha: 0.72)
                    : lastMove
                        ? AppColors.brassBright.withValues(alpha: 0.55)
                        : base,
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              if (piece != null)
                Padding(
                  padding: const EdgeInsets.all(5),
                  child: AppIcon('piece_${piece!.type.name}', size: 52, color: piece!.color == ChessColor.white ? const Color(0xFFFFF4DE) : const Color(0xFF171411)),
                ),
              if (legalTarget)
                Container(
                  width: piece == null ? 15 : 52,
                  height: piece == null ? 15 : 52,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: piece == null ? AppColors.success.withValues(alpha: 0.72) : Colors.transparent, border: piece == null ? null : Border.all(color: AppColors.success, width: 4)),
                ),
              if (row == 7)
                Positioned(left: 2, bottom: 1, child: Text('abcdefgh'[col], style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900, color: dark ? AppColors.parchment : AppColors.voidBlack))),
              if (col == 0)
                Positioned(right: 2, top: 1, child: Text('${8 - row}', style: TextStyle(fontSize: 8, fontWeight: FontWeight.w900, color: dark ? AppColors.parchment : AppColors.voidBlack))),
            ],
          ),
        ),
      ),
    );
  }
}
