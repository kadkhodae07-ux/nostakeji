import 'dart:convert';
import 'dart:isolate';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:nostalgia_club/core/game/game_models.dart';

enum ChessColor { white, black }
enum ChessPieceType { pawn, knight, bishop, rook, queen, king }
enum ChessResult { playing, whiteWin, blackWin, draw }

extension ChessColorX on ChessColor {
  ChessColor get opposite => this == ChessColor.white ? ChessColor.black : ChessColor.white;
  int get pawnDirection => this == ChessColor.white ? -1 : 1;
  int get homePawnRow => this == ChessColor.white ? 6 : 1;
  int get promotionRow => this == ChessColor.white ? 0 : 7;
}

class ChessPiece {
  const ChessPiece(this.type, this.color);
  final ChessPieceType type;
  final ChessColor color;

  String get fenChar {
    final raw = switch (type) {
      ChessPieceType.pawn => 'p',
      ChessPieceType.knight => 'n',
      ChessPieceType.bishop => 'b',
      ChessPieceType.rook => 'r',
      ChessPieceType.queen => 'q',
      ChessPieceType.king => 'k',
    };
    return color == ChessColor.white ? raw.toUpperCase() : raw;
  }

  Map<String, Object?> toJson() => {'type': type.name, 'color': color.name};
  factory ChessPiece.fromJson(Map<String, dynamic> json) => ChessPiece(
        ChessPieceType.values.byName(json['type'] as String),
        ChessColor.values.byName(json['color'] as String),
      );
}

class CastlingRights {
  const CastlingRights({
    this.whiteKingSide = true,
    this.whiteQueenSide = true,
    this.blackKingSide = true,
    this.blackQueenSide = true,
  });

  final bool whiteKingSide;
  final bool whiteQueenSide;
  final bool blackKingSide;
  final bool blackQueenSide;

  CastlingRights copyWith({
    bool? whiteKingSide,
    bool? whiteQueenSide,
    bool? blackKingSide,
    bool? blackQueenSide,
  }) =>
      CastlingRights(
        whiteKingSide: whiteKingSide ?? this.whiteKingSide,
        whiteQueenSide: whiteQueenSide ?? this.whiteQueenSide,
        blackKingSide: blackKingSide ?? this.blackKingSide,
        blackQueenSide: blackQueenSide ?? this.blackQueenSide,
      );

  String get fen {
    final value = StringBuffer();
    if (whiteKingSide) {value.write('K');}
    if (whiteQueenSide) {value.write('Q');}
    if (blackKingSide) {value.write('k');}
    if (blackQueenSide) {value.write('q');}
    return value.length == 0 ? '-' : value.toString();
  }

  Map<String, Object?> toJson() => {
        'whiteKingSide': whiteKingSide,
        'whiteQueenSide': whiteQueenSide,
        'blackKingSide': blackKingSide,
        'blackQueenSide': blackQueenSide,
      };

  factory CastlingRights.fromJson(Map<String, dynamic> json) => CastlingRights(
        whiteKingSide: json['whiteKingSide'] as bool,
        whiteQueenSide: json['whiteQueenSide'] as bool,
        blackKingSide: json['blackKingSide'] as bool,
        blackQueenSide: json['blackQueenSide'] as bool,
      );
}

class ChessMove implements GameMove {
  const ChessMove({
    required this.from,
    required this.to,
    this.promotion,
    this.isEnPassant = false,
    this.isCastle = false,
  });

  final int from;
  final int to;
  final ChessPieceType? promotion;
  final bool isEnPassant;
  final bool isCastle;

  String get coordinate => '${ChessEngine.squareName(from)}${ChessEngine.squareName(to)}${promotion == null ? '' : promotion!.name[0]}';

  Map<String, Object?> toJson() => {
        'from': from,
        'to': to,
        'promotion': promotion?.name,
        'isEnPassant': isEnPassant,
        'isCastle': isCastle,
      };

  factory ChessMove.fromJson(Map<String, dynamic> json) => ChessMove(
        from: json['from'] as int,
        to: json['to'] as int,
        promotion: json['promotion'] == null
            ? null
            : ChessPieceType.values.byName(json['promotion'] as String),
        isEnPassant: json['isEnPassant'] as bool? ?? false,
        isCastle: json['isCastle'] as bool? ?? false,
      );

  bool sameAs(ChessMove other) =>
      from == other.from && to == other.to && promotion == other.promotion;
}

class ChessPly {
  const ChessPly({required this.move, required this.san});
  final ChessMove move;
  final String san;
  Map<String, Object?> toJson() => {'move': move.toJson(), 'san': san};
  factory ChessPly.fromJson(Map<String, dynamic> json) => ChessPly(
        move: ChessMove.fromJson(json['move'] as Map<String, dynamic>),
        san: json['san'] as String,
      );
}

class ChessState implements SerializableGameState {
  const ChessState({
    required this.board,
    required this.turn,
    required this.castling,
    required this.halfmoveClock,
    required this.fullmoveNumber,
    required this.positionCounts,
    required this.history,
    required this.result,
    this.enPassantTarget,
    this.resultReason,
    this.lastMove,
  });

  factory ChessState.initial() {
    const back = [
      ChessPieceType.rook,
      ChessPieceType.knight,
      ChessPieceType.bishop,
      ChessPieceType.queen,
      ChessPieceType.king,
      ChessPieceType.bishop,
      ChessPieceType.knight,
      ChessPieceType.rook,
    ];
    final board = List<ChessPiece?>.filled(64, null);
    for (var col = 0; col < 8; col++) {
      board[col] = ChessPiece(back[col], ChessColor.black);
      board[8 + col] = const ChessPiece(ChessPieceType.pawn, ChessColor.black);
      board[48 + col] = const ChessPiece(ChessPieceType.pawn, ChessColor.white);
      board[56 + col] = ChessPiece(back[col], ChessColor.white);
    }
    final state = ChessState(
      board: board,
      turn: ChessColor.white,
      castling: const CastlingRights(),
      halfmoveClock: 0,
      fullmoveNumber: 1,
      positionCounts: const {},
      history: const [],
      result: ChessResult.playing,
    );
    return state.copyWith(positionCounts: {state.positionKey(): 1});
  }

  final List<ChessPiece?> board;
  final ChessColor turn;
  final CastlingRights castling;
  final int? enPassantTarget;
  final int halfmoveClock;
  final int fullmoveNumber;
  final Map<String, int> positionCounts;
  final List<ChessPly> history;
  final ChessResult result;
  final String? resultReason;
  final ChessMove? lastMove;

  ChessState copyWith({
    List<ChessPiece?>? board,
    ChessColor? turn,
    CastlingRights? castling,
    int? enPassantTarget,
    bool clearEnPassant = false,
    int? halfmoveClock,
    int? fullmoveNumber,
    Map<String, int>? positionCounts,
    List<ChessPly>? history,
    ChessResult? result,
    String? resultReason,
    bool clearResultReason = false,
    ChessMove? lastMove,
  }) =>
      ChessState(
        board: board ?? this.board,
        turn: turn ?? this.turn,
        castling: castling ?? this.castling,
        enPassantTarget: clearEnPassant ? null : enPassantTarget ?? this.enPassantTarget,
        halfmoveClock: halfmoveClock ?? this.halfmoveClock,
        fullmoveNumber: fullmoveNumber ?? this.fullmoveNumber,
        positionCounts: positionCounts ?? this.positionCounts,
        history: history ?? this.history,
        result: result ?? this.result,
        resultReason: clearResultReason ? null : resultReason ?? this.resultReason,
        lastMove: lastMove ?? this.lastMove,
      );

  String positionKey() {
    final rows = <String>[];
    for (var row = 0; row < 8; row++) {
      var empty = 0;
      final text = StringBuffer();
      for (var col = 0; col < 8; col++) {
        final piece = board[row * 8 + col];
        if (piece == null) {
          empty++;
        } else {
          if (empty > 0) {text.write(empty);}
          empty = 0;
          text.write(piece.fenChar);
        }
      }
      if (empty > 0) {text.write(empty);}
      rows.add(text.toString());
    }
    return '${rows.join('/')} ${turn == ChessColor.white ? 'w' : 'b'} ${castling.fen} ${enPassantTarget == null ? '-' : ChessEngine.squareName(enPassantTarget!)}';
  }

  String get fen => '${positionKey()} $halfmoveClock $fullmoveNumber';

  Map<String, Object?> toJson() => {
        'board': board.map((piece) => piece?.toJson()).toList(),
        'turn': turn.name,
        'castling': castling.toJson(),
        'enPassantTarget': enPassantTarget,
        'halfmoveClock': halfmoveClock,
        'fullmoveNumber': fullmoveNumber,
        'positionCounts': positionCounts,
        'history': history.map((e) => e.toJson()).toList(),
        'result': result.name,
        'resultReason': resultReason,
        'lastMove': lastMove?.toJson(),
      };

  factory ChessState.fromJson(Map<String, dynamic> json) => ChessState(
        board: (json['board'] as List)
            .map((piece) => piece == null ? null : ChessPiece.fromJson(piece as Map<String, dynamic>))
            .toList(),
        turn: ChessColor.values.byName(json['turn'] as String),
        castling: CastlingRights.fromJson(json['castling'] as Map<String, dynamic>),
        enPassantTarget: json['enPassantTarget'] as int?,
        halfmoveClock: json['halfmoveClock'] as int,
        fullmoveNumber: json['fullmoveNumber'] as int,
        positionCounts: (json['positionCounts'] as Map<String, dynamic>).map((k, v) => MapEntry(k, v as int)),
        history: (json['history'] as List).map((e) => ChessPly.fromJson(e as Map<String, dynamic>)).toList(),
        result: ChessResult.values.byName(json['result'] as String),
        resultReason: json['resultReason'] as String?,
        lastMove: json['lastMove'] == null ? null : ChessMove.fromJson(json['lastMove'] as Map<String, dynamic>),
      );

  @override
  String serialize() => jsonEncode(toJson());
  @override
  String stateHash() => sha256.convert(utf8.encode(serialize())).toString();
}

class ChessEngine implements GameEngine<ChessState, ChessMove> {
  ChessEngine([ChessState? initial]) : _state = initial ?? ChessState.initial();

  ChessState _state;
  final List<ChessState> _undo = [];

  @override
  ChessState get state => _state;

  static int index(int row, int col) => row * 8 + col;
  static int rowOf(int square) => square ~/ 8;
  static int colOf(int square) => square % 8;
  static bool inside(int row, int col) => row >= 0 && row < 8 && col >= 0 && col < 8;
  static String squareName(int square) => '${'abcdefgh'[colOf(square)]}${8 - rowOf(square)}';

  static int squareFromName(String name) {
    if (name.length != 2) {throw FormatException('Invalid square: $name');}
    final col = 'abcdefgh'.indexOf(name[0]);
    final rank = int.parse(name[1]);
    if (col < 0 || rank < 1 || rank > 8) {throw FormatException('Invalid square: $name');}
    return index(8 - rank, col);
  }

  @override
  List<ChessMove> legalMoves() => _legalMovesFor(_state, _state.turn);

  List<ChessMove> legalMovesFrom(int square) => legalMoves().where((move) => move.from == square).toList();

  @override
  bool isLegal(ChessMove move) => legalMoves().any((candidate) => candidate.sameAs(move));

  @override
  ChessState apply(ChessMove move) {
    final legal = legalMoves();
    ChessMove? selected;
    for (final candidate in legal) {
      if (candidate.sameAs(move)) {
        selected = candidate;
        break;
      }
    }
    if (selected == null) {throw StateError('Illegal chess move: ${move.coordinate}');}
    _undo.add(_state);
    final sanBase = _sanBase(_state, selected, legal);
    var next = _applyUnchecked(_state, selected);
    final counts = Map<String, int>.from(next.positionCounts);
    final key = next.positionKey();
    counts[key] = (counts[key] ?? 0) + 1;
    next = next.copyWith(positionCounts: counts);

    final replyMoves = _legalMovesFor(next, next.turn);
    final inCheck = isKingInCheck(next, next.turn);
    var suffix = '';
    var result = ChessResult.playing;
    String? reason;

    if (replyMoves.isEmpty && inCheck) {
      suffix = '#';
      result = next.turn == ChessColor.white ? ChessResult.blackWin : ChessResult.whiteWin;
      reason = 'checkmate';
    } else if (replyMoves.isEmpty) {
      result = ChessResult.draw;
      reason = 'stalemate';
    } else if (next.halfmoveClock >= 100) {
      result = ChessResult.draw;
      reason = 'fifty-move rule';
    } else if ((counts[key] ?? 0) >= 3) {
      result = ChessResult.draw;
      reason = 'threefold repetition';
    } else if (_insufficientMaterial(next)) {
      result = ChessResult.draw;
      reason = 'insufficient material';
    } else if (inCheck) {
      suffix = '+';
    }

    final history = [...next.history, ChessPly(move: selected, san: '$sanBase$suffix')];
    _state = next.copyWith(history: history, result: result, resultReason: reason, lastMove: selected);
    return _state;
  }

  ChessState _applyUnchecked(ChessState state, ChessMove move) {
    final board = List<ChessPiece?>.from(state.board);
    final moving = board[move.from]!;
    final captured = move.isEnPassant
        ? board[index(rowOf(move.from), colOf(move.to))]
        : board[move.to];
    board[move.from] = null;

    if (move.isEnPassant) {
      board[index(rowOf(move.from), colOf(move.to))] = null;
    }

    if (move.isCastle) {
      final row = rowOf(move.from);
      if (colOf(move.to) == 6) {
        board[index(row, 5)] = board[index(row, 7)];
        board[index(row, 7)] = null;
      } else {
        board[index(row, 3)] = board[index(row, 0)];
        board[index(row, 0)] = null;
      }
    }

    board[move.to] = move.promotion == null ? moving : ChessPiece(move.promotion!, moving.color);

    var rights = state.castling;
    if (moving.type == ChessPieceType.king) {
      rights = moving.color == ChessColor.white
          ? rights.copyWith(whiteKingSide: false, whiteQueenSide: false)
          : rights.copyWith(blackKingSide: false, blackQueenSide: false);
    }
    if (moving.type == ChessPieceType.rook) {rights = _removeRookRight(rights, move.from);}
    if (captured?.type == ChessPieceType.rook) {rights = _removeRookRight(rights, move.to);}

    int? enPassant;
    if (moving.type == ChessPieceType.pawn && (rowOf(move.to) - rowOf(move.from)).abs() == 2) {
      enPassant = index((rowOf(move.from) + rowOf(move.to)) ~/ 2, colOf(move.from));
    }

    final isPawnOrCapture = moving.type == ChessPieceType.pawn || captured != null;
    return state.copyWith(
      board: board,
      turn: state.turn.opposite,
      castling: rights,
      enPassantTarget: enPassant,
      clearEnPassant: enPassant == null,
      halfmoveClock: isPawnOrCapture ? 0 : state.halfmoveClock + 1,
      fullmoveNumber: state.fullmoveNumber + (state.turn == ChessColor.black ? 1 : 0),
      result: ChessResult.playing,
      clearResultReason: true,
    );
  }

  CastlingRights _removeRookRight(CastlingRights rights, int square) {
    return switch (square) {
      56 => rights.copyWith(whiteQueenSide: false),
      63 => rights.copyWith(whiteKingSide: false),
      0 => rights.copyWith(blackQueenSide: false),
      7 => rights.copyWith(blackKingSide: false),
      _ => rights,
    };
  }

  List<ChessMove> _legalMovesFor(ChessState state, ChessColor color) {
    if (state.result != ChessResult.playing && identical(state, _state)) {return const [];}
    final pseudo = _pseudoMoves(state, color);
    return pseudo.where((move) {
      final next = _applyUnchecked(state.copyWith(turn: color, result: ChessResult.playing), move);
      return !isKingInCheck(next, color);
    }).toList();
  }

  List<ChessMove> _pseudoMoves(ChessState state, ChessColor color) {
    final moves = <ChessMove>[];
    for (var from = 0; from < 64; from++) {
      final piece = state.board[from];
      if (piece == null || piece.color != color) {continue;}
      final row = rowOf(from);
      final col = colOf(from);
      switch (piece.type) {
        case ChessPieceType.pawn:
          _pawnMoves(state, piece, from, row, col, moves);
          break;
        case ChessPieceType.knight:
          for (final delta in const [(-2, -1), (-2, 1), (-1, -2), (-1, 2), (1, -2), (1, 2), (2, -1), (2, 1)]) {
            _addStep(state, piece, from, row + delta.$1, col + delta.$2, moves);
          }
          break;
        case ChessPieceType.bishop:
          _slider(state, piece, from, const [(-1, -1), (-1, 1), (1, -1), (1, 1)], moves);
          break;
        case ChessPieceType.rook:
          _slider(state, piece, from, const [(-1, 0), (1, 0), (0, -1), (0, 1)], moves);
          break;
        case ChessPieceType.queen:
          _slider(state, piece, from, const [(-1, -1), (-1, 1), (1, -1), (1, 1), (-1, 0), (1, 0), (0, -1), (0, 1)], moves);
          break;
        case ChessPieceType.king:
          for (var dr = -1; dr <= 1; dr++) {
            for (var dc = -1; dc <= 1; dc++) {
              if (dr != 0 || dc != 0) {_addStep(state, piece, from, row + dr, col + dc, moves);}
            }
          }
          _castleMoves(state, piece, from, moves);
          break;
      }
    }
    return moves;
  }

  void _pawnMoves(ChessState state, ChessPiece piece, int from, int row, int col, List<ChessMove> moves) {
    final direction = piece.color.pawnDirection;
    final oneRow = row + direction;
    if (inside(oneRow, col) && state.board[index(oneRow, col)] == null) {
      _addPawnMove(from, index(oneRow, col), oneRow == piece.color.promotionRow, moves);
      final twoRow = row + direction * 2;
      if (row == piece.color.homePawnRow && state.board[index(twoRow, col)] == null) {
        moves.add(ChessMove(from: from, to: index(twoRow, col)));
      }
    }
    for (final dc in const [-1, 1]) {
      final targetRow = row + direction;
      final targetCol = col + dc;
      if (!inside(targetRow, targetCol)) {continue;}
      final target = index(targetRow, targetCol);
      final occupant = state.board[target];
      if (occupant != null && occupant.color != piece.color) {
        _addPawnMove(from, target, targetRow == piece.color.promotionRow, moves);
      } else if (state.enPassantTarget == target) {
        final capturedSquare = index(row, targetCol);
        final capturedPawn = state.board[capturedSquare];
        if (capturedPawn?.type == ChessPieceType.pawn &&
            capturedPawn?.color == piece.color.opposite) {
          moves.add(ChessMove(from: from, to: target, isEnPassant: true));
        }
      }
    }
  }

  void _addPawnMove(int from, int to, bool promotion, List<ChessMove> moves) {
    if (!promotion) {
      moves.add(ChessMove(from: from, to: to));
      return;
    }
    for (final type in const [ChessPieceType.queen, ChessPieceType.rook, ChessPieceType.bishop, ChessPieceType.knight]) {
      moves.add(ChessMove(from: from, to: to, promotion: type));
    }
  }

  void _addStep(ChessState state, ChessPiece piece, int from, int row, int col, List<ChessMove> moves) {
    if (!inside(row, col)) {return;}
    final target = index(row, col);
    final occupant = state.board[target];
    if (occupant == null || occupant.color != piece.color) {moves.add(ChessMove(from: from, to: target));}
  }

  void _slider(
    ChessState state,
    ChessPiece piece,
    int from,
    List<(int, int)> directions,
    List<ChessMove> moves,
  ) {
    for (final direction in directions) {
      var row = rowOf(from) + direction.$1;
      var col = colOf(from) + direction.$2;
      while (inside(row, col)) {
        final target = index(row, col);
        final occupant = state.board[target];
        if (occupant == null) {
          moves.add(ChessMove(from: from, to: target));
        } else {
          if (occupant.color != piece.color) {moves.add(ChessMove(from: from, to: target));}
          break;
        }
        row += direction.$1;
        col += direction.$2;
      }
    }
  }

  void _castleMoves(ChessState state, ChessPiece king, int from, List<ChessMove> moves) {
    final row = king.color == ChessColor.white ? 7 : 0;
    if (from != index(row, 4) || isKingInCheck(state, king.color)) {return;}
    final enemy = king.color.opposite;
    final kingSide = king.color == ChessColor.white ? state.castling.whiteKingSide : state.castling.blackKingSide;
    final queenSide = king.color == ChessColor.white ? state.castling.whiteQueenSide : state.castling.blackQueenSide;

    if (kingSide &&
        state.board[index(row, 5)] == null &&
        state.board[index(row, 6)] == null &&
        state.board[index(row, 7)]?.type == ChessPieceType.rook &&
        state.board[index(row, 7)]?.color == king.color &&
        !isSquareAttacked(state, index(row, 5), enemy) &&
        !isSquareAttacked(state, index(row, 6), enemy)) {
      moves.add(ChessMove(from: from, to: index(row, 6), isCastle: true));
    }
    if (queenSide &&
        state.board[index(row, 1)] == null &&
        state.board[index(row, 2)] == null &&
        state.board[index(row, 3)] == null &&
        state.board[index(row, 0)]?.type == ChessPieceType.rook &&
        state.board[index(row, 0)]?.color == king.color &&
        !isSquareAttacked(state, index(row, 3), enemy) &&
        !isSquareAttacked(state, index(row, 2), enemy)) {
      moves.add(ChessMove(from: from, to: index(row, 2), isCastle: true));
    }
  }

  bool isKingInCheck(ChessState state, ChessColor color) {
    final king = state.board.indexWhere((piece) => piece?.type == ChessPieceType.king && piece?.color == color);
    if (king < 0) {return true;}
    return isSquareAttacked(state, king, color.opposite);
  }

  bool isSquareAttacked(ChessState state, int square, ChessColor byColor) {
    final row = rowOf(square);
    final col = colOf(square);

    final pawnSourceRow = row - byColor.pawnDirection;
    for (final dc in const [-1, 1]) {
      final sourceCol = col + dc;
      if (inside(pawnSourceRow, sourceCol)) {
        final piece = state.board[index(pawnSourceRow, sourceCol)];
        if (piece?.color == byColor && piece?.type == ChessPieceType.pawn) {return true;}
      }
    }

    for (final delta in const [(-2, -1), (-2, 1), (-1, -2), (-1, 2), (1, -2), (1, 2), (2, -1), (2, 1)]) {
      final r = row + delta.$1;
      final c = col + delta.$2;
      if (inside(r, c)) {
        final piece = state.board[index(r, c)];
        if (piece?.color == byColor && piece?.type == ChessPieceType.knight) {return true;}
      }
    }

    if (_rayAttacked(state, square, byColor, const [(-1, -1), (-1, 1), (1, -1), (1, 1)], const [ChessPieceType.bishop, ChessPieceType.queen])) {return true;}
    if (_rayAttacked(state, square, byColor, const [(-1, 0), (1, 0), (0, -1), (0, 1)], const [ChessPieceType.rook, ChessPieceType.queen])) {return true;}

    for (var dr = -1; dr <= 1; dr++) {
      for (var dc = -1; dc <= 1; dc++) {
        if (dr == 0 && dc == 0) {continue;}
        final r = row + dr;
        final c = col + dc;
        if (inside(r, c)) {
          final piece = state.board[index(r, c)];
          if (piece?.color == byColor && piece?.type == ChessPieceType.king) {return true;}
        }
      }
    }
    return false;
  }

  bool _rayAttacked(
    ChessState state,
    int square,
    ChessColor byColor,
    List<(int, int)> directions,
    List<ChessPieceType> attackers,
  ) {
    for (final direction in directions) {
      var row = rowOf(square) + direction.$1;
      var col = colOf(square) + direction.$2;
      while (inside(row, col)) {
        final piece = state.board[index(row, col)];
        if (piece != null) {
          if (piece.color == byColor && attackers.contains(piece.type)) {return true;}
          break;
        }
        row += direction.$1;
        col += direction.$2;
      }
    }
    return false;
  }

  bool _insufficientMaterial(ChessState state) {
    final pieces = state.board.whereType<ChessPiece>().where((p) => p.type != ChessPieceType.king).toList();
    if (pieces.isEmpty) {return true;}
    if (pieces.length == 1 && (pieces.single.type == ChessPieceType.bishop || pieces.single.type == ChessPieceType.knight)) {return true;}
    if (pieces.length == 2 && pieces.every((p) => p.type == ChessPieceType.bishop)) {
      final bishopSquares = <int>[];
      for (var i = 0; i < 64; i++) {
        if (state.board[i]?.type == ChessPieceType.bishop) {bishopSquares.add(i);}
      }
      return bishopSquares.length == 2 &&
          ((rowOf(bishopSquares[0]) + colOf(bishopSquares[0])) % 2 ==
              (rowOf(bishopSquares[1]) + colOf(bishopSquares[1])) % 2);
    }
    return false;
  }

  String _sanBase(ChessState state, ChessMove move, List<ChessMove> legal) {
    final piece = state.board[move.from]!;
    if (move.isCastle) {return colOf(move.to) == 6 ? 'O-O' : 'O-O-O';}
    final target = state.board[move.to];
    final isCapture = target != null || move.isEnPassant;
    final buffer = StringBuffer();
    if (piece.type == ChessPieceType.pawn) {
      if (isCapture) {buffer.write('abcdefgh'[colOf(move.from)]);}
    } else {
      buffer.write(switch (piece.type) {
        ChessPieceType.knight => 'N',
        ChessPieceType.bishop => 'B',
        ChessPieceType.rook => 'R',
        ChessPieceType.queen => 'Q',
        ChessPieceType.king => 'K',
        ChessPieceType.pawn => '',
      });
      final ambiguous = legal.where((candidate) {
        if (candidate.to != move.to || candidate.from == move.from) {return false;}
        final other = state.board[candidate.from];
        return other?.type == piece.type && other?.color == piece.color;
      }).toList();
      if (ambiguous.isNotEmpty) {
        final sameFile = ambiguous.any((m) => colOf(m.from) == colOf(move.from));
        final sameRank = ambiguous.any((m) => rowOf(m.from) == rowOf(move.from));
        if (!sameFile) {
          buffer.write('abcdefgh'[colOf(move.from)]);
        } else if (!sameRank) {
          buffer.write(8 - rowOf(move.from));
        } else {
          buffer.write(squareName(move.from));
        }
      }
    }
    if (isCapture) {buffer.write('x');}
    buffer.write(squareName(move.to));
    if (move.promotion != null) {
      final promotionLetter = switch (move.promotion!) {
        ChessPieceType.queen => 'Q',
        ChessPieceType.rook => 'R',
        ChessPieceType.bishop => 'B',
        ChessPieceType.knight => 'N',
        _ => 'Q',
      };
      buffer.write('=$promotionLetter');
    }
    return buffer.toString();
  }

  String exportPgn({String white = 'White', String black = 'Black'}) {
    final resultToken = switch (_state.result) {
      ChessResult.whiteWin => '1-0',
      ChessResult.blackWin => '0-1',
      ChessResult.draw => '1/2-1/2',
      ChessResult.playing => '*',
    };
    final body = StringBuffer();
    for (var i = 0; i < _state.history.length; i++) {
      if (i.isEven) {body.write('${i ~/ 2 + 1}. ');}
      body.write('${_state.history[i].san} ');
    }
    body.write(resultToken);
    return '[Event "Nostalgia Club Local Match"]\n[White "$white"]\n[Black "$black"]\n[Result "$resultToken"]\n\n${body.toString().trim()}';
  }

  static ChessState fromFen(String fen) {
    final parts = fen.trim().split(RegExp(r'\s+'));
    if (parts.length < 4) {throw const FormatException('FEN requires at least four fields');}
    final board = List<ChessPiece?>.filled(64, null);
    final rows = parts[0].split('/');
    if (rows.length != 8) {throw const FormatException('FEN board must have eight rows');}
    for (var row = 0; row < 8; row++) {
      var col = 0;
      for (final rune in rows[row].runes) {
        final char = String.fromCharCode(rune);
        final empty = int.tryParse(char);
        if (empty != null) {
          col += empty;
          continue;
        }
        final color = char == char.toUpperCase() ? ChessColor.white : ChessColor.black;
        final type = switch (char.toLowerCase()) {
          'p' => ChessPieceType.pawn,
          'n' => ChessPieceType.knight,
          'b' => ChessPieceType.bishop,
          'r' => ChessPieceType.rook,
          'q' => ChessPieceType.queen,
          'k' => ChessPieceType.king,
          _ => throw FormatException('Unknown FEN piece: $char'),
        };
        board[index(row, col)] = ChessPiece(type, color);
        col++;
      }
      if (col != 8) {throw const FormatException('Invalid FEN row width');}
    }
    final rightsText = parts[2];
    final state = ChessState(
      board: board,
      turn: parts[1] == 'w' ? ChessColor.white : ChessColor.black,
      castling: CastlingRights(
        whiteKingSide: rightsText.contains('K'),
        whiteQueenSide: rightsText.contains('Q'),
        blackKingSide: rightsText.contains('k'),
        blackQueenSide: rightsText.contains('q'),
      ),
      enPassantTarget: parts[3] == '-' ? null : squareFromName(parts[3]),
      halfmoveClock: parts.length > 4 ? int.parse(parts[4]) : 0,
      fullmoveNumber: parts.length > 5 ? int.parse(parts[5]) : 1,
      positionCounts: const {},
      history: const [],
      result: ChessResult.playing,
    );
    return state.copyWith(positionCounts: {state.positionKey(): 1});
  }

  @override
  ChessState undo() {
    if (_undo.isEmpty) {throw StateError('Nothing to undo');}
    _state = _undo.removeLast();
    return _state;
  }

  @override
  void restore(ChessState state) {
    _undo.clear();
    _state = state;
  }
}

class ChessBot implements GameBot<ChessState, ChessMove> {
  const ChessBot();

  @override
  Future<ChessMove> chooseMove(ChessState state, BotDifficulty difficulty) =>
      Isolate.run(() => _chooseSync(state, difficulty));

  static ChessMove _chooseSync(ChessState state, BotDifficulty difficulty) {
    final engine = ChessEngine(state);
    final legal = engine.legalMoves();
    if (legal.isEmpty) {throw StateError('No legal chess move');}
    if (difficulty == BotDifficulty.easy) {
      return legal[Random(state.stateHash().hashCode).nextInt(legal.length)];
    }
    var best = legal.first;
    var bestScore = -100000;
    final depth = difficulty == BotDifficulty.hard ? 2 : 1;
    for (final move in legal) {
      final nextEngine = ChessEngine(state)..apply(move);
      final score = -_search(nextEngine.state, depth - 1, state.turn.opposite);
      if (score > bestScore) {
        bestScore = score;
        best = move;
      }
    }
    return best;
  }

  static int _search(ChessState state, int depth, ChessColor perspective) {
    if (depth <= 0 || state.result != ChessResult.playing) {return _evaluate(state, perspective);}
    final moves = ChessEngine(state).legalMoves();
    if (moves.isEmpty) {return _evaluate(state, perspective);}
    var best = -100000;
    for (final move in moves.take(18)) {
      final child = ChessEngine(state)..apply(move);
      final score = -_search(child.state, depth - 1, perspective.opposite);
      if (score > best) {best = score;}
    }
    return best;
  }

  static int _evaluate(ChessState state, ChessColor perspective) {
    if (state.result == ChessResult.whiteWin) {return perspective == ChessColor.white ? 100000 : -100000;}
    if (state.result == ChessResult.blackWin) {return perspective == ChessColor.black ? 100000 : -100000;}
    if (state.result == ChessResult.draw) {return 0;}
    const values = {
      ChessPieceType.pawn: 100,
      ChessPieceType.knight: 320,
      ChessPieceType.bishop: 330,
      ChessPieceType.rook: 500,
      ChessPieceType.queen: 900,
      ChessPieceType.king: 20000,
    };
    var score = 0;
    for (final piece in state.board.whereType<ChessPiece>()) {
      score += (piece.color == perspective ? 1 : -1) * values[piece.type]!;
    }
    return score;
  }
}
