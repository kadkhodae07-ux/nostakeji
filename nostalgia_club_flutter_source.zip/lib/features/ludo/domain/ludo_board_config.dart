class BoardPoint {
  const BoardPoint(this.x, this.y);
  final int x;
  final int y;
}

abstract final class LudoBoardConfig {
  static const startOffsets = [0, 13, 26, 39];
  static const safeTrackPositions = {0, 8, 13, 21, 26, 34, 39, 47};

  static const commonTrack = <BoardPoint>[
    BoardPoint(6, 13), BoardPoint(6, 12), BoardPoint(6, 11), BoardPoint(6, 10), BoardPoint(6, 9), BoardPoint(5, 8),
    BoardPoint(4, 8), BoardPoint(3, 8), BoardPoint(2, 8), BoardPoint(1, 8), BoardPoint(0, 8), BoardPoint(0, 7),
    BoardPoint(0, 6), BoardPoint(1, 6), BoardPoint(2, 6), BoardPoint(3, 6), BoardPoint(4, 6), BoardPoint(5, 6),
    BoardPoint(6, 5), BoardPoint(6, 4), BoardPoint(6, 3), BoardPoint(6, 2), BoardPoint(6, 1), BoardPoint(6, 0),
    BoardPoint(7, 0), BoardPoint(8, 0), BoardPoint(8, 1), BoardPoint(8, 2), BoardPoint(8, 3), BoardPoint(8, 4),
    BoardPoint(8, 5), BoardPoint(9, 6), BoardPoint(10, 6), BoardPoint(11, 6), BoardPoint(12, 6), BoardPoint(13, 6),
    BoardPoint(14, 6), BoardPoint(14, 7), BoardPoint(14, 8), BoardPoint(13, 8), BoardPoint(12, 8), BoardPoint(11, 8),
    BoardPoint(10, 8), BoardPoint(9, 8), BoardPoint(8, 9), BoardPoint(8, 10), BoardPoint(8, 11), BoardPoint(8, 12),
    BoardPoint(8, 13), BoardPoint(8, 14), BoardPoint(7, 14), BoardPoint(6, 14),
  ];

  static const homeLanes = <List<BoardPoint>>[
    [BoardPoint(7, 13), BoardPoint(7, 12), BoardPoint(7, 11), BoardPoint(7, 10), BoardPoint(7, 9), BoardPoint(7, 8)],
    [BoardPoint(1, 7), BoardPoint(2, 7), BoardPoint(3, 7), BoardPoint(4, 7), BoardPoint(5, 7), BoardPoint(6, 7)],
    [BoardPoint(7, 1), BoardPoint(7, 2), BoardPoint(7, 3), BoardPoint(7, 4), BoardPoint(7, 5), BoardPoint(7, 6)],
    [BoardPoint(13, 7), BoardPoint(12, 7), BoardPoint(11, 7), BoardPoint(10, 7), BoardPoint(9, 7), BoardPoint(8, 7)],
  ];
}
