import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:nostalgia_club/core/game/deterministic_random.dart';
import 'package:nostalgia_club/core/game/game_models.dart';
import 'package:nostalgia_club/features/ludo/domain/ludo_board_config.dart';

enum LudoStatus { waitingForRoll, waitingForToken, finished }

class LudoRules {
  const LudoRules({
    this.exitOnSix = true,
    this.extraTurnOnSix = true,
    this.extraTurnOnCapture = true,
    this.threeSixesLoseTurn = true,
    this.exactFinish = true,
  });

  final bool exitOnSix;
  final bool extraTurnOnSix;
  final bool extraTurnOnCapture;
  final bool threeSixesLoseTurn;
  final bool exactFinish;
}

class LudoToken {
  const LudoToken({required this.player, required this.index, required this.steps});
  final int player;
  final int index;
  final int steps;

  bool get inBase => steps < 0;
  bool get completed => steps == 58;
  bool get onCommonTrack => steps >= 0 && steps <= 51;

  LudoToken copyWith({int? steps}) => LudoToken(player: player, index: index, steps: steps ?? this.steps);

  Map<String, Object?> toJson() => {'player': player, 'index': index, 'steps': steps};
  factory LudoToken.fromJson(Map<String, dynamic> json) => LudoToken(
        player: json['player'] as int,
        index: json['index'] as int,
        steps: json['steps'] as int,
      );
}

class LudoMove implements GameMove {
  const LudoMove.roll() : tokenIndex = null;
  const LudoMove.token(this.tokenIndex);
  final int? tokenIndex;
  bool get isRoll => tokenIndex == null;
}

class LudoState implements SerializableGameState {
  const LudoState({
    required this.players,
    required this.tokens,
    required this.currentPlayer,
    required this.seed,
    required this.status,
    required this.rankings,
    required this.consecutiveSixes,
    this.dice,
    this.lastCaptured,
  });

  factory LudoState.initial({required int players, int seed = 606}) {
    if (players < 2 || players > 4) {throw ArgumentError('Players must be 2 to 4');}
    return LudoState(
      players: players,
      tokens: [
        for (var player = 0; player < players; player++)
          for (var index = 0; index < 4; index++) LudoToken(player: player, index: index, steps: -1),
      ],
      currentPlayer: 0,
      seed: seed,
      status: LudoStatus.waitingForRoll,
      rankings: const [],
      consecutiveSixes: 0,
    );
  }

  final int players;
  final List<LudoToken> tokens;
  final int currentPlayer;
  final int seed;
  final LudoStatus status;
  final List<int> rankings;
  final int consecutiveSixes;
  final int? dice;
  final int? lastCaptured;

  LudoState copyWith({
    List<LudoToken>? tokens,
    int? currentPlayer,
    int? seed,
    LudoStatus? status,
    List<int>? rankings,
    int? consecutiveSixes,
    int? dice,
    bool clearDice = false,
    int? lastCaptured,
    bool clearCaptured = false,
  }) =>
      LudoState(
        players: players,
        tokens: tokens ?? this.tokens,
        currentPlayer: currentPlayer ?? this.currentPlayer,
        seed: seed ?? this.seed,
        status: status ?? this.status,
        rankings: rankings ?? this.rankings,
        consecutiveSixes: consecutiveSixes ?? this.consecutiveSixes,
        dice: clearDice ? null : dice ?? this.dice,
        lastCaptured: clearCaptured ? null : lastCaptured ?? this.lastCaptured,
      );

  Map<String, Object?> toJson() => {
        'players': players,
        'tokens': tokens.map((e) => e.toJson()).toList(),
        'currentPlayer': currentPlayer,
        'seed': seed,
        'status': status.name,
        'rankings': rankings,
        'consecutiveSixes': consecutiveSixes,
        'dice': dice,
        'lastCaptured': lastCaptured,
      };

  factory LudoState.fromJson(Map<String, dynamic> json) => LudoState(
        players: json['players'] as int,
        tokens: (json['tokens'] as List).map((e) => LudoToken.fromJson(e as Map<String, dynamic>)).toList(),
        currentPlayer: json['currentPlayer'] as int,
        seed: json['seed'] as int,
        status: LudoStatus.values.byName(json['status'] as String),
        rankings: (json['rankings'] as List).cast<int>(),
        consecutiveSixes: json['consecutiveSixes'] as int,
        dice: json['dice'] as int?,
        lastCaptured: json['lastCaptured'] as int?,
      );

  @override
  String serialize() => jsonEncode(toJson());
  @override
  String stateHash() => sha256.convert(utf8.encode(serialize())).toString();
}

class LudoEngine implements GameEngine<LudoState, LudoMove> {
  LudoEngine({LudoState? initial, this.rules = const LudoRules()})
      : _state = initial ?? LudoState.initial(players: 2);

  LudoState _state;
  final LudoRules rules;
  final List<LudoState> _history = [];

  @override
  LudoState get state => _state;

  List<LudoToken> tokensForPlayer(int player) => _state.tokens.where((t) => t.player == player).toList();

  @override
  List<LudoMove> legalMoves() {
    if (_state.status == LudoStatus.finished) {return const [];}
    if (_state.status == LudoStatus.waitingForRoll) {return const [LudoMove.roll()];}
    final dice = _state.dice!;
    return [
      for (final token in tokensForPlayer(_state.currentPlayer))
        if (_canMove(token, dice)) LudoMove.token(token.index),
    ];
  }

  bool _canMove(LudoToken token, int dice) {
    if (token.completed) {return false;}
    if (token.inBase) {return !rules.exitOnSix || dice == 6;}
    final destination = token.steps + dice;
    return rules.exactFinish ? destination <= 58 : true;
  }

  @override
  bool isLegal(LudoMove move) => legalMoves().any((m) => m.tokenIndex == move.tokenIndex && m.isRoll == move.isRoll);

  @override
  LudoState apply(LudoMove move) {
    if (!isLegal(move)) {throw StateError('Illegal Ludo move');}
    _history.add(_state);
    if (move.isRoll) {return _roll();}
    return _moveToken(move.tokenIndex!);
  }

  LudoState _roll() {
    final rng = DeterministicRandom(_state.seed);
    final dice = rng.nextInt(6) + 1;
    final sixes = dice == 6 ? _state.consecutiveSixes + 1 : 0;
    if (rules.threeSixesLoseTurn && sixes >= 3) {
      _state = _state.copyWith(
        seed: rng.state,
        currentPlayer: _nextPlayer(_state.currentPlayer),
        status: LudoStatus.waitingForRoll,
        consecutiveSixes: 0,
        dice: dice,
        clearCaptured: true,
      );
      return _state;
    }

    _state = _state.copyWith(
      seed: rng.state,
      dice: dice,
      consecutiveSixes: sixes,
      status: LudoStatus.waitingForToken,
      clearCaptured: true,
    );

    if (legalMoves().isEmpty) {
      _state = _state.copyWith(
        currentPlayer: _nextPlayer(_state.currentPlayer),
        status: LudoStatus.waitingForRoll,
        consecutiveSixes: 0,
        clearDice: true,
      );
    }
    return _state;
  }

  LudoState _moveToken(int tokenIndex) {
    final dice = _state.dice!;
    final tokens = List<LudoToken>.from(_state.tokens);
    final listIndex = tokens.indexWhere((t) => t.player == _state.currentPlayer && t.index == tokenIndex);
    final token = tokens[listIndex];
    final newSteps = token.inBase ? 0 : (token.steps + dice).clamp(0, 58).toInt();
    tokens[listIndex] = token.copyWith(steps: newSteps);

    int? captured;
    if (newSteps >= 0 && newSteps <= 51) {
      final global = globalTrackPosition(_state.currentPlayer, newSteps);
      if (!LudoBoardConfig.safeTrackPositions.contains(global)) {
        for (var i = 0; i < tokens.length; i++) {
          final other = tokens[i];
          if (other.player == _state.currentPlayer || !other.onCommonTrack) {continue;}
          if (globalTrackPosition(other.player, other.steps) == global) {
            captured = other.player;
            tokens[i] = other.copyWith(steps: -1);
          }
        }
      }
    }

    final rankings = List<int>.from(_state.rankings);
    final allFinished = tokens.where((t) => t.player == _state.currentPlayer).every((t) => t.completed);
    if (allFinished && !rankings.contains(_state.currentPlayer)) {rankings.add(_state.currentPlayer);}
    var status = LudoStatus.waitingForRoll;
    if (rankings.length == _state.players - 1) {
      final last = [for (var p = 0; p < _state.players; p++) if (!rankings.contains(p)) p].single;
      rankings.add(last);
      status = LudoStatus.finished;
    }

    final getsExtra = status != LudoStatus.finished &&
        ((dice == 6 && rules.extraTurnOnSix) || (captured != null && rules.extraTurnOnCapture));
    final next = getsExtra ? _state.currentPlayer : _nextPlayer(_state.currentPlayer, rankings: rankings);

    _state = _state.copyWith(
      tokens: tokens,
      rankings: rankings,
      currentPlayer: next,
      status: status,
      consecutiveSixes: getsExtra && dice == 6 ? _state.consecutiveSixes : 0,
      clearDice: true,
      lastCaptured: captured,
    );
    return _state;
  }

  int _nextPlayer(int current, {List<int>? rankings}) {
    final ranked = rankings ?? _state.rankings;
    var next = current;
    do {
      next = (next + 1) % _state.players;
    } while (ranked.contains(next) && ranked.length < _state.players);
    return next;
  }

  static int globalTrackPosition(int player, int steps) => (LudoBoardConfig.startOffsets[player] + steps) % 52;

  int stackCount(int player, int steps) => _state.tokens.where((t) => t.player == player && t.steps == steps).length;

  @override
  LudoState undo() {
    if (_history.isEmpty) {throw StateError('Nothing to undo');}
    _state = _history.removeLast();
    return _state;
  }

  @override
  void restore(LudoState state) {
    _history.clear();
    _state = state;
  }
}

class LudoBot implements GameBot<LudoState, LudoMove> {
  const LudoBot();

  @override
  Future<LudoMove> chooseMove(LudoState state, BotDifficulty difficulty) async {
    final engine = LudoEngine(initial: state);
    final legal = engine.legalMoves();
    if (legal.isEmpty) {throw StateError('No legal move');}
    if (state.status == LudoStatus.waitingForRoll) {return const LudoMove.roll();}
    var best = legal.first;
    var bestScore = -10000;
    for (final move in legal) {
      final token = state.tokens.firstWhere((t) => t.player == state.currentPlayer && t.index == move.tokenIndex);
      var score = token.inBase ? 20 : token.steps;
      final destination = token.inBase ? 0 : token.steps + state.dice!;
      if (destination == 58) {score += 100;}
      if (destination <= 51 && LudoBoardConfig.safeTrackPositions.contains(LudoEngine.globalTrackPosition(state.currentPlayer, destination))) {
        score += 15;
      }
      if (difficulty == BotDifficulty.easy) {score %= 17;}
      if (score > bestScore) {
        bestScore = score;
        best = move;
      }
    }
    return best;
  }
}
