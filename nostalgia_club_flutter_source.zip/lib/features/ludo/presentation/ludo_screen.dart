import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nostalgia_club/core/audio/audio_service.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/storage/game_autosave_mixin.dart';
import 'package:nostalgia_club/core/storage/match_history_repository.dart';
import 'package:nostalgia_club/features/game_catalog/domain/game_setup.dart';
import 'package:nostalgia_club/features/ludo/domain/ludo_board_config.dart';
import 'package:nostalgia_club/features/ludo/domain/ludo_engine.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_button.dart';
import 'package:nostalgia_club/shared/widgets/game_screen_frame.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';

class LudoScreen extends ConsumerStatefulWidget {
  const LudoScreen({super.key});
  @override
  ConsumerState<LudoScreen> createState() => _LudoScreenState();
}

class _LudoScreenState extends ConsumerState<LudoScreen>
    with SingleTickerProviderStateMixin, GameAutosaveMixin<LudoScreen> {
  late LudoEngine _engine;
  late final GameSetupConfig _setup;
  static const _bot = LudoBot();
  late final AnimationController _moveAnimation;
  bool _botRunning = false;
  int? _movingPlayer;
  int? _movingTokenIndex;
  int? _movingFromSteps;
  int? _movingToSteps;
  DateTime _startedAt = DateTime.now();

  @override
  void initState() {
    super.initState();
    _setup = ref.read(gameSetupProvider.notifier).read('ludo');
    _engine = LudoEngine(
      initial: LudoState.initial(
        players: _setup.playerCount,
        seed: DateTime.now().millisecondsSinceEpoch,
      ),
    );
    _moveAnimation = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    Future<void>.microtask(_restore);
  }


  @override
  void dispose() {
    _moveAnimation.dispose();
    super.dispose();
  }

  Future<void> _restore() async {
    try {
      final raw = await loadAutosave('ludo');
      if (raw == null || !mounted) {return;}
      final restored = LudoState.fromJson(jsonDecode(raw) as Map<String, dynamic>);
      setState(() => _engine = LudoEngine(initial: restored));
      if (_setup.withBot && _engine.state.status != LudoStatus.finished && _engine.state.currentPlayer != 0) {
        unawaited(_runBotTurns());
      }
    } catch (_) {
      deleteAutosave('ludo');
    }
  }

  void _persist() {
    if (_engine.state.status == LudoStatus.finished) {
      deleteAutosave('ludo');
      recordMatchHistory(
        gameKey: 'ludo',
        state: _engine.state,
        result: 'رتبه‌بندی: ${_engine.state.rankings.map((player) => player + 1).join('، ')}',
        outcome: _engine.state.rankings.first == 0
            ? LocalMatchOutcome.win
            : LocalMatchOutcome.loss,
        opponent: _setup.withBot
            ? '${_engine.state.players - 1} ربات محلی'
            : '${_engine.state.players} بازیکن محلی',
        startedAt: _startedAt,
      );
    } else {
      persistAutosave('ludo', _engine.state);
    }
  }

  Future<void> _apply(LudoMove move, {bool automated = false}) async {
    if (_moveAnimation.isAnimating || (_botRunning && !automated)) {return;}
    if (!automated && _setup.withBot && _engine.state.currentPlayer != 0) {return;}
    if (!_engine.isLegal(move)) {return;}

    int? movingPlayer;
    int? movingTokenIndex;
    int? fromSteps;
    if (!move.isRoll) {
      movingPlayer = _engine.state.currentPlayer;
      movingTokenIndex = move.tokenIndex;
      fromSteps = _engine.state.tokens
          .firstWhere(
            (token) =>
                token.player == movingPlayer && token.index == movingTokenIndex,
          )
          .steps;
    }

    if (move.isRoll) {
      AudioService.instance.playDice();
    } else {
      AudioService.instance.playMove();
    }

    setState(() {
      _engine.apply(move);
      if (!move.isRoll) {
        _movingPlayer = movingPlayer;
        _movingTokenIndex = movingTokenIndex;
        _movingFromSteps = fromSteps;
        _movingToSteps = _engine.state.tokens
            .firstWhere(
              (token) =>
                  token.player == movingPlayer && token.index == movingTokenIndex,
            )
            .steps;
      }
    });
    _persist();

    if (!move.isRoll && _movingFromSteps != _movingToSteps) {
      final distance = (_movingToSteps! - _movingFromSteps!)
          .abs()
          .clamp(1, 8)
          .toInt();
      _moveAnimation.duration = Duration(milliseconds: 150 * distance + 220);
      try {
        await _moveAnimation.forward(from: 0).orCancel;
      } on TickerCanceled {
        return;
      } finally {
        if (mounted) {
          setState(() {
            _movingPlayer = null;
            _movingTokenIndex = null;
            _movingFromSteps = null;
            _movingToSteps = null;
          });
        }
      }
    }

    if (!automated && _setup.withBot && _engine.state.currentPlayer != 0) {
      await _runBotTurns();
    }
  }

  Future<void> _runBotTurns() async {
    if (_botRunning || !_setup.withBot) {return;}
    _botRunning = true;
    if (mounted) {setState(() {});}
    try {
      while (mounted &&
          _engine.state.status != LudoStatus.finished &&
          _engine.state.currentPlayer != 0) {
        await Future<void>.delayed(const Duration(milliseconds: 420));
        final move = await _bot.chooseMove(_engine.state, _setup.difficulty);
        await _apply(move, automated: true);
      }
    } finally {
      _botRunning = false;
      if (mounted) {setState(() {});}
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = _engine.state;
    final playerColor = _color(state.currentPlayer);
    final title = state.status == LudoStatus.finished
        ? 'مسابقه پایان یافت'
        : state.status == LudoStatus.waitingForRoll
            ? 'نوبت ${_playerName(state.currentPlayer)} برای تاس'
            : 'تاس ${state.dice} • یک مهره مجاز را انتخاب کنید';
    final tokenMoves = _engine.legalMoves().where((move) => !move.isRoll).toList();
    return GameScreenFrame(
      title: 'منچ',
      subtitle: _setup.withBot
          ? 'Classic Rule Profile • ربات‌های محلی'
          : 'Classic Rule Profile • چندنفره محلی',
      child: Column(
        children: [
          GameStatusStrip(
            leading: AppIcon('ludo', color: playerColor),
            title: title,
            trailing: state.dice == null ? const AppIcon('dice', color: AppColors.muted) : _LudoDice(value: state.dice!, color: playerColor),
            accent: playerColor,
          ),
          const SizedBox(height: 14),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 640),
            child: AspectRatio(
              aspectRatio: 1,
              child: GildedPanel(
                accent: AppColors.ludo,
                padding: const EdgeInsets.all(6),
                child: AnimatedBuilder(
                  animation: _moveAnimation,
                  builder: (context, _) => CustomPaint(
                    painter: _LudoBoardPainter(
                      state: state,
                      animation: _moveAnimation.value,
                      movingPlayer: _movingPlayer,
                      movingTokenIndex: _movingTokenIndex,
                      movingFromSteps: _movingFromSteps,
                      movingToSteps: _movingToSteps,
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (state.status == LudoStatus.waitingForToken)
            GildedPanel(
              accent: playerColor,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('مهره‌های مجاز', style: TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final move in tokenMoves)
                        InkWell(
                          onTap: _botRunning ? null : () => unawaited(_apply(move)),
                          borderRadius: BorderRadius.circular(14),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), color: playerColor.withValues(alpha: 0.16), border: Border.all(color: playerColor.withValues(alpha: 0.65))),
                            child: Text('مهره ${(move.tokenIndex ?? 0) + 1}', style: const TextStyle(fontWeight: FontWeight.w900)),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          if (state.status == LudoStatus.waitingForToken) const SizedBox(height: 12),
          AppButton(
            label: state.status == LudoStatus.finished ? 'شروع مسابقه تازه' : 'ریختن تاس',
            icon: state.status == LudoStatus.finished ? 'replay' : 'dice',
            onPressed: state.status == LudoStatus.waitingForToken ||
                    _botRunning ||
                    _moveAnimation.isAnimating
                ? null
                : () {
                    if (state.status == LudoStatus.finished) {
                      _startedAt = DateTime.now();
                      setState(() => _engine = LudoEngine(
                            initial: LudoState.initial(
                              players: _setup.playerCount,
                              seed: DateTime.now().millisecondsSinceEpoch,
                            ),
                          ));
                      _persist();
                    } else {
                      unawaited(_apply(const LudoMove.roll()));
                    }
                  },
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              for (var player = 0; player < state.players; player++)
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(left: player == state.players - 1 ? 0 : 6),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: _color(player).withValues(alpha: state.currentPlayer == player ? 0.18 : 0.07), border: Border.all(color: _color(player).withValues(alpha: state.currentPlayer == player ? 0.65 : 0.18))),
                      child: Column(children: [Text(_playerName(player), style: TextStyle(color: _color(player), fontWeight: FontWeight.w900)), Text('${state.tokens.where((t) => t.player == player && t.completed).length}/4', style: const TextStyle(fontSize: 11, color: AppColors.muted))]),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  String _playerName(int player) {
    if (_setup.withBot && player > 0) {return 'ربات $player';}
    if (player < _setup.playerNames.length) {return _setup.playerNames[player];}
    return 'بازیکن ${player + 1}';
  }

  Color _color(int player) => const [AppColors.success, AppColors.brassBright, AppColors.info, AppColors.morris][player];
}

class _LudoDice extends StatelessWidget {
  const _LudoDice({required this.value, required this.color});
  final int value;
  final Color color;
  @override
  Widget build(BuildContext context) => Container(width: 38, height: 38, decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: color), alignment: Alignment.center, child: Text('$value', style: const TextStyle(color: AppColors.voidBlack, fontSize: 18, fontWeight: FontWeight.w900)));
}

class _LudoBoardPainter extends CustomPainter {
  const _LudoBoardPainter({
    required this.state,
    required this.animation,
    required this.movingPlayer,
    required this.movingTokenIndex,
    required this.movingFromSteps,
    required this.movingToSteps,
  });

  final LudoState state;
  final double animation;
  final int? movingPlayer;
  final int? movingTokenIndex;
  final int? movingFromSteps;
  final int? movingToSteps;

  static const colors = [
    AppColors.success,
    AppColors.brassBright,
    AppColors.info,
    AppColors.morris,
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final cell = size.shortestSide / 15;
    final origin = Offset(
      (size.width - cell * 15) / 2,
      (size.height - cell * 15) / 2,
    );
    final boardRect = Rect.fromLTWH(
      origin.dx,
      origin.dy,
      cell * 15,
      cell * 15,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(boardRect, const Radius.circular(12)),
      Paint()..color = AppColors.parchment.withValues(alpha: 0.07),
    );

    final yards = [
      Rect.fromLTWH(origin.dx, origin.dy, cell * 6, cell * 6),
      Rect.fromLTWH(origin.dx + cell * 9, origin.dy, cell * 6, cell * 6),
      Rect.fromLTWH(
        origin.dx + cell * 9,
        origin.dy + cell * 9,
        cell * 6,
        cell * 6,
      ),
      Rect.fromLTWH(origin.dx, origin.dy + cell * 9, cell * 6, cell * 6),
    ];
    for (var i = 0; i < 4; i++) {
      final yard = RRect.fromRectAndRadius(
        yards[i].deflate(cell * 0.15),
        Radius.circular(cell * 0.4),
      );
      canvas.drawRRect(
        yard,
        Paint()..color = colors[i].withValues(alpha: 0.14),
      );
      canvas.drawRRect(
        yard,
        Paint()
          ..color = colors[i].withValues(alpha: 0.65)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5,
      );
    }

    for (var i = 0; i < LudoBoardConfig.commonTrack.length; i++) {
      final point = LudoBoardConfig.commonTrack[i];
      final rect = Rect.fromLTWH(
        origin.dx + point.x * cell,
        origin.dy + point.y * cell,
        cell,
        cell,
      ).deflate(1);
      final safe = LudoBoardConfig.safeTrackPositions.contains(i);
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, Radius.circular(cell * 0.12)),
        Paint()
          ..color = safe
              ? AppColors.brass.withValues(alpha: 0.25)
              : AppColors.parchment.withValues(alpha: 0.11),
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, Radius.circular(cell * 0.12)),
        Paint()
          ..color = AppColors.parchment.withValues(alpha: 0.18)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.8,
      );
      if (safe) {
        canvas.drawCircle(
          rect.center,
          cell * 0.12,
          Paint()..color = AppColors.brassBright.withValues(alpha: 0.75),
        );
      }
    }

    for (var player = 0; player < 4; player++) {
      for (final point in LudoBoardConfig.homeLanes[player]) {
        final rect = Rect.fromLTWH(
          origin.dx + point.x * cell,
          origin.dy + point.y * cell,
          cell,
          cell,
        ).deflate(1);
        canvas.drawRRect(
          RRect.fromRectAndRadius(rect, Radius.circular(cell * 0.12)),
          Paint()..color = colors[player].withValues(alpha: 0.34),
        );
      }
    }

    final center = Offset(
      origin.dx + 7.5 * cell,
      origin.dy + 7.5 * cell,
    );
    final centerPath = Path()
      ..moveTo(center.dx, center.dy - cell)
      ..lineTo(center.dx + cell, center.dy)
      ..lineTo(center.dx, center.dy + cell)
      ..lineTo(center.dx - cell, center.dy)
      ..close();
    canvas.drawPath(
      centerPath,
      Paint()..color = AppColors.brass.withValues(alpha: 0.24),
    );

    for (final token in state.tokens) {
      final isMoving = token.player == movingPlayer &&
          token.index == movingTokenIndex &&
          movingFromSteps != null &&
          movingToSteps != null;
      if (isMoving) {continue;}
      final position = _positionForSteps(
        token.player,
        token.index,
        token.steps,
        origin,
        cell,
        applyStackOffset: true,
      );
      _drawToken(
        canvas,
        position,
        colors[token.player],
        token.index,
        cell,
        token.completed,
      );
    }

    if (movingPlayer != null &&
        movingTokenIndex != null &&
        movingFromSteps != null &&
        movingToSteps != null) {
      final position = _animatedTokenPosition(origin, cell);
      _drawToken(
        canvas,
        position,
        colors[movingPlayer!],
        movingTokenIndex!,
        cell,
        movingToSteps == 58 && animation >= 1,
      );
    }
  }

  Offset _animatedTokenPosition(Offset origin, double cell) {
    final path = <int>[];
    if (movingFromSteps! < 0) {
      path.addAll([-1, 0]);
    } else {
      for (var step = movingFromSteps!; step <= movingToSteps!; step++) {
        path.add(step);
      }
    }
    if (path.length == 1) {
      return _positionForSteps(
        movingPlayer!,
        movingTokenIndex!,
        path.single,
        origin,
        cell,
      );
    }
    final scaled = animation * (path.length - 1);
    final segment = scaled.floor().clamp(0, path.length - 2).toInt();
    final fraction = scaled - segment;
    final from = _positionForSteps(
      movingPlayer!,
      movingTokenIndex!,
      path[segment],
      origin,
      cell,
    );
    final to = _positionForSteps(
      movingPlayer!,
      movingTokenIndex!,
      path[segment + 1],
      origin,
      cell,
    );
    return Offset.lerp(from, to, Curves.easeInOut.transform(fraction))!;
  }

  Offset _positionForSteps(
    int player,
    int tokenIndex,
    int steps,
    Offset origin,
    double cell, {
    bool applyStackOffset = false,
  }) {
    if (steps < 0) {
      final yardOrigins = [
        const BoardPoint(1, 1),
        const BoardPoint(10, 1),
        const BoardPoint(10, 10),
        const BoardPoint(1, 10),
      ];
      final base = yardOrigins[player];
      final dx = tokenIndex % 2 == 0 ? 1.2 : 3.8;
      final dy = tokenIndex < 2 ? 1.2 : 3.8;
      return Offset(
        origin.dx + (base.x + dx) * cell,
        origin.dy + (base.y + dy) * cell,
      );
    }
    if (steps == 58) {
      const offsets = [
        Offset(-0.22, 0.22),
        Offset(0.22, -0.22),
        Offset(0.22, 0.22),
        Offset(-0.22, -0.22),
      ];
      return Offset(
        origin.dx + 7.5 * cell + offsets[player].dx * cell,
        origin.dy + 7.5 * cell + offsets[player].dy * cell,
      );
    }

    BoardPoint point;
    if (steps <= 51) {
      final global = LudoEngine.globalTrackPosition(player, steps);
      point = LudoBoardConfig.commonTrack[global];
    } else {
      point = LudoBoardConfig.homeLanes[player][steps - 52];
    }

    var stackOffset = Offset.zero;
    if (applyStackOffset) {
      final same = state.tokens
          .where((token) => token.player == player && token.steps == steps)
          .toList();
      final stackIndex = same.indexWhere((token) => token.index == tokenIndex);
      if (stackIndex >= 0) {
        final angle = stackIndex * pi / 2;
        stackOffset = Offset(
          cos(angle) * cell * 0.13,
          sin(angle) * cell * 0.13,
        );
      }
    }
    return Offset(
      origin.dx + (point.x + 0.5) * cell + stackOffset.dx,
      origin.dy + (point.y + 0.5) * cell + stackOffset.dy,
    );
  }

  void _drawToken(
    Canvas canvas,
    Offset center,
    Color color,
    int index,
    double cell,
    bool completed,
  ) {
    final radius = cell * (completed ? 0.20 : 0.27);
    canvas.drawCircle(
      center + Offset(0, cell * 0.07),
      radius,
      Paint()..color = Colors.black.withValues(alpha: 0.55),
    );
    canvas.drawCircle(center, radius, Paint()..color = color);
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..color = AppColors.parchment.withValues(alpha: 0.65)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1,
    );
    final text = TextPainter(
      text: TextSpan(
        text: '${index + 1}',
        style: TextStyle(
          color: AppColors.voidBlack,
          fontSize: cell * 0.25,
          fontWeight: FontWeight.w900,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    text.paint(canvas, center - Offset(text.width / 2, text.height / 2));
  }

  @override
  bool shouldRepaint(covariant _LudoBoardPainter oldDelegate) =>
      oldDelegate.state.stateHash() != state.stateHash() ||
      oldDelegate.animation != animation ||
      oldDelegate.movingPlayer != movingPlayer ||
      oldDelegate.movingTokenIndex != movingTokenIndex;
}

