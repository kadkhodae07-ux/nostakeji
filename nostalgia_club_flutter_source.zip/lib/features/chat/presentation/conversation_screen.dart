import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/storage/mock_chat_repository.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/mock/social_mock_data.dart';
import 'package:nostalgia_club/shared/widgets/app_background.dart';
import 'package:nostalgia_club/shared/widgets/app_top_bar.dart';
import 'package:nostalgia_club/shared/widgets/mock_badge.dart';
import 'package:nostalgia_club/shared/widgets/state_view.dart';

class ConversationScreen extends ConsumerStatefulWidget {
  const ConversationScreen({super.key, required this.conversationId});
  final String conversationId;

  @override
  ConsumerState<ConversationScreen> createState() => _ConversationScreenState();
}

class _ConversationScreenState extends ConsumerState<ConversationScreen> {
  final _controller = TextEditingController();
  final _scroll = ScrollController();
  late final MockConversation _conversation;
  final List<LocalChatMessage> _messages = [];
  String? _reply;
  String? _editingId;
  bool _loading = true;
  Object? _loadError;

  MockChatRepository get _repository => ref.read(mockChatRepositoryProvider);

  @override
  void initState() {
    super.initState();
    _conversation = SocialMockData.conversations.firstWhere(
      (item) => item.id == widget.conversationId,
    );
    unawaited(_load());
  }

  Future<void> _load() async {
    try {
      final messages = await _repository.seedIfEmpty(widget.conversationId);
      if (!mounted) {return;}
      setState(() {
        _messages
          ..clear()
          ..addAll(messages);
        _loading = false;
        _loadError = null;
      });
      _scrollToEnd(immediate: true);
    } catch (error) {
      if (!mounted) {return;}
      setState(() {
        _loading = false;
        _loadError = error;
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty) {return;}

    if (_editingId != null) {
      final index = _messages.indexWhere((message) => message.id == _editingId);
      if (index < 0) {return;}
      final updated = _messages[index].copyWith(text: text, edited: true);
      setState(() {
        _messages[index] = updated;
        _controller.clear();
        _editingId = null;
        _reply = null;
      });
      await _repository.save(updated);
      return;
    }

    final now = DateTime.now().toUtc();
    final message = LocalChatMessage(
      id: '${widget.conversationId}:${now.microsecondsSinceEpoch}',
      conversationId: widget.conversationId,
      text: text,
      mine: true,
      createdAt: now,
      replyTo: _reply,
      deliveryState: 'read',
    );
    setState(() {
      _messages.add(message);
      _controller.clear();
      _reply = null;
    });
    await _repository.save(message);
    _scrollToEnd();
  }

  void _scrollToEnd({bool immediate = false}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) {return;}
      if (immediate) {
        _scroll.jumpTo(_scroll.position.maxScrollExtent);
      } else {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 260),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Column(
          children: [
            AppTopBar(
              title: _conversation.user.name,
              subtitle: _conversation.user.online ? 'آنلاین نمایشی' : 'آخرین بازدید اخیراً',
              actions: const [MockBadge()],
            ),
            Expanded(child: _messageBody()),
            if (_reply != null || _editingId != null) _composeContextBar(),
            _composer(),
          ],
        ),
      ),
    );
  }

  Widget _messageBody() {
    if (_loading) {
      return const Padding(
        padding: EdgeInsets.all(24),
        child: StateView(
          icon: 'chat',
          title: 'در حال بازیابی گفتگو',
          description: 'پیام‌های Mock از دیتابیس محلی خوانده می‌شوند.',
          loading: true,
        ),
      );
    }
    if (_loadError != null) {
      return Padding(
        padding: const EdgeInsets.all(24),
        child: StateView(
          icon: 'warning',
          title: 'گفتگو بارگذاری نشد',
          description: '$_loadError',
          actionLabel: 'تلاش دوباره',
          onAction: () {
            setState(() {
              _loading = true;
              _loadError = null;
            });
            unawaited(_load());
          },
        ),
      );
    }
    if (_messages.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(24),
        child: StateView(
          icon: 'chat',
          title: 'گفتگو خالی است',
          description: 'اولین پیام را ارسال کنید. پیام فقط روی همین دستگاه ذخیره می‌شود.',
        ),
      );
    }
    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
      itemCount: _messages.length,
      itemBuilder: (context, index) => _Bubble(
        message: _messages[index],
        onAction: (action) => _handle(action, _messages[index]),
      ),
    );
  }

  Widget _composeContextBar() => Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
        color: AppColors.raised,
        child: Row(
          children: [
            AppIcon(_editingId != null ? 'edit' : 'replay', size: 16, color: AppColors.brassBright),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                _editingId != null ? 'ویرایش پیام' : 'پاسخ به: $_reply',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppColors.muted),
              ),
            ),
            InkWell(
              onTap: () => setState(() {
                _reply = null;
                _editingId = null;
                _controller.clear();
              }),
              child: const Padding(
                padding: EdgeInsets.all(8),
                child: AppIcon('close', size: 16),
              ),
            ),
          ],
        ),
      );

  Widget _composer() => SafeArea(
        top: false,
        child: Container(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
          decoration: BoxDecoration(
            color: AppColors.charcoal,
            border: Border(top: BorderSide(color: AppColors.brass.withValues(alpha: 0.18))),
          ),
          child: Row(
            children: [
              InkWell(
                onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('دعوت بازی در Mock Repository ثبت شد.')),
                ),
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.brass.withValues(alpha: 0.12),
                  ),
                  alignment: Alignment.center,
                  child: const AppIcon('invite', size: 19, color: AppColors.brassBright),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _controller,
                  minLines: 1,
                  maxLines: 4,
                  onSubmitted: (_) => unawaited(_send()),
                  decoration: const InputDecoration(
                    hintText: 'پیام نمایشی...',
                    isDense: true,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              InkWell(
                onTap: () => unawaited(_send()),
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  width: 42,
                  height: 42,
                  decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.brass),
                  alignment: Alignment.center,
                  child: const AppIcon('continue', size: 19, color: AppColors.voidBlack),
                ),
              ),
            ],
          ),
        ),
      );

  Future<void> _handle(String action, LocalChatMessage message) async {
    switch (action) {
      case 'reply':
        setState(() {
          _reply = message.text;
          _editingId = null;
        });
        break;
      case 'copy':
        await Clipboard.setData(ClipboardData(text: message.text));
        break;
      case 'edit':
        if (message.mine) {
          setState(() {
            _editingId = message.id;
            _reply = null;
            _controller.text = message.text;
            _controller.selection = TextSelection.collapsed(offset: _controller.text.length);
          });
        }
        break;
      case 'delete':
        if (message.mine) {
          setState(() => _messages.removeWhere((item) => item.id == message.id));
          await _repository.delete(message.id);
        }
        break;
      case 'block':
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('کاربر در Mock Repository مسدود شد.')),
          );
        }
        break;
      case 'report':
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('گزارش نمایشی ثبت شد.')),
          );
        }
        break;
    }
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.message, required this.onAction});
  final LocalChatMessage message;
  final ValueChanged<String> onAction;

  @override
  Widget build(BuildContext context) => Align(
        alignment: message.mine ? Alignment.centerLeft : Alignment.centerRight,
        child: GestureDetector(
          onLongPress: () => showModalBottomSheet<void>(
            context: context,
            backgroundColor: AppColors.charcoal,
            builder: (context) => SafeArea(
              child: Wrap(
                children: [
                  _ActionTile(
                    icon: 'replay',
                    title: 'پاسخ',
                    onTap: () {
                      Navigator.pop(context);
                      onAction('reply');
                    },
                  ),
                  _ActionTile(
                    icon: 'share',
                    title: 'کپی',
                    onTap: () {
                      Navigator.pop(context);
                      onAction('copy');
                    },
                  ),
                  if (message.mine)
                    _ActionTile(
                      icon: 'edit',
                      title: 'ویرایش',
                      onTap: () {
                        Navigator.pop(context);
                        onAction('edit');
                      },
                    ),
                  if (message.mine)
                    _ActionTile(
                      icon: 'delete',
                      title: 'حذف',
                      onTap: () {
                        Navigator.pop(context);
                        onAction('delete');
                      },
                    ),
                  if (!message.mine)
                    _ActionTile(
                      icon: 'lock',
                      title: 'مسدودسازی',
                      onTap: () {
                        Navigator.pop(context);
                        onAction('block');
                      },
                    ),
                  if (!message.mine)
                    _ActionTile(
                      icon: 'warning',
                      title: 'گزارش',
                      onTap: () {
                        Navigator.pop(context);
                        onAction('report');
                      },
                    ),
                ],
              ),
            ),
          ),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 320),
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.fromLTRB(12, 9, 12, 7),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(17).copyWith(
                bottomLeft: Radius.circular(message.mine ? 5 : 17),
                bottomRight: Radius.circular(message.mine ? 17 : 5),
              ),
              color: message.mine ? AppColors.brass.withValues(alpha: 0.22) : AppColors.raised,
              border: Border.all(
                color: message.mine
                    ? AppColors.brass.withValues(alpha: 0.38)
                    : AppColors.parchment.withValues(alpha: 0.06),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (message.replyTo != null)
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.only(bottom: 6),
                    padding: const EdgeInsets.all(7),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(9),
                      color: AppColors.voidBlack.withValues(alpha: 0.25),
                    ),
                    child: Text(
                      message.replyTo!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: AppColors.muted, fontSize: 11),
                    ),
                  ),
                Text(message.text),
                const SizedBox(height: 4),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '${_timeLabel(message.createdAt)}${message.edited ? ' • ویرایش‌شده' : ''}',
                      style: const TextStyle(fontSize: 9, color: AppColors.muted),
                    ),
                    if (message.mine) ...[
                      const SizedBox(width: 5),
                      const AppIcon('check', size: 12, color: AppColors.success),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
      );

  static String _timeLabel(DateTime value) {
    final local = value.toLocal();
    return '${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({required this.icon, required this.title, required this.onTap});
  final String icon;
  final String title;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => ListTile(
        onTap: onTap,
        leading: AppIcon(icon, color: AppColors.brassBright),
        title: Text(title),
      );
}
