import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/mock/social_mock_data.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';
import 'package:nostalgia_club/shared/widgets/mock_badge.dart';

class ChatListScreen extends StatelessWidget {
  const ChatListScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(18, 18, 18, 12), child: Row(children: [Expanded(child: Text('گفتگوها', style: Theme.of(context).textTheme.headlineMedium)), const MockBadge()])),
        const Padding(padding: EdgeInsets.symmetric(horizontal: 18), child: TextField(decoration: InputDecoration(prefixIcon: Padding(padding: EdgeInsets.all(14), child: AppIcon('search', size: 20, color: AppColors.muted)), hintText: 'جست‌وجوی گفتگو'))),
        const SizedBox(height: 12),
        Expanded(child: ListView.separated(padding: const EdgeInsets.fromLTRB(18, 0, 18, 24), itemCount: SocialMockData.conversations.length, separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (context, index) {
          final conversation = SocialMockData.conversations[index];
          return GildedPanel(
            onTap: () => context.push('/conversation/${conversation.id}'),
            child: Row(children: [
              Stack(children: [Container(width: 52, height: 52, decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.info.withValues(alpha: 0.12)), alignment: Alignment.center, child: const AppIcon('profile', color: AppColors.info)), Positioned(left: 1, bottom: 1, child: Container(width: 12, height: 12, decoration: BoxDecoration(shape: BoxShape.circle, color: conversation.user.online ? AppColors.success : AppColors.muted, border: Border.all(color: AppColors.raised, width: 2))))]),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(conversation.user.name, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(conversation.lastMessage, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.muted))])),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(conversation.time, style: const TextStyle(fontSize: 10, color: AppColors.muted)), const SizedBox(height: 8), if (conversation.unread > 0) Container(minWidth: 22, height: 22, padding: const EdgeInsets.symmetric(horizontal: 6), decoration: BoxDecoration(borderRadius: BorderRadius.circular(99), color: AppColors.brass), alignment: Alignment.center, child: Text('${conversation.unread}', style: const TextStyle(color: AppColors.voidBlack, fontSize: 10, fontWeight: FontWeight.w900))) else const AppIcon('check', size: 15, color: AppColors.success)]),
            ]),
          );
        })),
      ]),
    );
  }
}
