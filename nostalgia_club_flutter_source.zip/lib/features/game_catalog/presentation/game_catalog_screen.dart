import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/features/game_catalog/domain/game_definition.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';

class GameCatalogScreen extends StatefulWidget {
  const GameCatalogScreen({super.key});
  @override
  State<GameCatalogScreen> createState() => _GameCatalogScreenState();
}

class _GameCatalogScreenState extends State<GameCatalogScreen> {
  final _search = TextEditingController();
  String _filter = 'همه';
  static const _filters = ['همه', 'تک‌نفره', 'دونفره', 'چندنفره'];

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final query = _search.text.trim();
    final games = GameCatalog.all.where((game) {
      final matchesSearch = query.isEmpty || game.title.contains(query) || game.subtitle.contains(query);
      final matchesFilter = _filter == 'همه' || game.tags.contains(_filter);
      return matchesSearch && matchesFilter;
    }).toList();

    return SafeArea(
      bottom: false,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
            child: Row(
              children: [
                Expanded(child: Text('تالار بازی‌ها', style: Theme.of(context).textTheme.headlineMedium)),
                Semantics(button: true, label: 'تنظیمات', child: InkWell(onTap: () => context.push('/settings'), borderRadius: BorderRadius.circular(22), child: Container(width: 44, height: 44, decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.raised, border: Border.all(color: AppColors.brass.withValues(alpha: 0.25))), alignment: Alignment.center, child: const AppIcon('settings', size: 20)))),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            child: TextField(
              controller: _search,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(prefixIcon: Padding(padding: EdgeInsets.all(14), child: AppIcon('search', size: 20, color: AppColors.muted)), hintText: 'جست‌وجوی بازی'),
            ),
          ),
          SizedBox(
            height: 58,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
              scrollDirection: Axis.horizontal,
              itemCount: _filters.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (context, index) {
                final value = _filters[index];
                final selected = value == _filter;
                return ChoiceChip(
                  label: Text(value),
                  selected: selected,
                  showCheckmark: false,
                  onSelected: (_) => setState(() => _filter = value),
                  backgroundColor: AppColors.raised,
                  selectedColor: AppColors.brass.withValues(alpha: 0.2),
                  side: BorderSide(color: selected ? AppColors.brass : AppColors.brass.withValues(alpha: 0.18)),
                );
              },
            ),
          ),
          Expanded(
            child: games.isEmpty
                ? const Center(child: Text('بازی مطابق جست‌وجو پیدا نشد.', style: TextStyle(color: AppColors.muted)))
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(18, 6, 18, 24),
                    itemCount: games.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, index) => _GameListCard(game: games[index]),
                  ),
          ),
        ],
      ),
    );
  }
}

class _GameListCard extends StatelessWidget {
  const _GameListCard({required this.game});
  final GameDefinition game;

  @override
  Widget build(BuildContext context) {
    return GildedPanel(
      onTap: () => context.push('/game-detail/${game.key}'),
      accent: game.accent,
      child: Row(
        children: [
          Container(width: 68, height: 68, decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), color: game.accent.withValues(alpha: 0.14)), alignment: Alignment.center, child: AppIcon(game.icon, size: 38, color: game.accent)),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(game.title, style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 3),
                Text(game.subtitle, style: const TextStyle(color: AppColors.muted)),
                const SizedBox(height: 9),
                Wrap(spacing: 8, runSpacing: 6, children: [
                  _Meta(icon: 'local_player', text: game.players),
                  _Meta(icon: 'timer', text: game.duration),
                  _Meta(icon: 'difficulty', text: game.difficulty),
                ]),
              ],
            ),
          ),
          const AppIcon('continue', size: 20, color: AppColors.muted),
        ],
      ),
    );
  }
}

class _Meta extends StatelessWidget {
  const _Meta({required this.icon, required this.text});
  final String icon;
  final String text;
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [AppIcon(icon, size: 13, color: AppColors.brassBright), const SizedBox(width: 4), Text(text, style: const TextStyle(fontSize: 10, color: AppColors.muted))]);
}
