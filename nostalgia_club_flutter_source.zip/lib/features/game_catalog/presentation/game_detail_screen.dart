import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/storage/saved_game_repository.dart';
import 'package:nostalgia_club/features/game_catalog/domain/game_definition.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_background.dart';
import 'package:nostalgia_club/shared/widgets/app_button.dart';
import 'package:nostalgia_club/shared/widgets/app_top_bar.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';

class GameDetailScreen extends ConsumerWidget {
  const GameDetailScreen({super.key, required this.gameKey});
  final String gameKey;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final game = GameCatalog.byKey(gameKey);
    final hasSavedGame = ref.watch(savedGameExistsProvider(gameKey));
    return AppBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Column(
          children: [
            AppTopBar(title: game.title, subtitle: game.subtitle),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
                child: Column(
                  children: [
                    GildedPanel(
                      accent: game.accent,
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        children: [
                          Container(width: 112, height: 112, decoration: BoxDecoration(shape: BoxShape.circle, color: game.accent.withValues(alpha: 0.15)), alignment: Alignment.center, child: AppIcon(game.icon, size: 62, color: game.accent)),
                          const SizedBox(height: 20),
                          Text(game.description, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: AppColors.muted)),
                          const SizedBox(height: 20),
                          Row(children: [
                            Expanded(child: _InfoTile(icon: 'local_player', label: 'بازیکن', value: game.players)),
                            const SizedBox(width: 10),
                            Expanded(child: _InfoTile(icon: 'timer', label: 'زمان', value: game.duration)),
                            const SizedBox(width: 10),
                            Expanded(child: _InfoTile(icon: 'difficulty', label: 'سطح', value: game.difficulty)),
                          ]),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    GildedPanel(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('حالت‌های موجود', style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 12),
                          const _ModeRow(icon: 'local_player', title: 'بازیکنان محلی', subtitle: 'رقابت روی یک گوشی', enabled: true),
                          const Divider(height: 24),
                          const _ModeRow(icon: 'bot', title: 'بازی با ربات', subtitle: 'سه سطح آسان، متوسط و سخت', enabled: true),
                          const Divider(height: 24),
                          const _ModeRow(icon: 'online', title: 'بازی آنلاین', subtitle: 'قرارداد اتصال آماده؛ در این نسخه غیرفعال', enabled: false),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(child: AppButton(label: 'آموزش', icon: 'help', secondary: true, onPressed: () => context.push('/tutorial/$gameKey'))),
                        const SizedBox(width: 10),
                        Expanded(child: AppButton(label: 'قوانین', icon: 'rules', secondary: true, onPressed: () => context.push('/rules/$gameKey'))),
                      ],
                    ),
                    const SizedBox(height: 12),
                    AppButton(label: 'تنظیم بازیکنان', icon: 'play', onPressed: () => context.push('/player-setup/$gameKey')),
                    const SizedBox(height: 10),
                    AppButton(
                      label: hasSavedGame.isLoading
                          ? 'در حال بررسی بازی ذخیره‌شده'
                          : hasSavedGame.value == true
                              ? 'ادامه بازی قبلی'
                              : 'بازی ذخیره‌شده‌ای وجود ندارد',
                      icon: 'continue',
                      secondary: true,
                      onPressed: hasSavedGame.value == true ? () => context.go(game.route) : null,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  const _InfoTile({required this.icon, required this.label, required this.value});
  final String icon;
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), color: AppColors.voidBlack.withValues(alpha: 0.28)),
        child: Column(children: [AppIcon(icon, size: 20, color: AppColors.brassBright), const SizedBox(height: 7), Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 10)), const SizedBox(height: 2), Text(value, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11))]),
      );
}

class _ModeRow extends StatelessWidget {
  const _ModeRow({required this.icon, required this.title, required this.subtitle, required this.enabled});
  final String icon;
  final String title;
  final String subtitle;
  final bool enabled;
  @override
  Widget build(BuildContext context) => Opacity(
        opacity: enabled ? 1 : 0.5,
        child: Row(children: [Container(width: 44, height: 44, decoration: BoxDecoration(shape: BoxShape.circle, color: AppColors.brass.withValues(alpha: 0.1)), alignment: Alignment.center, child: AppIcon(icon, size: 21, color: AppColors.brassBright)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), Text(subtitle, style: const TextStyle(color: AppColors.muted, fontSize: 12))])), AppIcon(enabled ? 'check' : 'lock', size: 18, color: enabled ? AppColors.success : AppColors.muted)]),
      );
}
