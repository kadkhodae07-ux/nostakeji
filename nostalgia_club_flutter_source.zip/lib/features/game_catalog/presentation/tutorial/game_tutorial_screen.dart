import 'package:flutter/material.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/features/game_catalog/domain/game_definition.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_background.dart';
import 'package:nostalgia_club/shared/widgets/app_button.dart';
import 'package:nostalgia_club/shared/widgets/app_top_bar.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';

class GameTutorialScreen extends StatefulWidget {
  const GameTutorialScreen({super.key, required this.gameKey});
  final String gameKey;
  @override
  State<GameTutorialScreen> createState() => _GameTutorialScreenState();
}

class _GameTutorialScreenState extends State<GameTutorialScreen> {
  final _controller = PageController();
  int _page = 0;

  List<(String, String, String)> get _slides => switch (widget.gameKey) {
        'chess' => const [
            ('piece_king', 'شاه را امن نگه دارید', 'هیچ حرکتی که شاه خودی را در کیش باقی بگذارد پذیرفته نمی‌شود.'),
            ('piece_rook', 'قلعه‌رفتن', 'شاه و رخ نباید حرکت کرده باشند؛ مسیر خالی و خانه‌های عبوری شاه امن باشند.'),
            ('piece_pawn', 'آن‌پاسان و ارتقا', 'حرکت‌های ویژه پیاده فقط در زمان و موقعیت قانونی فعال می‌شوند.'),
          ],
        'morris' => const [
            ('morris', 'چیدن ۹ مهره', 'مهره‌ها را روی نقاط خالی قرار دهید و ردیف سه‌تایی Mill بسازید.'),
            ('rules', 'حذف پس از Mill', 'تا وقتی مهره‌ای خارج از Mill وجود دارد، حذف مهره داخل Mill مجاز نیست.'),
            ('continue', 'مرحله پرواز', 'با باقی‌ماندن سه مهره، می‌توانید به هر نقطه خالی پرواز کنید.'),
          ],
        'xox' => const [
            ('xox', 'سه خانه هم‌خط', 'سه علامت افقی، عمودی یا مورب نتیجه راند را تعیین می‌کند.'),
            ('bot', 'ربات شکست‌ناپذیر', 'سطح سخت با Minimax تمام پاسخ‌های ممکن را بررسی می‌کند.'),
            ('leaderboard', 'مسابقه چندراندی', 'امتیاز هر راند تا شروع مسابقه تازه حفظ می‌شود.'),
          ],
        '2048' => const [
            ('2048', 'حرکت در چهار جهت', 'تمام خانه‌ها هم‌زمان حرکت می‌کنند و فقط جفت‌های برابر ترکیب می‌شوند.'),
            ('rules', 'هر خانه یک ادغام', 'در هر حرکت، خانه حاصل از ادغام دوباره در همان مسیر ترکیب نمی‌شود.'),
            ('back', 'Undo محدود', 'برای اصلاح اشتباه، تعداد محدودی بازگشت در اختیار دارید.'),
          ],
        'snakes' => const [
            ('dice', 'تاس و حرکت خانه‌به‌خانه', 'مهره به تعداد تاس روی مسیر رفت‌وبرگشتی پیش می‌رود.'),
            ('snakes', 'مار و نردبان', 'فقط یک انتقال در هر فرود اجرا می‌شود؛ زنجیره انتقال تکرار نمی‌شود.'),
            ('win', 'رسیدن دقیق به ۱۰۰', 'در Rule پیش‌فرض، عدد تاس باید دقیقاً شما را به خانه ۱۰۰ برساند.'),
          ],
        _ => const [
            ('dice', 'خروج با عدد ۶', 'در Rule کلاسیک، مهره از پایگاه با عدد شش وارد مسیر می‌شود.'),
            ('ludo', 'خانه امن و زدن مهره', 'مهره حریف فقط روی خانه غیرامن به پایگاه بازگردانده می‌شود.'),
            ('win', 'مسیر نهایی دقیق', 'مهره برای پایان باید دقیقاً به انتهای Home Lane برسد.'),
          ],
      };

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final game = GameCatalog.byKey(widget.gameKey);
    final slides = _slides;
    return AppBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Column(children: [
          AppTopBar(title: 'آموزش ${game.title}', subtitle: 'مثال کوتاه و تعاملی'),
          Expanded(
            child: PageView.builder(
              controller: _controller,
              itemCount: slides.length,
              onPageChanged: (value) => setState(() => _page = value),
              itemBuilder: (context, index) {
                final slide = slides[index];
                return Padding(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 20),
                  child: Center(
                    child: GildedPanel(
                      accent: game.accent,
                      padding: const EdgeInsets.all(26),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(width: 210, height: 170, child: CustomPaint(painter: _TutorialDiagramPainter(index: index, accent: game.accent), child: Center(child: AppIcon(slide.$1, size: 68, color: game.accent)))),
                          const SizedBox(height: 22),
                          Text(slide.$2, style: Theme.of(context).textTheme.headlineMedium, textAlign: TextAlign.center),
                          const SizedBox(height: 12),
                          Text(slide.$3, style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: AppColors.muted), textAlign: TextAlign.center),
                          const SizedBox(height: 18),
                          const Row(mainAxisAlignment: MainAxisAlignment.center, children: [AppIcon('warning', size: 17, color: AppColors.brassBright), SizedBox(width: 7), Flexible(child: Text('اشتباه رایج: انتخاب یا حرکت قبل از تأیید Rule Engine.', style: TextStyle(color: AppColors.brassBright, fontSize: 11)))]),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 16),
              child: Column(children: [
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [for (var i = 0; i < slides.length; i++) AnimatedContainer(duration: const Duration(milliseconds: 180), margin: const EdgeInsets.all(4), width: i == _page ? 24 : 8, height: 8, decoration: BoxDecoration(borderRadius: BorderRadius.circular(99), color: i == _page ? game.accent : AppColors.panel))]),
                const SizedBox(height: 12),
                AppButton(label: _page == slides.length - 1 ? 'پایان آموزش' : 'مثال بعدی', icon: _page == slides.length - 1 ? 'check' : 'continue', onPressed: () {
                  if (_page == slides.length - 1) {
                    Navigator.of(context).pop();
                  } else {
                    _controller.nextPage(duration: const Duration(milliseconds: 280), curve: Curves.easeOutCubic);
                  }
                }),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}

class _TutorialDiagramPainter extends CustomPainter {
  const _TutorialDiagramPainter({required this.index, required this.accent});
  final int index;
  final Color accent;
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = accent.withValues(alpha: 0.18)..strokeWidth = 1;
    for (var i = 1; i < 5; i++) {
      canvas.drawLine(Offset(size.width * i / 5, 0), Offset(size.width * i / 5, size.height), grid);
      canvas.drawLine(Offset(0, size.height * i / 4), Offset(size.width, size.height * i / 4), grid);
    }
    final highlight = Paint()..color = accent.withValues(alpha: 0.18 + index * 0.06);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(size.width * (0.28 + index * 0.2), size.height * 0.52), width: 58, height: 58), const Radius.circular(12)), highlight);
  }
  @override
  bool shouldRepaint(covariant _TutorialDiagramPainter oldDelegate) => oldDelegate.index != index || oldDelegate.accent != accent;
}
