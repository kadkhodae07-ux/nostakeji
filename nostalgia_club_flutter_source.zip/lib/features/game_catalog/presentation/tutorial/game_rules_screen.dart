import 'package:flutter/material.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/features/game_catalog/domain/game_definition.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_background.dart';
import 'package:nostalgia_club/shared/widgets/app_top_bar.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';

class GameRulesScreen extends StatelessWidget {
  const GameRulesScreen({super.key, required this.gameKey});
  final String gameKey;

  List<String> get rules => switch (gameKey) {
        'chess' => const ['حرکت قانونی همه مهره‌ها و ممنوعیت باقی‌ماندن شاه در کیش', 'قلعه در دو سمت با کنترل خانه‌های عبوری', 'آن‌پاسان، ارتقای پیاده، تکرار سه‌باره و قانون ۵۰ حرکت', 'کیش‌ومات، پات و کمبود مهره برای مات'],
        'morris' => const ['۹ مهره برای هر بازیکن و سه مرحله چیدن، حرکت و پرواز', 'پس از ساخت Mill یک مهره مجاز از حریف حذف می‌شود', 'با سه مهره حرکت به هر نقطه خالی ممکن است', 'کمتر از سه مهره یا نداشتن حرکت قانونی برابر با باخت است'],
        'xox' => const ['تخته ۳×۳ و نوبت متناوب X و O', 'سه علامت هم‌خط برد را تعیین می‌کند', 'پرشدن تخته بدون خط برنده مساوی است', 'سطح سخت ربات از Minimax استفاده می‌کند'],
        '2048' => const ['خانه‌ها در چهار جهت حرکت می‌کنند', 'دو عدد برابر فقط یک بار در هر حرکت ادغام می‌شوند', 'عدد تازه فقط بعد از حرکت معتبر ساخته می‌شود', 'پس از ۲۰۴۸ ادامه بازی مجاز است'],
        'snakes' => const ['تخته ۱۰۰ خانه‌ای با شماره‌گذاری رفت‌وبرگشتی', 'مار و نردبان فقط یک بار پس از فرود اعمال می‌شوند', 'رسیدن دقیق به ۱۰۰ و نوبت اضافه با شش قابل تنظیم است', 'رتبه تمام بازیکنان تا پایان مسابقه ثبت می‌شود'],
        _ => const ['۲ تا ۴ بازیکن و چهار مهره برای هر نفر', 'خروج از پایگاه و نوبت اضافه با عدد شش', 'زدن مهره حریف روی خانه غیرامن', 'رسیدن دقیق به پایان، خانه‌های امن و سه شش متوالی قابل تنظیم است'],
      };

  @override
  Widget build(BuildContext context) {
    final game = GameCatalog.byKey(gameKey);
    return AppBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Column(children: [
          AppTopBar(title: 'قوانین ${game.title}', subtitle: 'Rule Profile فعال نسخه آفلاین'),
          Expanded(child: ListView(padding: const EdgeInsets.fromLTRB(18, 0, 18, 24), children: [
            GildedPanel(accent: game.accent, child: Row(children: [Container(width: 64, height: 64, decoration: BoxDecoration(shape: BoxShape.circle, color: game.accent.withValues(alpha: 0.14)), alignment: Alignment.center, child: AppIcon(game.icon, size: 35, color: game.accent)), const SizedBox(width: 14), Expanded(child: Text(game.description, style: const TextStyle(color: AppColors.muted, height: 1.6)))])),
            const SizedBox(height: 14),
            for (var i = 0; i < rules.length; i++) Padding(padding: const EdgeInsets.only(bottom: 10), child: GildedPanel(child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Container(width: 30, height: 30, decoration: BoxDecoration(shape: BoxShape.circle, color: game.accent.withValues(alpha: 0.15)), alignment: Alignment.center, child: Text('${i + 1}', style: TextStyle(color: game.accent, fontWeight: FontWeight.w900))), const SizedBox(width: 12), Expanded(child: Text(rules[i], style: const TextStyle(height: 1.7)))]))),
            GildedPanel(accent: AppColors.info, child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [AppIcon('info', color: AppColors.info), SizedBox(width: 12), Expanded(child: Text('تمام حرکت‌ها ابتدا در Rule Engine اعتبارسنجی می‌شوند. UI فقط درخواست حرکت را ارسال می‌کند و اجازه تغییر مستقیم State را ندارد.', style: TextStyle(color: AppColors.muted, height: 1.6)))])),
          ])),
        ]),
      ),
    );
  }
}
