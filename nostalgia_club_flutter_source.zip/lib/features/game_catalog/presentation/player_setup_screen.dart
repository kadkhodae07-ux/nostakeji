import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/game/game_models.dart';
import 'package:nostalgia_club/core/storage/saved_game_repository.dart';
import 'package:nostalgia_club/features/game_catalog/domain/game_definition.dart';
import 'package:nostalgia_club/features/game_catalog/domain/game_setup.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_background.dart';
import 'package:nostalgia_club/shared/widgets/app_button.dart';
import 'package:nostalgia_club/shared/widgets/app_top_bar.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';

class PlayerSetupScreen extends ConsumerStatefulWidget {
  const PlayerSetupScreen({super.key, required this.gameKey});
  final String gameKey;

  @override
  ConsumerState<PlayerSetupScreen> createState() => _PlayerSetupScreenState();
}

class _PlayerSetupScreenState extends ConsumerState<PlayerSetupScreen> {
  late int _players;
  late bool _withBot;
  late BotDifficulty _difficulty;
  final List<TextEditingController> _nameControllers = [];

  bool get _singlePlayer => widget.gameKey == '2048';
  bool get _raceGame => widget.gameKey == 'snakes' || widget.gameKey == 'ludo';
  int get _minPlayers => _singlePlayer ? 1 : 2;
  int get _maxPlayers => _singlePlayer ? 1 : (_raceGame ? 4 : 2);

  @override
  void initState() {
    super.initState();
    final config = ref.read(gameSetupProvider.notifier).read(widget.gameKey);
    _players = config.playerCount.clamp(_minPlayers, _maxPlayers).toInt();
    _withBot = _singlePlayer ? false : config.withBot;
    _difficulty = config.difficulty;
    _syncNameControllers(config.playerNames);
    unawaited(_loadStoredSetup());
  }



  Future<void> _loadStoredSetup() async {
    try {
      final stored = await ref.read(gameSetupStorageProvider).load(widget.gameKey);
      if (stored == null || !mounted) return;
      for (final controller in _nameControllers) {
        controller.dispose();
      }
      _nameControllers.clear();
      setState(() {
        _players = stored.playerCount.clamp(_minPlayers, _maxPlayers).toInt();
        _withBot = _singlePlayer ? false : stored.withBot;
        _difficulty = stored.difficulty;
        _syncNameControllers(stored.playerNames);
      });
    } catch (_) {
      // Corrupt setup preferences fall back to safe defaults.
    }
  }

  void _syncNameControllers([List<String> initialNames = const []]) {
    while (_nameControllers.length < _players) {
      final index = _nameControllers.length;
      final fallback = index == 0
          ? 'بازیکن مهمان'
          : _withBot
              ? 'ربات $index'
              : 'بازیکن ${index + 1}';
      _nameControllers.add(
        TextEditingController(text: index < initialNames.length ? initialNames[index] : fallback),
      );
    }
    while (_nameControllers.length > _players) {
      _nameControllers.removeLast().dispose();
    }
  }

  void _changePlayerCount(int value) {
    setState(() {
      _players = value;
      _syncNameControllers();
    });
  }

  void _changeBot(bool value) {
    setState(() {
      _withBot = value;
      for (var i = 1; i < _nameControllers.length; i++) {
        final previous = _nameControllers[i].text.trim();
        final looksGenerated = previous.startsWith('ربات ') || previous.startsWith('بازیکن ');
        if (looksGenerated) {
          _nameControllers[i].text = value ? 'ربات $i' : 'بازیکن ${i + 1}';
        }
      }
    });
  }

  Future<void> _start(String route) async {
    final names = [
      for (var i = 0; i < _players; i++)
        _nameControllers[i].text.trim().isEmpty
            ? i == 0
                ? 'بازیکن مهمان'
                : _withBot
                    ? 'ربات $i'
                    : 'بازیکن ${i + 1}'
            : _nameControllers[i].text.trim(),
    ];
    final config = GameSetupConfig(
      playerCount: _players,
      withBot: _withBot,
      difficulty: _difficulty,
      playerNames: names,
    );
    ref.read(gameSetupProvider.notifier).save(widget.gameKey, config);
    await ref.read(gameSetupStorageProvider).save(widget.gameKey, config);
    await ref.read(savedGameRepositoryProvider).delete(widget.gameKey);
    ref.invalidate(savedGameExistsProvider(widget.gameKey));
    if (mounted) context.go(route);
  }

  @override
  void dispose() {
    for (final controller in _nameControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final game = GameCatalog.byKey(widget.gameKey);
    return AppBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Column(
          children: [
            AppTopBar(title: 'آماده‌سازی ${game.title}', subtitle: 'حالت و بازیکنان را مشخص کنید'),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
                child: Column(
                  children: [
                    GildedPanel(
                      accent: game.accent,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('تعداد بازیکنان', style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 14),
                          Row(
                            children: [
                              for (var count = _minPlayers; count <= _maxPlayers; count++)
                                Expanded(
                                  child: Padding(
                                    padding: EdgeInsets.only(left: count == _maxPlayers ? 0 : 8),
                                    child: _SelectionTile(
                                      label: '$count',
                                      selected: _players == count,
                                      onTap: () => _changePlayerCount(count),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),
                    if (!_singlePlayer)
                      GildedPanel(
                        child: Column(
                          children: [
                            SwitchListTile(
                              contentPadding: EdgeInsets.zero,
                              value: _withBot,
                              onChanged: _changeBot,
                              title: const Text(
                                'حریف‌های رباتی',
                                style: TextStyle(fontWeight: FontWeight.w800),
                              ),
                              subtitle: Text(
                                _raceGame
                                    ? 'بازیکن اول انسانی است و صندلی‌های بعدی با ربات کنترل می‌شوند.'
                                    : 'در حالت خاموش، هر دو بازیکن روی همین گوشی بازی می‌کنند.',
                                style: const TextStyle(color: AppColors.muted),
                              ),
                              secondary: const AppIcon('bot', color: AppColors.brassBright),
                            ),
                            if (_withBot) ...[
                              const Divider(height: 24),
                              Align(
                                alignment: Alignment.centerRight,
                                child: Text('سطح ربات', style: Theme.of(context).textTheme.titleMedium),
                              ),
                              const SizedBox(height: 12),
                              SegmentedButton<BotDifficulty>(
                                showSelectedIcon: false,
                                segments: const [
                                  ButtonSegment(value: BotDifficulty.easy, label: Text('آسان')),
                                  ButtonSegment(value: BotDifficulty.medium, label: Text('متوسط')),
                                  ButtonSegment(value: BotDifficulty.hard, label: Text('سخت')),
                                ],
                                selected: {_difficulty},
                                onSelectionChanged: (value) => setState(() => _difficulty = value.first),
                              ),
                            ],
                          ],
                        ),
                      ),
                    const SizedBox(height: 14),
                    GildedPanel(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('بازیکنان', style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 12),
                          for (var i = 0; i < _players; i++) ...[
                            TextField(
                              controller: _nameControllers[i],
                              enabled: !_withBot || i == 0,
                              decoration: InputDecoration(
                                prefixIcon: Padding(
                                  padding: const EdgeInsets.all(14),
                                  child: AppIcon(
                                    _withBot && i > 0 ? 'bot' : 'local_player',
                                    size: 20,
                                  ),
                                ),
                                labelText: _withBot && i > 0 ? 'نام ربات ${i}' : 'نام صندلی ${i + 1}',
                              ),
                            ),
                            if (i != _players - 1) const SizedBox(height: 10),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),
                    AppButton(
                      label: 'شروع ${game.title}',
                      icon: 'play',
                      onPressed: () => unawaited(_start(game.route)),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SelectionTile extends StatelessWidget {
  const _SelectionTile({required this.label, required this.selected, required this.onTap});
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          height: 52,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: selected
                ? AppColors.brass.withValues(alpha: 0.18)
                : AppColors.voidBlack.withValues(alpha: 0.25),
            border: Border.all(
              color: selected ? AppColors.brassBright : AppColors.brass.withValues(alpha: 0.15),
            ),
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              color: selected ? AppColors.brassBright : AppColors.muted,
            ),
          ),
        ),
      );
}
