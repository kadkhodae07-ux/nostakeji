import 'package:flutter/material.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';

class GameDefinition {
  const GameDefinition({
    required this.key,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.icon,
    required this.accent,
    required this.players,
    required this.duration,
    required this.difficulty,
    required this.route,
    required this.tags,
  });

  final String key;
  final String title;
  final String subtitle;
  final String description;
  final String icon;
  final Color accent;
  final String players;
  final String duration;
  final String difficulty;
  final String route;
  final List<String> tags;
}

abstract final class GameCatalog {
  static const all = <GameDefinition>[
    GameDefinition(
      key: 'chess',
      title: 'شطرنج',
      subtitle: 'نبرد عمیق و کلاسیک',
      description: 'شطرنج کامل با قوانین استاندارد، ذخیره FEN، خروجی PGN و ربات محلی.',
      icon: 'chess', accent: AppColors.chess, players: '۱ تا ۲', duration: '۱۰–۶۰ دقیقه', difficulty: 'پیشرفته', route: '/game/chess',
      tags: ['دونفره', 'ربات', 'فکری'],
    ),
    GameDefinition(
      key: 'morris', title: 'دوز ۹ مهره‌ای', subtitle: 'سه مرحله، یک نبرد تاکتیکی',
      description: 'تخته استاندارد ۲۴ نقطه‌ای با Mill، پرواز و قوانین حذف دقیق.',
      icon: 'morris', accent: AppColors.morris, players: '۱ تا ۲', duration: '۱۰–۲۵ دقیقه', difficulty: 'متوسط', route: '/game/morris',
      tags: ['دونفره', 'ربات', 'فکری'],
    ),
    GameDefinition(
      key: 'xox', title: 'XOX', subtitle: 'ساده، سریع، شکست‌ناپذیر',
      description: 'دوز سه‌درسه با مسابقه چندراندی و ربات Minimax شکست‌ناپذیر.',
      icon: 'xox', accent: AppColors.xox, players: '۱ تا ۲', duration: '۱–۳ دقیقه', difficulty: 'آسان', route: '/game/xox',
      tags: ['دونفره', 'ربات', 'سریع'],
    ),
    GameDefinition(
      key: '2048', title: '۲۰۴۸', subtitle: 'ترکیب، تمرکز، رکورد',
      description: 'نسخه کامل ۴×۴ با Undo، ذخیره خودکار و تولید قطعی تست‌پذیر.',
      icon: '2048', accent: AppColors.game2048, players: '۱', duration: '۵–۲۰ دقیقه', difficulty: 'متوسط', route: '/game/2048',
      tags: ['تک‌نفره', 'رکوردی'],
    ),
    GameDefinition(
      key: 'snakes', title: 'مار و پله', subtitle: 'مسابقه روی صد خانه',
      description: 'حرکت خانه‌به‌خانه، رتبه‌بندی کامل و تخته داده‌محور.',
      icon: 'snakes', accent: AppColors.snakes, players: '۲ تا ۴', duration: '۱۰–۳۰ دقیقه', difficulty: 'آسان', route: '/game/snakes',
      tags: ['چندنفره', 'ربات', 'شانسی'],
    ),
    GameDefinition(
      key: 'ludo', title: 'منچ', subtitle: 'رقابت خانوادگی کلاسیک',
      description: 'مسیر کامل، خانه امن، زدن مهره، Stack و رتبه‌بندی ۲ تا ۴ نفره.',
      icon: 'ludo', accent: AppColors.ludo, players: '۲ تا ۴', duration: '۲۰–۵۰ دقیقه', difficulty: 'آسان', route: '/game/ludo',
      tags: ['چندنفره', 'ربات', 'محلی'],
    ),
  ];

  static GameDefinition byKey(String key) => all.firstWhere((game) => game.key == key);
}
