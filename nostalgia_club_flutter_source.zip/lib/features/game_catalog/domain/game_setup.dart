import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nostalgia_club/core/storage/app_database.dart';
import 'package:nostalgia_club/core/storage/database_provider.dart';
import 'package:nostalgia_club/core/game/game_models.dart';

class GameSetupConfig {
  const GameSetupConfig({
    required this.playerCount,
    required this.withBot,
    required this.difficulty,
    required this.playerNames,
  });

  final int playerCount;
  final bool withBot;
  final BotDifficulty difficulty;
  final List<String> playerNames;

  Map<String, Object?> toJson() => {
        'playerCount': playerCount,
        'withBot': withBot,
        'difficulty': difficulty.name,
        'playerNames': playerNames,
      };

  factory GameSetupConfig.fromJson(Map<String, dynamic> json) => GameSetupConfig(
        playerCount: json['playerCount'] as int,
        withBot: json['withBot'] as bool,
        difficulty: BotDifficulty.values.byName(json['difficulty'] as String),
        playerNames: (json['playerNames'] as List).cast<String>(),
      );

  factory GameSetupConfig.defaultsFor(String gameKey) {
    final singlePlayer = gameKey == '2048';
    final multiRace = gameKey == 'snakes' || gameKey == 'ludo';
    return GameSetupConfig(
      playerCount: singlePlayer ? 1 : multiRace ? 4 : 2,
      withBot: !singlePlayer,
      difficulty: BotDifficulty.medium,
      playerNames: singlePlayer
          ? const ['بازیکن مهمان']
          : multiRace
              ? const ['بازیکن مهمان', 'ربات ۱', 'ربات ۲', 'ربات ۳']
              : const ['بازیکن مهمان', 'ربات'],
    );
  }
}

class GameSetupController extends StateNotifier<Map<String, GameSetupConfig>> {
  GameSetupController() : super(const {});

  GameSetupConfig read(String gameKey) => state[gameKey] ?? GameSetupConfig.defaultsFor(gameKey);

  void save(String gameKey, GameSetupConfig config) {
    state = {...state, gameKey: config};
  }
}

final gameSetupProvider = StateNotifierProvider<GameSetupController, Map<String, GameSetupConfig>>(
  (ref) => GameSetupController(),
);


class GameSetupStorage {
  const GameSetupStorage(this._database);
  final AppDatabase _database;

  Future<GameSetupConfig?> load(String gameKey) async {
    final raw = await _database.readSetting('gameSetup:$gameKey');
    if (raw == null) return null;
    return GameSetupConfig.fromJson(jsonDecode(raw) as Map<String, dynamic>);
  }

  Future<void> save(String gameKey, GameSetupConfig config) =>
      _database.writeSetting('gameSetup:$gameKey', jsonEncode(config.toJson()));
}

final gameSetupStorageProvider = Provider<GameSetupStorage>(
  (ref) => GameSetupStorage(ref.watch(appDatabaseProvider)),
);
