import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nostalgia_club/core/audio/audio_service.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/storage/game_autosave_mixin.dart';
import 'package:nostalgia_club/core/storage/match_history_repository.dart';
import 'package:nostalgia_club/features/game_catalog/domain/game_setup.dart';
import 'package:nostalgia_club/features/snakes_and_ladders/domain/snakes_ladders_engine.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_button.dart';
import 'package:nostalgia_club/shared/widgets/game_screen_frame.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';

class SnakesLaddersScreen extends ConsumerStatefulWidget {
  const SnakesLaddersScreen({super.key});
  @override
  ConsumerState<SnakesLaddersScreen> createState() => _SnakesLaddersScreenState();
}

class _SnakesLaddersScreenState extends ConsumerState<SnakesLaddersScreen> with SingleTickerProviderStateMixin, GameAutosaveMixin<SnakesLaddersScreen> {
  late SnakesLaddersEngine _engine;
  late final GameSetupConfig _setup;
  late final AnimationController _animation;
  int? _lastMover;
  int _oldPosition = 0;
  DateTime _startedAt = DateTime.now();
  bool _botRunning = false;

  @override
  void initState() {
    super.initState();
    _setup = ref.read(gameSetupProvider.notifier).read('snakes');
    _engine = SnakesLaddersEngine(
      initial: SnakesLaddersState.initial(
        players: _setup.playerCount,
        seed: DateTime.now().millisecondsSinceEpoch,
      ),
    );
    _animation = AnimationController(vsync: this, duration: const Duration(milliseconds: 850));
    Future<void>.microtask(_restore);
  }

  Future<void> _restore() async {
    try {
      final raw = await loadAutosave('snakes');
      if (raw == null || !mounted) {return;}
      final restored = SnakesLaddersState.fromJson(jsonDecode(raw) as Map<String, dynamic>);
      setState(() => _engine = SnakesLaddersEngine(initial: restored));
      if (_setup.withBot && _engine.state.status == RaceStatus.playing && _engine.state.currentPlayer != 0) {
        unawaited(_runBotTurns());
      }
    } catch (_) {
      deleteAutosave('snakes');
    }
  }

  void _persist() {
    if (_engine.state.status == RaceStatus.finished) {
      deleteAutosave('snakes');
      recordMatchHistory(
        gameKey: 'snakes',
        state: _engine.state,
        result: 'رتبه‌بندی: ${_engine.state.rankings.map((player) => player + 1).join('، ')}',
        outcome: _engine.state.rankings.first == 0
            ? LocalMatchOutcome.win
            : LocalMatchOutcome.loss,
        opponent: _setup.withBot
            ? '${_engine.state.positions.length - 1} ربات محلی'
            : '${_engine.state.positions.length} بازیکن محلی',
        startedAt: _startedAt,
      );
    } else {
      persistAutosave('snakes', _engine.state);
    }
  }

  @override
  void dispose() {
    _animation.dispose();
    super.dispose();
  }

  Future<void> _roll({bool automated = false}) async {
    if (_animation.isAnimating || _engine.state.status == RaceStatus.finished) {return;}
    if (!automated && _setup.withBot && _engine.state.currentPlayer != 0) {return;}
    AudioService.instance.playDice();
    final mover = _engine.state.currentPlayer;
    final old = _engine.state.positions[mover];
    setState(() {
      _lastMover = mover;
      _oldPosition = old;
      _engine.apply(const SnakesLaddersMove.roll());
    });
    _persist();
    try {
      await _animation.forward(from: 0).orCancel;
    } catch (_) {
      return;
    }
    if (!automated && _setup.withBot) {
      await _runBotTurns();
    }
  }

  Future<void> _runBotTurns() async {
    if (_botRunning || !_setup.withBot) {return;}
    _botRunning = true;
    if (mounted) {setState(() {});}
    try {
      while (mounted &&
          _engine.state.status == RaceStatus.playing &&
          _engine.state.currentPlayer != 0) {
        await Future<void>.delayed(const Duration(milliseconds: 420));
        await _roll(automated: true);
      }
    } finally {
      _botRunning = false;
      if (mounted) {setState(() {});}
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = _engine.state;
    final status = state.status == RaceStatus.finished
        ? 'رتبه‌بندی کامل شد'
        : 'نوبت ${_playerName(state.currentPlayer)}${state.lastRoll == null ? '' : ' • تاس قبلی ${state.lastRoll}'}';
    return GameScreenFrame(
      title: 'مار و پله',
      subtitle: _setup.withBot ? 'تخته ۱۰۰ خانه‌ای • ربات بدون تقلب' : 'تخته ۱۰۰ خانه‌ای • رقابت محلی',
      child: Column(
        children: [
          GameStatusStrip(
            leading: const AppIcon('snakes', color: AppColors.snakes),
            title: status,
            trailing: state.lastRoll == null ? const AppIcon('dice', color: AppColors.muted) : _DiceFace(value: state.lastRoll!),
            accent: AppColors.snakes,
          ),
          const SizedBox(height: 14),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 610),
            child: AspectRatio(
              aspectRatio: 1,
              child: GildedPanel(
                accent: AppColors.snakes,
                padding: const EdgeInsets.all(8),
                child: AnimatedBuilder(
                  animation: _animation,
                  builder: (context, _) => CustomPaint(
                    painter: _SnakesBoardPainter(
                      state: state,
                      config: _engine.config,
                      animation: _animation.value,
                      lastMover: _lastMover,
                      oldPosition: _oldPosition,
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          GildedPanel(
            child: Row(
              children: [
                for (var i = 0; i < state.positions.length; i++)
                  Expanded(
                    child: Column(children: [
                      Container(width: 24, height: 24, decoration: BoxDecoration(shape: BoxShape.circle, color: _playerColor(i))),
                      const SizedBox(height: 4),
                      Text(_playerName(i), style: const TextStyle(fontSize: 10, color: AppColors.muted)),
                      Text('${state.positions[i]}', style: const TextStyle(fontWeight: FontWeight.w900)),
                    ]),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          AppButton(
            label: state.status == RaceStatus.finished ? 'شروع مسابقه تازه' : 'ریختن تاس',
            icon: state.status == RaceStatus.finished ? 'replay' : 'dice',
            onPressed: _botRunning ? null : () {
            if (state.status == RaceStatus.finished) {
              _startedAt = DateTime.now();
              setState(() => _engine = SnakesLaddersEngine(
                    initial: SnakesLaddersState.initial(
                      players: _setup.playerCount,
                      seed: DateTime.now().millisecondsSinceEpoch,
                    ),
                  ));
              _persist();
            } else {
              unawaited(_roll());
            }
            },
          ),
        ],
      ),
    );
  }

  String _playerName(int player) {
    if (_setup.withBot && player > 0) {return 'ربات $player';}
    if (player < _setup.playerNames.length) {return _setup.playerNames[player];}
    return 'بازیکن ${player + 1}';
  }

  Color _playerColor(int player) => const [AppColors.brassBright, AppColors.morris, AppColors.info, AppColors.success][player];
}

class _DiceFace extends StatelessWidget {
  const _DiceFace({required this.value});
  final int value;
  @override
  Widget build(BuildContext context) => Container(width: 38, height: 38, decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), color: AppColors.parchment), alignment: Alignment.center, child: Text('$value', style: const TextStyle(color: AppColors.voidBlack, fontSize: 18, fontWeight: FontWeight.w900)));
}

class _SnakesBoardPainter extends CustomPainter {
  const _SnakesBoardPainter({required this.state, required this.config, required this.animation, required this.lastMover, required this.oldPosition});
  final SnakesLaddersState state;
  final SnakesLaddersConfig config;
  final double animation;
  final int? lastMover;
  final int oldPosition;

  Offset _center(int cell, Size size) {
    if (cell <= 0) {return Offset(size.width * 0.04, size.height * 0.96);}
    final rowFromBottom = SnakesLaddersEngine.rowForCell(cell);
    final col = SnakesLaddersEngine.columnForCell(cell);
    final cellSize = size.width / 10;
    return Offset((col + 0.5) * cellSize, size.height - (rowFromBottom + 0.5) * cellSize);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final cell = size.width / 10;
    for (var n = 1; n <= 100; n++) {
      final row = SnakesLaddersEngine.rowForCell(n);
      final col = SnakesLaddersEngine.columnForCell(n);
      final rect = Rect.fromLTWH(col * cell, size.height - (row + 1) * cell, cell, cell);
      final color = (row + col).isEven ? AppColors.parchment.withValues(alpha: 0.10) : AppColors.snakes.withValues(alpha: 0.13);
      canvas.drawRRect(RRect.fromRectAndRadius(rect.deflate(1), const Radius.circular(4)), Paint()..color = color);
      final text = TextPainter(text: TextSpan(text: '$n', style: TextStyle(fontSize: max(7.0, cell * 0.19), color: AppColors.parchment.withValues(alpha: 0.55), fontWeight: FontWeight.w700)), textDirection: TextDirection.ltr)..layout();
      text.paint(canvas, rect.topLeft + const Offset(3, 2));
    }

    for (final entry in config.transitions.entries) {
      final start = _center(entry.key, size);
      final end = _center(entry.value, size);
      if (entry.value > entry.key) {
        final ladder = Paint()..color = AppColors.brassBright.withValues(alpha: 0.78)..strokeWidth = max(2.0, cell * 0.08)..strokeCap = StrokeCap.round;
        final direction = end - start;
        final normal = Offset(-direction.dy, direction.dx) / direction.distance * cell * 0.09;
        canvas.drawLine(start + normal, end + normal, ladder);
        canvas.drawLine(start - normal, end - normal, ladder);
        for (var t = 0.15; t < 0.95; t += 0.16) {
          final p = Offset.lerp(start, end, t)!;
          canvas.drawLine(p - normal, p + normal, ladder..strokeWidth = max(1.4, cell * 0.04));
        }
      } else {
        final snake = Paint()..color = AppColors.morris.withValues(alpha: 0.92)..strokeWidth = max(3.0, cell * 0.13)..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
        final path = Path()..moveTo(start.dx, start.dy);
        final mid = Offset((start.dx + end.dx) / 2, (start.dy + end.dy) / 2);
        final bend = Offset((end.dy - start.dy) * 0.13, (start.dx - end.dx) * 0.13);
        path.quadraticBezierTo(mid.dx + bend.dx, mid.dy + bend.dy, end.dx, end.dy);
        canvas.drawPath(path, snake);
        canvas.drawCircle(start, cell * 0.12, Paint()..color = AppColors.morris);
      }
    }

    for (var player = 0; player < state.positions.length; player++) {
      var position = state.positions[player];
      if (lastMover == player && animation < 1 && state.lastPath.isNotEmpty) {
        final path = [oldPosition, ...state.lastPath];
        final scaled = animation * (path.length - 1);
        final i = scaled.floor().clamp(0, path.length - 2).toInt();
        final t = scaled - i;
        final p = Offset.lerp(_center(path[i], size), _center(path[i + 1], size), t)!;
        _drawToken(canvas, p, player, cell);
        continue;
      }
      _drawToken(canvas, _center(position, size), player, cell);
    }
  }

  void _drawToken(Canvas canvas, Offset center, int player, double cell) {
    const colors = [AppColors.brassBright, AppColors.morris, AppColors.info, AppColors.success];
    final offset = Offset((player % 2 - 0.5) * cell * 0.22, (player ~/ 2 - 0.5) * cell * 0.22);
    canvas.drawCircle(center + offset + const Offset(0, 2), cell * 0.13, Paint()..color = Colors.black.withValues(alpha: 0.55));
    canvas.drawCircle(center + offset, cell * 0.13, Paint()..color = colors[player]);
  }

  @override
  bool shouldRepaint(covariant _SnakesBoardPainter oldDelegate) => oldDelegate.state.stateHash() != state.stateHash() || oldDelegate.animation != animation;
}
