import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:nostalgia_club/core/game/deterministic_random.dart';
import 'package:nostalgia_club/core/game/game_models.dart';

class SnakesLaddersConfig {
  const SnakesLaddersConfig({
    required this.transitions,
    this.exactFinish = true,
    this.extraTurnOnSix = true,
  });

  factory SnakesLaddersConfig.classic() => const SnakesLaddersConfig(
        transitions: {
          2: 38,
          7: 14,
          8: 31,
          15: 26,
          21: 42,
          28: 84,
          36: 44,
          51: 67,
          71: 91,
          78: 98,
          87: 94,
          16: 6,
          46: 25,
          49: 11,
          62: 19,
          64: 60,
          74: 53,
          89: 68,
          92: 88,
          95: 75,
          99: 80,
        },
      );

  final Map<int, int> transitions;
  final bool exactFinish;
  final bool extraTurnOnSix;
}

enum RaceStatus { playing, finished }

class SnakesLaddersMove implements GameMove {
  const SnakesLaddersMove.roll();
}

class SnakesLaddersState implements SerializableGameState {
  const SnakesLaddersState({
    required this.positions,
    required this.currentPlayer,
    required this.rankings,
    required this.seed,
    required this.status,
    this.lastRoll,
    this.lastPath = const [],
  });

  factory SnakesLaddersState.initial({required int players, int seed = 100}) {
    if (players < 2 || players > 4) {throw ArgumentError('Players must be between 2 and 4');}
    return SnakesLaddersState(
      positions: List<int>.filled(players, 0),
      currentPlayer: 0,
      rankings: const [],
      seed: seed,
      status: RaceStatus.playing,
    );
  }

  final List<int> positions;
  final int currentPlayer;
  final List<int> rankings;
  final int seed;
  final RaceStatus status;
  final int? lastRoll;
  final List<int> lastPath;

  SnakesLaddersState copyWith({
    List<int>? positions,
    int? currentPlayer,
    List<int>? rankings,
    int? seed,
    RaceStatus? status,
    int? lastRoll,
    List<int>? lastPath,
  }) =>
      SnakesLaddersState(
        positions: positions ?? this.positions,
        currentPlayer: currentPlayer ?? this.currentPlayer,
        rankings: rankings ?? this.rankings,
        seed: seed ?? this.seed,
        status: status ?? this.status,
        lastRoll: lastRoll ?? this.lastRoll,
        lastPath: lastPath ?? this.lastPath,
      );

  Map<String, Object?> toJson() => {
        'positions': positions,
        'currentPlayer': currentPlayer,
        'rankings': rankings,
        'seed': seed,
        'status': status.name,
        'lastRoll': lastRoll,
        'lastPath': lastPath,
      };

  factory SnakesLaddersState.fromJson(Map<String, dynamic> json) => SnakesLaddersState(
        positions: (json['positions'] as List).cast<int>(),
        currentPlayer: json['currentPlayer'] as int,
        rankings: (json['rankings'] as List).cast<int>(),
        seed: json['seed'] as int,
        status: RaceStatus.values.byName(json['status'] as String),
        lastRoll: json['lastRoll'] as int?,
        lastPath: (json['lastPath'] as List? ?? const []).cast<int>(),
      );

  @override
  String serialize() => jsonEncode(toJson());

  @override
  String stateHash() => sha256.convert(utf8.encode(serialize())).toString();
}

class SnakesLaddersEngine implements GameEngine<SnakesLaddersState, SnakesLaddersMove> {
  SnakesLaddersEngine({SnakesLaddersState? initial, SnakesLaddersConfig? config})
      : _state = initial ?? SnakesLaddersState.initial(players: 2),
        config = config ?? SnakesLaddersConfig.classic();

  SnakesLaddersState _state;
  final SnakesLaddersConfig config;
  final List<SnakesLaddersState> _history = [];

  @override
  SnakesLaddersState get state => _state;

  @override
  List<SnakesLaddersMove> legalMoves() => _state.status == RaceStatus.playing
      ? const [SnakesLaddersMove.roll()]
      : const [];

  @override
  bool isLegal(SnakesLaddersMove move) => _state.status == RaceStatus.playing;

  @override
  SnakesLaddersState apply(SnakesLaddersMove move) {
    if (!isLegal(move)) {throw StateError('Race is already finished');}
    _history.add(_state);
    final rng = DeterministicRandom(_state.seed);
    final roll = rng.nextInt(6) + 1;
    final player = _state.currentPlayer;
    final positions = List<int>.from(_state.positions);
    final rankings = List<int>.from(_state.rankings);
    final current = positions[player];
    var target = current + roll;
    final path = <int>[];

    if (target > 100 && config.exactFinish) {
      target = current;
    } else {
      target = target.clamp(0, 100).toInt();
      for (var cell = current + 1; cell <= target; cell++) {
        path.add(cell);
      }
      final transitioned = config.transitions[target];
      if (transitioned != null) {
        target = transitioned;
        path.add(target);
      }
    }

    positions[player] = target;
    if (target == 100 && !rankings.contains(player)) {rankings.add(player);}

    var status = RaceStatus.playing;
    if (rankings.length == positions.length - 1) {
      final last = [for (var i = 0; i < positions.length; i++) if (!rankings.contains(i)) i].single;
      rankings.add(last);
      status = RaceStatus.finished;
    }

    var nextPlayer = player;
    if (status == RaceStatus.playing && !(roll == 6 && config.extraTurnOnSix) && target != 100) {
      do {
        nextPlayer = (nextPlayer + 1) % positions.length;
      } while (rankings.contains(nextPlayer));
    } else if (target == 100 && status == RaceStatus.playing) {
      do {
        nextPlayer = (nextPlayer + 1) % positions.length;
      } while (rankings.contains(nextPlayer));
    }

    _state = _state.copyWith(
      positions: positions,
      rankings: rankings,
      currentPlayer: nextPlayer,
      seed: rng.state,
      status: status,
      lastRoll: roll,
      lastPath: path,
    );
    return _state;
  }

  @override
  SnakesLaddersState undo() {
    if (_history.isEmpty) {throw StateError('Nothing to undo');}
    _state = _history.removeLast();
    return _state;
  }

  @override
  void restore(SnakesLaddersState state) {
    _history.clear();
    _state = state;
  }

  static int rowForCell(int cell) => (cell - 1) ~/ 10;

  static int columnForCell(int cell) {
    final row = rowForCell(cell);
    final offset = (cell - 1) % 10;
    return row.isEven ? offset : 9 - offset;
  }
}


class SnakesLaddersBot implements GameBot<SnakesLaddersState, SnakesLaddersMove> {
  const SnakesLaddersBot();

  @override
  Future<SnakesLaddersMove> chooseMove(SnakesLaddersState state, BotDifficulty difficulty) async {
    if (state.status != RaceStatus.playing) {throw StateError('Race is finished');}
    return const SnakesLaddersMove.roll();
  }
}
