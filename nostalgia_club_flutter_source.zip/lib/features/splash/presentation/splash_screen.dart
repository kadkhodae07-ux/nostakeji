import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:nostalgia_club/core/config/app_config.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/storage/local_profile_repository.dart';
import 'package:nostalgia_club/features/game_catalog/domain/game_definition.dart';
import 'package:nostalgia_club/features/game_catalog/domain/game_setup.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_background.dart';

class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..forward();
    unawaited(_initialize());
  }

  Future<void> _initialize() async {
    final minimumDelay = Future<void>.delayed(const Duration(milliseconds: 1500));
    final profiles = ref.read(localProfileRepositoryProvider);
    try {
      for (final game in GameCatalog.all) {
        final setup = await ref.read(gameSetupStorageProvider).load(game.key);
        if (setup != null) {
          ref.read(gameSetupProvider.notifier).save(game.key, setup);
        }
      }
      final hasSession = await profiles.hasSession();
      final onboardingSeen = await profiles.hasSeenOnboarding();
      await minimumDelay;
      if (!mounted) {return;}
      if (hasSession) {
        context.go('/home');
      } else if (onboardingSeen) {
        context.go('/guest');
      } else {
        context.go('/onboarding');
      }
    } catch (_) {
      await minimumDelay;
      if (mounted) {context.go('/onboarding');}
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AppBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Center(
          child: FadeTransition(
            opacity: CurvedAnimation(parent: _controller, curve: Curves.easeOut),
            child: ScaleTransition(
              scale: Tween(begin: 0.86, end: 1.0).animate(
                CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 112,
                    height: 112,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.brass.withValues(alpha: 0.12),
                      border: Border.all(color: AppColors.brassBright, width: 1.4),
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.brass.withValues(alpha: 0.25),
                          blurRadius: 42,
                        ),
                      ],
                    ),
                    alignment: Alignment.center,
                    child: const AppIcon('logo', size: 66, color: AppColors.brassBright),
                  ),
                  const SizedBox(height: 28),
                  Text(AppConfig.appNameFa, style: Theme.of(context).textTheme.displaySmall),
                  const SizedBox(height: 8),
                  const Text(
                    AppConfig.studioName,
                    style: TextStyle(color: AppColors.muted, letterSpacing: 1.2),
                  ),
                  const SizedBox(height: 34),
                  const _LoadingOrnament(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _LoadingOrnament extends StatefulWidget {
  const _LoadingOrnament();

  @override
  State<_LoadingOrnament> createState() => _LoadingOrnamentState();
}

class _LoadingOrnamentState extends State<_LoadingOrnament>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 100,
      height: 8,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) => CustomPaint(
          painter: _OrnamentPainter(_controller.value),
        ),
      ),
    );
  }
}

class _OrnamentPainter extends CustomPainter {
  const _OrnamentPainter(this.progress);
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final base = Paint()..color = AppColors.brass.withValues(alpha: 0.18);
    final active = Paint()..color = AppColors.brassBright;
    canvas.drawRRect(
      RRect.fromRectAndRadius(Offset.zero & size, const Radius.circular(8)),
      base,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(0, 0, size.width * progress, size.height),
        const Radius.circular(8),
      ),
      active,
    );
  }

  @override
  bool shouldRepaint(covariant _OrnamentPainter oldDelegate) =>
      oldDelegate.progress != progress;
}
