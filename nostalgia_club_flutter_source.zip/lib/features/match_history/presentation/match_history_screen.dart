import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/storage/match_history_repository.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_background.dart';
import 'package:nostalgia_club/shared/widgets/app_top_bar.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';
import 'package:nostalgia_club/shared/widgets/state_view.dart';

class MatchHistoryScreen extends ConsumerWidget {
  const MatchHistoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final history = ref.watch(matchHistoryProvider);
    final count = history.asData?.value.length ?? 0;
    return AppBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Column(
          children: [
            AppTopBar(
              title: 'تاریخچه مسابقات',
              subtitle: history.isLoading ? 'در حال خواندن دیتابیس محلی' : '$count رکورد محلی',
            ),
            Expanded(
              child: history.when(
                loading: () => const Padding(
                  padding: EdgeInsets.all(24),
                  child: StateView(
                    icon: 'history',
                    title: 'در حال بازیابی تاریخچه',
                    description: 'رکوردهای Drift و جزئیات مسابقات بررسی می‌شوند.',
                    loading: true,
                  ),
                ),
                error: (error, _) => Padding(
                  padding: const EdgeInsets.all(24),
                  child: StateView(
                    icon: 'warning',
                    title: 'خواندن تاریخچه ممکن نشد',
                    description: '$error',
                    actionLabel: 'تلاش دوباره',
                    onAction: () => ref.invalidate(matchHistoryProvider),
                  ),
                ),
                data: (items) => items.isEmpty
                    ? const Padding(
                        padding: EdgeInsets.all(24),
                        child: StateView(
                          icon: 'history',
                          title: 'هنوز مسابقه‌ای ثبت نشده است',
                          description: 'پس از پایان یک بازی، نتیجه و مدت آن به‌صورت محلی در این بخش ذخیره می‌شود.',
                        ),
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
                        itemCount: items.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (context, index) => _HistoryCard(item: items[index]),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HistoryCard extends ConsumerWidget {
  const _HistoryCard({required this.item});
  final LocalMatchHistoryItem item;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return GildedPanel(
      child: Row(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: AppColors.brass.withValues(alpha: 0.12),
            ),
            alignment: Alignment.center,
            child: AppIcon(item.gameKey, color: AppColors.brassBright),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_gameTitle(item.gameKey), style: const TextStyle(fontWeight: FontWeight.w900)),
                Text(
                  '${item.result} • ${item.opponent}',
                  style: const TextStyle(color: AppColors.muted, fontSize: 12),
                ),
                Text(
                  '${_dateLabel(item.finishedAt)} • ${_durationLabel(item.durationSeconds)}',
                  style: const TextStyle(color: AppColors.muted, fontSize: 10),
                ),
              ],
            ),
          ),
          InkWell(
            onTap: () => context.push('/game-detail/${item.gameKey}'),
            borderRadius: BorderRadius.circular(14),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                color: AppColors.success.withValues(alpha: 0.12),
              ),
              alignment: Alignment.center,
              child: const AppIcon('replay', size: 18, color: AppColors.success),
            ),
          ),
          const SizedBox(width: 6),
          InkWell(
            onTap: () {
              unawaited(() async {
                await ref.read(matchHistoryRepositoryProvider).delete(item.id);
                ref.invalidate(matchHistoryProvider);
              }());
            },
            borderRadius: BorderRadius.circular(14),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                color: AppColors.danger.withValues(alpha: 0.10),
              ),
              alignment: Alignment.center,
              child: const AppIcon('delete', size: 17, color: AppColors.danger),
            ),
          ),
        ],
      ),
    );
  }

  static String _gameTitle(String key) => switch (key) {
        'chess' => 'شطرنج',
        'morris' => 'دوز ۹ مهره‌ای',
        'xox' => 'XOX',
        '2048' => '۲۰۴۸',
        'snakes' => 'مار و پله',
        'ludo' => 'منچ',
        _ => key,
      };

  static String _durationLabel(int seconds) {
    final minutes = seconds ~/ 60;
    final remainder = seconds % 60;
    if (minutes == 0) return '$remainder ثانیه';
    return '$minutes دقیقه و $remainder ثانیه';
  }

  static String _dateLabel(DateTime date) {
    final local = date.toLocal();
    final now = DateTime.now();
    final sameDay = now.year == local.year && now.month == local.month && now.day == local.day;
    if (sameDay) {
      return 'امروز ${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';
    }
    return '${local.year}/${local.month.toString().padLeft(2, '0')}/${local.day.toString().padLeft(2, '0')}';
  }
}
