import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:nostalgia_club/core/game/game_models.dart';

enum MorrisPhase { placing, moving, flying, finished, draw }
enum MorrisAction { place, move, remove }

class MorrisMove implements GameMove {
  const MorrisMove({required this.action, required this.to, this.from});
  final MorrisAction action;
  final int? from;
  final int to;
}

class MorrisState implements SerializableGameState {
  const MorrisState({
    required this.board,
    required this.toPlace,
    required this.activePlayer,
    required this.pendingRemoval,
    required this.noCapturePly,
    required this.positionCounts,
    this.winner,
    this.lastMove,
    this.noCaptureDrawLimit = 100,
  });

  factory MorrisState.initial({int noCaptureDrawLimit = 100}) => MorrisState(
        board: List<int?>.filled(24, null),
        toPlace: const [9, 9],
        activePlayer: 0,
        pendingRemoval: false,
        noCapturePly: 0,
        positionCounts: const {},
        noCaptureDrawLimit: noCaptureDrawLimit,
      );

  final List<int?> board;
  final List<int> toPlace;
  final int activePlayer;
  final bool pendingRemoval;
  final int noCapturePly;
  final Map<String, int> positionCounts;
  final int? winner;
  final MorrisMove? lastMove;
  final int noCaptureDrawLimit;

  int piecesOnBoard(int player) => board.where((cell) => cell == player).length;

  MorrisPhase phaseFor(int player) {
    if (winner != null) {return MorrisPhase.finished;}
    if (noCapturePly >= noCaptureDrawLimit || positionCounts.values.any((count) => count >= 3)) {
      return MorrisPhase.draw;
    }
    if (toPlace[player] > 0) {return MorrisPhase.placing;}
    return piecesOnBoard(player) == 3 ? MorrisPhase.flying : MorrisPhase.moving;
  }

  MorrisState copyWith({
    List<int?>? board,
    List<int>? toPlace,
    int? activePlayer,
    bool? pendingRemoval,
    int? noCapturePly,
    Map<String, int>? positionCounts,
    int? winner,
    bool clearWinner = false,
    MorrisMove? lastMove,
    int? noCaptureDrawLimit,
  }) =>
      MorrisState(
        board: board ?? this.board,
        toPlace: toPlace ?? this.toPlace,
        activePlayer: activePlayer ?? this.activePlayer,
        pendingRemoval: pendingRemoval ?? this.pendingRemoval,
        noCapturePly: noCapturePly ?? this.noCapturePly,
        positionCounts: positionCounts ?? this.positionCounts,
        winner: clearWinner ? null : winner ?? this.winner,
        lastMove: lastMove ?? this.lastMove,
        noCaptureDrawLimit: noCaptureDrawLimit ?? this.noCaptureDrawLimit,
      );

  Map<String, Object?> toJson() => {
        'board': board,
        'toPlace': toPlace,
        'activePlayer': activePlayer,
        'pendingRemoval': pendingRemoval,
        'noCapturePly': noCapturePly,
        'positionCounts': positionCounts,
        'winner': winner,
        'lastMove': lastMove == null
            ? null
            : {'action': lastMove!.action.name, 'from': lastMove!.from, 'to': lastMove!.to},
        'noCaptureDrawLimit': noCaptureDrawLimit,
      };

  factory MorrisState.fromJson(Map<String, dynamic> json) {
    final moveJson = json['lastMove'] as Map<String, dynamic>?;
    return MorrisState(
      board: (json['board'] as List).cast<int?>(),
      toPlace: (json['toPlace'] as List).cast<int>(),
      activePlayer: json['activePlayer'] as int,
      pendingRemoval: json['pendingRemoval'] as bool,
      noCapturePly: json['noCapturePly'] as int,
      positionCounts: (json['positionCounts'] as Map<String, dynamic>).map((k, v) => MapEntry(k, v as int)),
      winner: json['winner'] as int?,
      lastMove: moveJson == null
          ? null
          : MorrisMove(
              action: MorrisAction.values.byName(moveJson['action'] as String),
              from: moveJson['from'] as int?,
              to: moveJson['to'] as int,
            ),
      noCaptureDrawLimit: json['noCaptureDrawLimit'] as int? ?? 100,
    );
  }

  String positionKey() => '${board.map((e) => e ?? '-').join()}:$activePlayer:${toPlace.join(',')}:$pendingRemoval';

  @override
  String serialize() => jsonEncode(toJson());

  @override
  String stateHash() => sha256.convert(utf8.encode(serialize())).toString();
}

class NineMensMorrisEngine implements GameEngine<MorrisState, MorrisMove> {
  NineMensMorrisEngine([MorrisState? initial]) : _state = initial ?? MorrisState.initial();

  static const adjacency = <List<int>>[
    [1, 9], [0, 2, 4], [1, 14], [4, 10], [1, 3, 5, 7], [4, 13],
    [7, 11], [4, 6, 8], [7, 12], [0, 10, 21], [3, 9, 11, 18], [6, 10, 15],
    [8, 13, 17], [5, 12, 14, 20], [2, 13, 23], [11, 16], [15, 17, 19], [12, 16],
    [10, 19], [16, 18, 20, 22], [13, 19], [9, 22], [19, 21, 23], [14, 22],
  ];

  static const mills = <List<int>>[
    [0, 1, 2], [3, 4, 5], [6, 7, 8], [9, 10, 11], [12, 13, 14], [15, 16, 17], [18, 19, 20], [21, 22, 23],
    [0, 9, 21], [3, 10, 18], [6, 11, 15], [1, 4, 7], [16, 19, 22], [8, 12, 17], [5, 13, 20], [2, 14, 23],
  ];

  MorrisState _state;
  final List<MorrisState> _history = [];

  @override
  MorrisState get state => _state;

  @override
  List<MorrisMove> legalMoves() {
    if (_state.winner != null || _state.phaseFor(_state.activePlayer) == MorrisPhase.draw) {return const [];}
    if (_state.pendingRemoval) {
      final opponent = 1 - _state.activePlayer;
      final outside = [for (var i = 0; i < 24; i++) if (_state.board[i] == opponent && !isInMill(i, opponent)) i];
      final removable = outside.isNotEmpty
          ? outside
          : [for (var i = 0; i < 24; i++) if (_state.board[i] == opponent) i];
      return [for (final i in removable) MorrisMove(action: MorrisAction.remove, to: i)];
    }

    final phase = _state.phaseFor(_state.activePlayer);
    if (phase == MorrisPhase.placing) {
      return [for (var i = 0; i < 24; i++) if (_state.board[i] == null) MorrisMove(action: MorrisAction.place, to: i)];
    }

    final moves = <MorrisMove>[];
    for (var from = 0; from < 24; from++) {
      if (_state.board[from] != _state.activePlayer) {continue;}
      final targets = phase == MorrisPhase.flying
          ? [for (var i = 0; i < 24; i++) if (_state.board[i] == null) i]
          : adjacency[from].where((to) => _state.board[to] == null);
      for (final to in targets) {
        moves.add(MorrisMove(action: MorrisAction.move, from: from, to: to));
      }
    }
    return moves;
  }

  @override
  bool isLegal(MorrisMove move) => legalMoves().any(
        (candidate) => candidate.action == move.action && candidate.from == move.from && candidate.to == move.to,
      );

  @override
  MorrisState apply(MorrisMove move) {
    if (!isLegal(move)) {throw StateError('Illegal Nine Men’s Morris move');}
    _history.add(_state);
    final board = List<int?>.from(_state.board);
    var toPlace = List<int>.from(_state.toPlace);
    var pendingRemoval = false;
    var activePlayer = _state.activePlayer;
    var noCapture = _state.noCapturePly;

    switch (move.action) {
      case MorrisAction.place:
        board[move.to] = activePlayer;
        toPlace[activePlayer]--;
        pendingRemoval = _formsMill(board, move.to, activePlayer);
        break;
      case MorrisAction.move:
        board[move.from!] = null;
        board[move.to] = activePlayer;
        pendingRemoval = _formsMill(board, move.to, activePlayer);
        noCapture++;
        break;
      case MorrisAction.remove:
        board[move.to] = null;
        pendingRemoval = false;
        noCapture = 0;
        activePlayer = 1 - activePlayer;
        break;
    }

    if (move.action != MorrisAction.remove && !pendingRemoval) {activePlayer = 1 - activePlayer;}

    var next = _state.copyWith(
      board: board,
      toPlace: toPlace,
      activePlayer: activePlayer,
      pendingRemoval: pendingRemoval,
      noCapturePly: noCapture,
      lastMove: move,
    );

    final counts = Map<String, int>.from(next.positionCounts);
    final key = next.positionKey();
    counts[key] = (counts[key] ?? 0) + 1;
    next = next.copyWith(positionCounts: counts);

    if (!next.pendingRemoval && next.toPlace.every((v) => v == 0)) {
      final playerToCheck = next.activePlayer;
      if (next.piecesOnBoard(playerToCheck) < 3 || _legalMovementCount(next, playerToCheck) == 0) {
        next = next.copyWith(winner: 1 - playerToCheck);
      }
    }
    _state = next;
    return _state;
  }

  int _legalMovementCount(MorrisState state, int player) {
    final phase = state.phaseFor(player);
    if (phase == MorrisPhase.flying) {return state.board.where((e) => e == null).length * state.piecesOnBoard(player);}
    var count = 0;
    for (var i = 0; i < 24; i++) {
      if (state.board[i] == player) {count += adjacency[i].where((to) => state.board[to] == null).length;}
    }
    return count;
  }

  bool isInMill(int position, int player) => _formsMill(_state.board, position, player);

  bool _formsMill(List<int?> board, int position, int player) => mills
      .where((mill) => mill.contains(position))
      .any((mill) => mill.every((index) => board[index] == player));

  @override
  MorrisState undo() {
    if (_history.isEmpty) {throw StateError('Nothing to undo');}
    _state = _history.removeLast();
    return _state;
  }

  @override
  void restore(MorrisState state) {
    _history.clear();
    _state = state;
  }
}

class MorrisBot implements GameBot<MorrisState, MorrisMove> {
  const MorrisBot();

  @override
  Future<MorrisMove> chooseMove(MorrisState state, BotDifficulty difficulty) async {
    final engine = NineMensMorrisEngine(state);
    final legal = engine.legalMoves();
    if (legal.isEmpty) {throw StateError('No legal move');}
    if (difficulty == BotDifficulty.easy) {
      return legal[Random(state.stateHash().hashCode).nextInt(legal.length)];
    }
    MorrisMove? best;
    var bestScore = -100000;
    for (final move in legal) {
      final next = NineMensMorrisEngine(state)..apply(move);
      var score = _evaluate(next.state, state.activePlayer);
      if (difficulty == BotDifficulty.hard && next.state.pendingRemoval) {score += 40;}
      if (score > bestScore) {
        bestScore = score;
        best = move;
      }
    }
    return best ?? legal.first;
  }

  int _evaluate(MorrisState state, int player) {
    final opponent = 1 - player;
    final material = (state.piecesOnBoard(player) - state.piecesOnBoard(opponent)) * 20;
    final mobility = _mobility(state, player) - _mobility(state, opponent);
    return material + mobility;
  }

  int _mobility(MorrisState state, int player) {
    if (state.toPlace[player] > 0) {return state.board.where((cell) => cell == null).length;}
    if (state.piecesOnBoard(player) == 3) {return state.board.where((cell) => cell == null).length * 3;}
    var count = 0;
    for (var i = 0; i < 24; i++) {
      if (state.board[i] == player) {
        count += NineMensMorrisEngine.adjacency[i].where((to) => state.board[to] == null).length;
      }
    }
    return count;
  }
}
