import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/game/game_models.dart';
import 'package:nostalgia_club/core/storage/game_autosave_mixin.dart';
import 'package:nostalgia_club/core/storage/match_history_repository.dart';
import 'package:nostalgia_club/features/game_catalog/domain/game_setup.dart';
import 'package:nostalgia_club/features/nine_mens_morris/domain/nine_mens_morris_engine.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_button.dart';
import 'package:nostalgia_club/shared/widgets/game_screen_frame.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';

class NineMensMorrisScreen extends ConsumerStatefulWidget {
  const NineMensMorrisScreen({super.key});
  @override
  ConsumerState<NineMensMorrisScreen> createState() => _NineMensMorrisScreenState();
}

class _NineMensMorrisScreenState extends ConsumerState<NineMensMorrisScreen> with GameAutosaveMixin<NineMensMorrisScreen> {
  late NineMensMorrisEngine _engine;
  final _bot = const MorrisBot();
  late final GameSetupConfig _setup;
  int? _selected;
  bool _thinking = false;
  DateTime _startedAt = DateTime.now();

  @override
  void initState() {
    super.initState();
    _setup = ref.read(gameSetupProvider.notifier).read('morris');
    _engine = NineMensMorrisEngine();
    Future<void>.microtask(_restore);
  }

  Future<void> _restore() async {
    try {
      final raw = await loadAutosave('morris');
      if (raw == null || !mounted) return;
      final restored = MorrisState.fromJson(jsonDecode(raw) as Map<String, dynamic>);
      setState(() => _engine = NineMensMorrisEngine(restored));
      if (_setup.withBot && _engine.state.activePlayer == 1 && _engine.state.winner == null) {
        await _playBot();
      }
    } catch (_) {
      deleteAutosave('morris');
    }
  }

  void _persist() {
    final state = _engine.state;
    final isDraw = state.phaseFor(state.activePlayer) == MorrisPhase.draw;
    if (state.winner == null && !isDraw) {
      persistAutosave('morris', state);
    } else {
      deleteAutosave('morris');
      recordMatchHistory(
        gameKey: 'morris',
        state: state,
        result: isDraw
            ? 'مساوی'
            : state.winner == 0
                ? 'برد بازیکن'
                : _setup.withBot
                    ? 'برد ربات'
                    : 'برد ${_playerName(1)}',
        outcome: isDraw
            ? LocalMatchOutcome.draw
            : state.winner == 0
                ? LocalMatchOutcome.win
                : LocalMatchOutcome.loss,
        opponent: _setup.withBot ? 'ربات ${_difficultyLabel(_setup.difficulty)}' : _playerName(1),
        startedAt: _startedAt,
      );
    }
  }

  Future<void> _tapNode(int node) async {
    if (_thinking || _engine.state.winner != null) return;
    if (_setup.withBot && _engine.state.activePlayer != 0) return;
    final state = _engine.state;
    MorrisMove? move;
    if (state.pendingRemoval) {
      move = MorrisMove(action: MorrisAction.remove, to: node);
    } else if (state.phaseFor(state.activePlayer) == MorrisPhase.placing) {
      move = MorrisMove(action: MorrisAction.place, to: node);
    } else if (_selected == null) {
      if (state.board[node] == state.activePlayer) setState(() => _selected = node);
      return;
    } else {
      move = MorrisMove(action: MorrisAction.move, from: _selected, to: node);
    }
    if (!_engine.isLegal(move)) {
      if (state.board[node] == state.activePlayer) setState(() => _selected = node);
      return;
    }
    setState(() {
      _engine.apply(move!);
      _selected = null;
    });
    _persist();
    if (_setup.withBot && _engine.state.activePlayer == 1 && _engine.state.winner == null) await _playBot();
  }

  Future<void> _playBot() async {
    setState(() => _thinking = true);
    await Future<void>.delayed(const Duration(milliseconds: 320));
    while (mounted && _engine.state.activePlayer == 1 && _engine.state.winner == null) {
      final move = await _bot.chooseMove(_engine.state, _setup.difficulty);
      setState(() => _engine.apply(move));
      _persist();
      if (!_engine.state.pendingRemoval) break;
      await Future<void>.delayed(const Duration(milliseconds: 220));
    }
    if (mounted) setState(() => _thinking = false);
  }

  @override
  Widget build(BuildContext context) {
    final state = _engine.state;
    final phase = state.phaseFor(state.activePlayer);
    final activeName = _setup.withBot && state.activePlayer == 1 ? 'ربات' : _playerName(state.activePlayer);
    final title = state.winner != null
        ? '${_setup.withBot && state.winner == 1 ? 'ربات' : _playerName(state.winner!)} برنده شد'
        : phase == MorrisPhase.draw
            ? 'بازی مساوی شد'
            : state.pendingRemoval
                ? '$activeName باید یک مهره حذف کند'
                : _thinking
                    ? 'ربات در حال بررسی حرکت است'
                    : 'نوبت $activeName • ${_phaseLabel(phase)}';
    return GameScreenFrame(
      title: 'دوز ۹ مهره‌ای',
      subtitle: _setup.withBot ? 'تخته استاندارد • بازی با ربات' : 'تخته استاندارد • دونفره محلی',
      child: Column(
        children: [
          GameStatusStrip(
            leading: const AppIcon('morris', color: AppColors.morris),
            title: title,
            trailing: Text('${state.piecesOnBoard(0)} : ${state.piecesOnBoard(1)}', style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.brassBright)),
            accent: AppColors.morris,
          ),
          const SizedBox(height: 16),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: AspectRatio(
              aspectRatio: 1,
              child: GildedPanel(
                accent: AppColors.morris,
                padding: const EdgeInsets.all(12),
                child: LayoutBuilder(
                  builder: (context, constraints) => GestureDetector(
                    onTapUp: (details) {
                      final node = _MorrisGeometry.nearest(details.localPosition, constraints.biggest);
                      if (node != null) _tapNode(node);
                    },
                    child: CustomPaint(
                      size: constraints.biggest,
                      painter: _MorrisPainter(state: state, selected: _selected, legal: _engine.legalMoves()),
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: AppButton(label: 'Undo', icon: 'back', secondary: true, onPressed: _thinking ? null : () { try { setState(() { _engine.undo(); _selected = null; }); _persist(); } catch (_) {} })),
            const SizedBox(width: 10),
            Expanded(child: AppButton(label: 'شروع تازه', icon: 'replay', onPressed: () { _startedAt = DateTime.now(); setState(() { _engine = NineMensMorrisEngine(); _selected = null; }); _persist(); })),
          ]),
        ],
      ),
    );
  }

  String _playerName(int index) => index < _setup.playerNames.length
      ? _setup.playerNames[index]
      : 'بازیکن ${index + 1}';

  String _difficultyLabel(BotDifficulty value) => switch (value) {
        BotDifficulty.easy => 'آسان',
        BotDifficulty.medium => 'متوسط',
        BotDifficulty.hard => 'سخت',
      };

  String _phaseLabel(MorrisPhase phase) => switch (phase) {
        MorrisPhase.placing => 'مرحله چیدن',
        MorrisPhase.moving => 'مرحله حرکت',
        MorrisPhase.flying => 'مرحله پرواز',
        MorrisPhase.finished => 'پایان',
        MorrisPhase.draw => 'مساوی',
      };
}

abstract final class _MorrisGeometry {
  static const points = <Offset>[
    Offset(0.06, 0.06), Offset(0.50, 0.06), Offset(0.94, 0.06),
    Offset(0.20, 0.20), Offset(0.50, 0.20), Offset(0.80, 0.20),
    Offset(0.34, 0.34), Offset(0.50, 0.34), Offset(0.66, 0.34),
    Offset(0.06, 0.50), Offset(0.20, 0.50), Offset(0.34, 0.50),
    Offset(0.66, 0.50), Offset(0.80, 0.50), Offset(0.94, 0.50),
    Offset(0.34, 0.66), Offset(0.50, 0.66), Offset(0.66, 0.66),
    Offset(0.20, 0.80), Offset(0.50, 0.80), Offset(0.80, 0.80),
    Offset(0.06, 0.94), Offset(0.50, 0.94), Offset(0.94, 0.94),
  ];

  static Offset position(int index, Size size) => Offset(points[index].dx * size.width, points[index].dy * size.height);
  static int? nearest(Offset tap, Size size) {
    var best = double.infinity;
    int? result;
    for (var i = 0; i < points.length; i++) {
      final distance = (position(i, size) - tap).distance;
      if (distance < best && distance < size.shortestSide * 0.08) {
        best = distance;
        result = i;
      }
    }
    return result;
  }
}

class _MorrisPainter extends CustomPainter {
  const _MorrisPainter({required this.state, required this.selected, required this.legal});
  final MorrisState state;
  final int? selected;
  final List<MorrisMove> legal;

  @override
  void paint(Canvas canvas, Size size) {
    final line = Paint()..color = AppColors.brass.withValues(alpha: 0.55)..strokeWidth = max(2.0, size.shortestSide * 0.007)..style = PaintingStyle.stroke;
    for (final mill in NineMensMorrisEngine.mills) {
      final a = _MorrisGeometry.position(mill.first, size);
      final b = _MorrisGeometry.position(mill.last, size);
      canvas.drawLine(a, b, line);
    }
    final legalTargets = legal.map((m) => m.to).toSet();
    for (var i = 0; i < 24; i++) {
      final center = _MorrisGeometry.position(i, size);
      final node = Paint()..color = legalTargets.contains(i) ? AppColors.success.withValues(alpha: 0.45) : AppColors.parchment.withValues(alpha: 0.5);
      canvas.drawCircle(center, size.shortestSide * 0.018, node);
      final player = state.board[i];
      if (player != null) {
        final fill = Paint()..color = player == 0 ? AppColors.brassBright : AppColors.morris;
        final shadow = Paint()..color = Colors.black.withValues(alpha: 0.55)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7);
        canvas.drawCircle(center + const Offset(0, 4), size.shortestSide * 0.042, shadow);
        canvas.drawCircle(center, size.shortestSide * 0.042, fill);
        canvas.drawCircle(center, size.shortestSide * 0.042, Paint()..color = AppColors.parchment.withValues(alpha: 0.55)..style = PaintingStyle.stroke..strokeWidth = 1.3);
      }
      if (selected == i) {
        canvas.drawCircle(center, size.shortestSide * 0.058, Paint()..color = AppColors.success..style = PaintingStyle.stroke..strokeWidth = 3);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _MorrisPainter oldDelegate) => oldDelegate.state.stateHash() != state.stateHash() || oldDelegate.selected != selected;
}
