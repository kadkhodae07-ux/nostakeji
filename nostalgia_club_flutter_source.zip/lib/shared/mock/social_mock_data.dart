class MockUser {
  const MockUser({required this.id, required this.name, required this.level, required this.online, required this.favoriteGame});
  final String id;
  final String name;
  final int level;
  final bool online;
  final String favoriteGame;
}

class MockConversation {
  const MockConversation({required this.id, required this.user, required this.lastMessage, required this.unread, required this.time});
  final String id;
  final MockUser user;
  final String lastMessage;
  final int unread;
  final String time;
}

abstract final class SocialMockData {
  static const users = [
    MockUser(id: 'u1', name: 'آرمان', level: 24, online: true, favoriteGame: 'شطرنج'),
    MockUser(id: 'u2', name: 'سارا', level: 19, online: true, favoriteGame: 'منچ'),
    MockUser(id: 'u3', name: 'نیما', level: 31, online: false, favoriteGame: 'دوز ۹ مهره‌ای'),
    MockUser(id: 'u4', name: 'هلیا', level: 17, online: true, favoriteGame: '۲۰۴۸'),
    MockUser(id: 'u5', name: 'کیان', level: 28, online: false, favoriteGame: 'مار و پله'),
  ];

  static const conversations = [
    MockConversation(id: 'c1', user: users[0], lastMessage: 'یک دست شطرنج؟', unread: 2, time: '۱۸:۴۲'),
    MockConversation(id: 'c2', user: users[1], lastMessage: 'اتاق خصوصی را ساختم.', unread: 0, time: '۱۷:۱۰'),
    MockConversation(id: 'c3', user: users[2], lastMessage: 'بازی خوبی بود 👌', unread: 0, time: 'دیروز'),
  ];
}
