import 'package:flutter/material.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';

class AppBackground extends StatelessWidget {
  const AppBackground({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(0.25, -0.65),
          radius: 1.25,
          colors: [Color(0xFF2B2620), AppColors.charcoal, AppColors.voidBlack],
          stops: [0, 0.48, 1],
        ),
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          CustomPaint(painter: _TexturePainter()),
          child,
        ],
      ),
    );
  }
}

class _TexturePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0x0CFFFFFF);
    for (var i = 0; i < 90; i++) {
      final x = ((i * 67) % 997) / 997 * size.width;
      final y = ((i * 131) % 991) / 991 * size.height;
      canvas.drawCircle(Offset(x, y), i % 3 == 0 ? 0.8 : 0.45, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
