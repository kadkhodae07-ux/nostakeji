import 'dart:async';

import 'package:flutter/material.dart';
import 'package:nostalgia_club/core/audio/audio_service.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/design_system/app_radii.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';

class AppButton extends StatelessWidget {
  const AppButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.secondary = false,
    this.expanded = true,
  });

  final String label;
  final VoidCallback? onPressed;
  final String? icon;
  final bool secondary;
  final bool expanded;

  @override
  Widget build(BuildContext context) {
    final child = ConstrainedBox(
      constraints: const BoxConstraints(minHeight: 52),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        child: Row(
          mainAxisSize: expanded ? MainAxisSize.max : MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (icon != null) ...[
              AppIcon(icon!, size: 21, color: secondary ? AppColors.parchment : AppColors.voidBlack),
              const SizedBox(width: 10),
            ],
            Flexible(
              child: Text(
                label,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: secondary ? AppColors.parchment : AppColors.voidBlack,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        ),
      ),
    );

    final decorated = DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppRadii.medium),
        gradient: secondary
            ? const LinearGradient(colors: [AppColors.panel, AppColors.raised])
            : const LinearGradient(colors: [AppColors.brassBright, AppColors.brass]),
        border: Border.all(color: AppColors.brass.withValues(alpha: secondary ? 0.4 : 0.75)),
        boxShadow: onPressed == null
            ? const []
            : [BoxShadow(color: AppColors.brass.withValues(alpha: 0.18), blurRadius: 16, offset: const Offset(0, 8))],
      ),
      child: child,
    );

    return Opacity(
      opacity: onPressed == null ? 0.45 : 1,
      child: Semantics(
        button: true,
        enabled: onPressed != null,
        child: InkWell(
          onTap: onPressed == null
              ? null
              : () {
                  unawaited(AudioService.instance.playTap());
                  onPressed!();
                },
          borderRadius: BorderRadius.circular(AppRadii.medium),
          child: expanded ? SizedBox(width: double.infinity, child: decorated) : decorated,
        ),
      ),
    );
  }
}
