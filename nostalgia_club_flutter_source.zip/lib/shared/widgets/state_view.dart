import 'package:flutter/material.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';
import 'package:nostalgia_club/shared/widgets/app_button.dart';
import 'package:nostalgia_club/shared/widgets/gilded_panel.dart';

class StateView extends StatelessWidget {
  const StateView({
    super.key,
    required this.icon,
    required this.title,
    required this.description,
    this.actionLabel,
    this.onAction,
    this.loading = false,
  });

  final String icon;
  final String title;
  final String description;
  final String? actionLabel;
  final VoidCallback? onAction;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: GildedPanel(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.brass.withValues(alpha: 0.12),
                ),
                alignment: Alignment.center,
                child: loading
                    ? const SizedBox(
                        width: 30,
                        height: 30,
                        child: CircularProgressIndicator(strokeWidth: 2.5),
                      )
                    : AppIcon(icon, size: 34, color: AppColors.brassBright),
              ),
              const SizedBox(height: 18),
              Text(title, style: Theme.of(context).textTheme.titleLarge, textAlign: TextAlign.center),
              const SizedBox(height: 8),
              Text(description, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppColors.muted), textAlign: TextAlign.center),
              if (actionLabel != null) ...[
                const SizedBox(height: 20),
                AppButton(label: actionLabel!, onPressed: onAction, icon: 'replay'),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
