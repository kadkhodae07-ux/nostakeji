import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/shared/icons/app_icon.dart';

class AppTopBar extends StatelessWidget {
  const AppTopBar({super.key, required this.title, this.subtitle, this.actions = const [], this.showBack = true});

  final String title;
  final String? subtitle;
  final List<Widget> actions;
  final bool showBack;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
        child: Row(
          children: [
            if (showBack)
              _CircleAction(
                label: 'بازگشت',
                icon: 'back',
                onTap: () => context.canPop() ? context.pop() : context.go('/home'),
              ),
            if (showBack) const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: Theme.of(context).textTheme.titleLarge),
                  if (subtitle != null)
                    Text(subtitle!, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: AppColors.muted)),
                ],
              ),
            ),
            ...actions,
          ],
        ),
      ),
    );
  }
}

class _CircleAction extends StatelessWidget {
  const _CircleAction({required this.label, required this.icon, required this.onTap});
  final String label;
  final String icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: label,
      button: true,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppColors.raised,
            border: Border.all(color: AppColors.brass.withValues(alpha: 0.28)),
          ),
          alignment: Alignment.center,
          child: AppIcon(icon, size: 20),
        ),
      ),
    );
  }
}
