import 'package:flutter/material.dart';
import 'package:nostalgia_club/core/config/app_config.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';

class MockBadge extends StatelessWidget {
  const MockBadge({super.key});

  @override
  Widget build(BuildContext context) {
    if (!AppConfig.mockMode) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: AppColors.info.withValues(alpha: 0.15),
        border: Border.all(color: AppColors.info.withValues(alpha: 0.55)),
        borderRadius: BorderRadius.circular(999),
      ),
      child: const Text('Mock Mode', style: TextStyle(fontSize: 10, color: AppColors.info, fontWeight: FontWeight.w800)),
    );
  }
}
