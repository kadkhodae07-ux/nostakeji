import 'dart:async';

import 'package:flutter/material.dart';
import 'package:nostalgia_club/core/audio/audio_service.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';
import 'package:nostalgia_club/core/design_system/app_radii.dart';

class GildedPanel extends StatelessWidget {
  const GildedPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
    this.accent,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final Color? accent;

  @override
  Widget build(BuildContext context) {
    final panel = AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppRadii.medium),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.panelSoft, AppColors.raised],
        ),
        border: Border.all(color: (accent ?? AppColors.brass).withValues(alpha: 0.30)),
        boxShadow: const [
          BoxShadow(color: Color(0x66000000), blurRadius: 20, offset: Offset(0, 12)),
          BoxShadow(color: Color(0x16000000), blurRadius: 2, offset: Offset(0, 1)),
        ],
      ),
      child: child,
    );
    if (onTap == null) {return panel;}
    return Semantics(
      button: true,
      child: InkWell(
        onTap: () {
          unawaited(AudioService.instance.playTap());
          onTap!();
        },
        borderRadius: BorderRadius.circular(AppRadii.medium),
        child: panel,
      ),
    );
  }
}
