import 'dart:async';

class CreateMatchRequest {
  const CreateMatchRequest({required this.gameKey, required this.playerCount, this.options = const {}});
  final String gameKey;
  final int playerCount;
  final Map<String, Object?> options;
}

class SubmitMoveRequest {
  const SubmitMoveRequest({required this.matchId, required this.move, required this.expectedStateHash});
  final String matchId;
  final Map<String, Object?> move;
  final String expectedStateHash;
}

class MatchModel {
  const MatchModel({required this.id, required this.gameKey, required this.state});
  final String id;
  final String gameKey;
  final Map<String, Object?> state;
}

class MatchEvent {
  const MatchEvent({required this.type, required this.payload});
  final String type;
  final Map<String, Object?> payload;
}

class MoveResult {
  const MoveResult({required this.accepted, required this.state, this.reason});
  final bool accepted;
  final Map<String, Object?> state;
  final String? reason;
}

abstract interface class MatchRepository {
  Future<MatchModel> createLocalMatch(CreateMatchRequest request);
  Future<MatchModel> createOnlineMatch(CreateMatchRequest request);
  Stream<MatchEvent> watchMatch(String matchId);
  Future<MoveResult> submitMove(SubmitMoveRequest request);
}

class LocalMatchRepository implements MatchRepository {
  final _events = StreamController<MatchEvent>.broadcast();

  @override
  Future<MatchModel> createLocalMatch(CreateMatchRequest request) async => MatchModel(
        id: 'local-${DateTime.now().microsecondsSinceEpoch}',
        gameKey: request.gameKey,
        state: {'mode': 'local', 'playerCount': request.playerCount, ...request.options},
      );

  @override
  Future<MatchModel> createOnlineMatch(CreateMatchRequest request) =>
      throw UnsupportedError('Online matchmaking is disabled in the offline release.');

  @override
  Future<MoveResult> submitMove(SubmitMoveRequest request) async {
    final state = {'lastMove': request.move, 'expectedStateHash': request.expectedStateHash};
    _events.add(MatchEvent(type: 'match:state', payload: state));
    return MoveResult(accepted: true, state: state);
  }

  @override
  Stream<MatchEvent> watchMatch(String matchId) => _events.stream;
}

class MockMatchRepository extends LocalMatchRepository {
  @override
  Future<MatchModel> createOnlineMatch(CreateMatchRequest request) async => MatchModel(
        id: 'mock-${DateTime.now().microsecondsSinceEpoch}',
        gameKey: request.gameKey,
        state: {'mode': 'mock-online', 'playerCount': request.playerCount, ...request.options},
      );
}

class RemoteMatchRepository implements MatchRepository {
  const RemoteMatchRepository();

  Never _disabled() => throw UnsupportedError(
        'Remote repository contract exists, but network access is intentionally disabled in this release.',
      );

  @override
  Future<MatchModel> createLocalMatch(CreateMatchRequest request) async => _disabled();
  @override
  Future<MatchModel> createOnlineMatch(CreateMatchRequest request) async => _disabled();
  @override
  Future<MoveResult> submitMove(SubmitMoveRequest request) async => _disabled();
  @override
  Stream<MatchEvent> watchMatch(String matchId) => const Stream.empty();
}
