import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nostalgia_club/core/storage/app_database.dart';
import 'package:nostalgia_club/core/storage/database_provider.dart';

enum LocalMatchOutcome { win, loss, draw, score, ranking }

class LocalMatchHistoryItem {
  const LocalMatchHistoryItem({
    required this.id,
    required this.gameKey,
    required this.result,
    required this.outcome,
    required this.opponent,
    required this.durationSeconds,
    required this.finishedAt,
    required this.stateHash,
  });

  final String id;
  final String gameKey;
  final String result;
  final LocalMatchOutcome outcome;
  final String opponent;
  final int durationSeconds;
  final DateTime finishedAt;
  final String stateHash;

  Map<String, Object?> toJson() => {
        'result': result,
        'outcome': outcome.name,
        'opponent': opponent,
        'durationSeconds': durationSeconds,
        'stateHash': stateHash,
      };

  factory LocalMatchHistoryItem.fromEntry(LocalHistoryEntry entry) {
    final payload = jsonDecode(entry.payload) as Map<String, dynamic>;
    return LocalMatchHistoryItem(
      id: entry.id,
      gameKey: entry.gameKey,
      result: payload['result'] as String? ?? 'پایان مسابقه',
      outcome: LocalMatchOutcome.values.byName(
        payload['outcome'] as String? ?? 'ranking',
      ),
      opponent: payload['opponent'] as String? ?? 'محلی',
      durationSeconds: payload['durationSeconds'] as int? ?? 0,
      finishedAt: entry.finishedAt,
      stateHash: payload['stateHash'] as String? ?? '',
    );
  }
}

abstract interface class MatchHistoryRepository {
  Future<List<LocalMatchHistoryItem>> load();
  Future<void> record(LocalMatchHistoryItem item);
  Future<void> delete(String id);
}

class DriftMatchHistoryRepository implements MatchHistoryRepository {
  const DriftMatchHistoryRepository(this._database);
  final AppDatabase _database;

  @override
  Future<List<LocalMatchHistoryItem>> load() async =>
      (await _database.readHistoryEntries()).map(LocalMatchHistoryItem.fromEntry).toList();

  @override
  Future<void> record(LocalMatchHistoryItem item) => _database.saveHistoryEntry(
        idValue: item.id,
        gameKeyValue: item.gameKey,
        payloadValue: jsonEncode(item.toJson()),
        finishedAtValue: item.finishedAt,
      );

  @override
  Future<void> delete(String id) => _database.deleteHistoryEntry(id);
}

final matchHistoryRepositoryProvider = Provider<MatchHistoryRepository>(
  (ref) => DriftMatchHistoryRepository(ref.watch(appDatabaseProvider)),
);

final matchHistoryProvider = FutureProvider<List<LocalMatchHistoryItem>>(
  (ref) => ref.watch(matchHistoryRepositoryProvider).load(),
);
