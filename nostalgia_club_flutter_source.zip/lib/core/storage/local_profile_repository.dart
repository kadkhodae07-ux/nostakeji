import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nostalgia_club/core/storage/app_database.dart';
import 'package:nostalgia_club/core/storage/database_provider.dart';

class LocalGuestProfile {
  const LocalGuestProfile({
    required this.displayName,
    required this.localId,
    required this.createdAt,
  });

  final String displayName;
  final String localId;
  final DateTime createdAt;

  Map<String, Object?> toJson() => {
        'displayName': displayName,
        'localId': localId,
        'createdAt': createdAt.toUtc().toIso8601String(),
      };

  factory LocalGuestProfile.fromJson(Map<String, dynamic> json) => LocalGuestProfile(
        displayName: json['displayName'] as String,
        localId: json['localId'] as String,
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}

class LocalProfileRepository {
  const LocalProfileRepository(this._database);
  final AppDatabase _database;

  Future<LocalGuestProfile?> load() async {
    final raw = await _database.readSetting('guestProfile');
    if (raw == null) {return null;}
    return LocalGuestProfile.fromJson(jsonDecode(raw) as Map<String, dynamic>);
  }

  Future<LocalGuestProfile> createOrUpdate(String displayName) async {
    final existing = await load();
    final now = DateTime.now().toUtc();
    final profile = LocalGuestProfile(
      displayName: displayName.trim(),
      localId: existing?.localId ?? 'LOCAL-${now.microsecondsSinceEpoch.toRadixString(36).toUpperCase()}',
      createdAt: existing?.createdAt ?? now,
    );
    await _database.writeSetting('guestProfile', jsonEncode(profile.toJson()));
    await _database.writeSetting('guestSession', 'true');
    return profile;
  }

  Future<void> signOut() => _database.writeSetting('guestSession', 'false');

  Future<bool> hasSession() async => await _database.readSetting('guestSession') == 'true';

  Future<bool> hasSeenOnboarding() async => await _database.readSetting('onboardingSeen') == 'true';

  Future<void> markOnboardingSeen() => _database.writeSetting('onboardingSeen', 'true');
}

final localProfileRepositoryProvider = Provider<LocalProfileRepository>(
  (ref) => LocalProfileRepository(ref.watch(appDatabaseProvider)),
);

final localGuestProfileProvider = FutureProvider<LocalGuestProfile?>((ref) {
  return ref.watch(localProfileRepositoryProvider).load();
});
