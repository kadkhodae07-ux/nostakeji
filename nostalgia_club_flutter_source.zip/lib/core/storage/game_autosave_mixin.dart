import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nostalgia_club/core/game/game_models.dart';
import 'package:nostalgia_club/core/storage/match_history_repository.dart';
import 'package:nostalgia_club/core/storage/saved_game_repository.dart';

mixin GameAutosaveMixin<T extends ConsumerStatefulWidget> on ConsumerState<T> {
  Future<String?> loadAutosave(String gameKey) =>
      ref.read(savedGameRepositoryProvider).load(gameKey);

  void persistAutosave(String gameKey, SerializableGameState state) {
    unawaited(() async {
      await ref.read(savedGameRepositoryProvider).save(
            gameKey: gameKey,
            serializedState: state.serialize(),
            stateHash: state.stateHash(),
          );
      if (mounted) {ref.invalidate(savedGameExistsProvider(gameKey));}
    }());
  }

  void deleteAutosave(String gameKey) {
    unawaited(() async {
      await ref.read(savedGameRepositoryProvider).delete(gameKey);
      if (mounted) {ref.invalidate(savedGameExistsProvider(gameKey));}
    }());
  }

  void recordMatchHistory({
    required String gameKey,
    required SerializableGameState state,
    required String result,
    required LocalMatchOutcome outcome,
    required String opponent,
    required DateTime startedAt,
  }) {
    final now = DateTime.now().toUtc();
    final hash = state.stateHash();
    final repository = ref.read(matchHistoryRepositoryProvider);
    unawaited(() async {
      await repository.record(
        LocalMatchHistoryItem(
          id: '$gameKey:$hash',
          gameKey: gameKey,
          result: result,
          outcome: outcome,
          opponent: opponent,
          durationSeconds: now.difference(startedAt.toUtc()).inSeconds,
          finishedAt: now,
          stateHash: hash,
        ),
      );
      if (mounted) {ref.invalidate(matchHistoryProvider);}
    }());
  }
}
