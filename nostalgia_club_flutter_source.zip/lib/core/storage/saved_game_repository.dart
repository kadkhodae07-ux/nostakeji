import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nostalgia_club/core/storage/app_database.dart';
import 'package:nostalgia_club/core/storage/database_provider.dart';

abstract interface class SavedGameRepository {
  Future<String?> load(String gameKey);
  Future<void> save({required String gameKey, required String serializedState, required String stateHash});
  Future<void> delete(String gameKey);
}

class DriftSavedGameRepository implements SavedGameRepository {
  const DriftSavedGameRepository(this._database);

  final AppDatabase _database;

  @override
  Future<String?> load(String gameKey) => _database.readGameSnapshot(gameKey);

  @override
  Future<void> save({required String gameKey, required String serializedState, required String stateHash}) =>
      _database.saveGameSnapshot(
        gameKeyValue: gameKey,
        serializedStateValue: serializedState,
        stateHashValue: stateHash,
      );

  @override
  Future<void> delete(String gameKey) => _database.deleteGameSnapshot(gameKey);
}

final savedGameRepositoryProvider = Provider<SavedGameRepository>(
  (ref) => DriftSavedGameRepository(ref.watch(appDatabaseProvider)),
);

final savedGameExistsProvider = FutureProvider.family<bool, String>((ref, gameKey) async {
  final snapshot = await ref.watch(savedGameRepositoryProvider).load(gameKey);
  return snapshot != null;
});
