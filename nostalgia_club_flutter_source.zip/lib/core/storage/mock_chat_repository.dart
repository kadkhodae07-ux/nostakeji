import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nostalgia_club/core/storage/app_database.dart';
import 'package:nostalgia_club/core/storage/database_provider.dart';

class LocalChatMessage {
  const LocalChatMessage({
    required this.id,
    required this.conversationId,
    required this.text,
    required this.mine,
    required this.createdAt,
    this.replyTo,
    this.edited = false,
    this.deliveryState = 'read',
  });

  final String id;
  final String conversationId;
  final String text;
  final bool mine;
  final DateTime createdAt;
  final String? replyTo;
  final bool edited;
  final String deliveryState;

  LocalChatMessage copyWith({
    String? text,
    String? replyTo,
    bool clearReply = false,
    bool? edited,
    String? deliveryState,
  }) =>
      LocalChatMessage(
        id: id,
        conversationId: conversationId,
        text: text ?? this.text,
        mine: mine,
        createdAt: createdAt,
        replyTo: clearReply ? null : replyTo ?? this.replyTo,
        edited: edited ?? this.edited,
        deliveryState: deliveryState ?? this.deliveryState,
      );

  Map<String, Object?> toJson() => {
        'id': id,
        'conversationId': conversationId,
        'text': text,
        'mine': mine,
        'createdAt': createdAt.toUtc().toIso8601String(),
        'replyTo': replyTo,
        'edited': edited,
        'deliveryState': deliveryState,
      };

  factory LocalChatMessage.fromJson(Map<String, dynamic> json) => LocalChatMessage(
        id: json['id'] as String,
        conversationId: json['conversationId'] as String,
        text: json['text'] as String,
        mine: json['mine'] as bool,
        createdAt: DateTime.parse(json['createdAt'] as String),
        replyTo: json['replyTo'] as String?,
        edited: json['edited'] as bool? ?? false,
        deliveryState: json['deliveryState'] as String? ?? 'read',
      );
}

class MockChatRepository {
  MockChatRepository(this._database);
  final AppDatabase _database;

  Future<List<LocalChatMessage>> load(String conversationId) async {
    final rows = await _database.readMockMessages(conversationId);
    return rows
        .map((row) => LocalChatMessage.fromJson(jsonDecode(row.payload) as Map<String, dynamic>))
        .toList(growable: false);
  }

  Future<void> save(LocalChatMessage message) => _database.saveMockMessage(
        idValue: message.id,
        conversationIdValue: message.conversationId,
        payloadValue: jsonEncode(message.toJson()),
        createdAtValue: message.createdAt.toUtc(),
      );

  Future<void> delete(String id) => _database.deleteMockMessage(id);

  Future<List<LocalChatMessage>> seedIfEmpty(String conversationId) async {
    final existing = await load(conversationId);
    if (existing.isNotEmpty) {return existing;}
    final now = DateTime.now().toUtc();
    final seed = [
      LocalChatMessage(
        id: '$conversationId:seed:1',
        conversationId: conversationId,
        text: 'سلام! برای یک مسابقه آماده‌ای؟',
        mine: false,
        createdAt: now.subtract(const Duration(minutes: 7)),
      ),
      LocalChatMessage(
        id: '$conversationId:seed:2',
        conversationId: conversationId,
        text: 'بله، شطرنج بدون ساعت خوبه.',
        mine: true,
        createdAt: now.subtract(const Duration(minutes: 5)),
      ),
      LocalChatMessage(
        id: '$conversationId:seed:3',
        conversationId: conversationId,
        text: 'یک دست شطرنج؟',
        mine: false,
        createdAt: now,
      ),
    ];
    for (final message in seed) {
      await save(message);
    }
    return seed;
  }
}

final mockChatRepositoryProvider = Provider<MockChatRepository>(
  (ref) => MockChatRepository(ref.watch(appDatabaseProvider)),
);
