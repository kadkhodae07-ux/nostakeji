import 'dart:io';

import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

part 'app_database.g.dart';

class LocalMockMessageEntry {
  const LocalMockMessageEntry({
    required this.id,
    required this.conversationId,
    required this.payload,
    required this.createdAt,
  });

  final String id;
  final String conversationId;
  final String payload;
  final DateTime createdAt;
}

class LocalHistoryEntry {
  const LocalHistoryEntry({
    required this.id,
    required this.gameKey,
    required this.payload,
    required this.finishedAt,
  });

  final String id;
  final String gameKey;
  final String payload;
  final DateTime finishedAt;
}

class SettingsRows extends Table {
  TextColumn get key => text()();
  TextColumn get value => text()();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  @override
  Set<Column<Object>> get primaryKey => {key};
}

class SavedMatches extends Table {
  TextColumn get id => text()();
  TextColumn get gameKey => text()();
  TextColumn get serializedState => text()();
  TextColumn get stateHash => text()();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();
  @override
  Set<Column<Object>> get primaryKey => {id};
}

class MatchHistoryRows extends Table {
  TextColumn get id => text()();
  TextColumn get gameKey => text()();
  TextColumn get payload => text()();
  DateTimeColumn get finishedAt => dateTime()();
  @override
  Set<Column<Object>> get primaryKey => {id};
}

class MockMessages extends Table {
  TextColumn get id => text()();
  TextColumn get conversationId => text()();
  TextColumn get payload => text()();
  DateTimeColumn get createdAt => dateTime()();
  @override
  Set<Column<Object>> get primaryKey => {id};
}

@DriftDatabase(tables: [SettingsRows, SavedMatches, MatchHistoryRows, MockMessages])
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());
  AppDatabase.forTesting(super.executor);

  @override
  int get schemaVersion => 1;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (m) => m.createAll(),
        onUpgrade: (m, from, to) async {
          // Future migrations are applied here without destructive resets.
        },
      );

  Future<String?> readSetting(String keyValue) async {
    final query = select(settingsRows)..where((row) => row.key.equals(keyValue));
    return (await query.getSingleOrNull())?.value;
  }

  Future<void> writeSetting(String keyValue, String valueValue) =>
      into(settingsRows).insertOnConflictUpdate(
        SettingsRowsCompanion.insert(
          key: keyValue,
          value: valueValue,
          updatedAt: Value(DateTime.now().toUtc()),
        ),
      );

  Future<void> saveGameSnapshot({
    required String gameKeyValue,
    required String serializedStateValue,
    required String stateHashValue,
  }) =>
      into(savedMatches).insertOnConflictUpdate(
        SavedMatchesCompanion.insert(
          id: 'autosave:$gameKeyValue',
          gameKey: gameKeyValue,
          serializedState: serializedStateValue,
          stateHash: stateHashValue,
          updatedAt: Value(DateTime.now().toUtc()),
        ),
      );

  Future<String?> readGameSnapshot(String gameKeyValue) async {
    final query = select(savedMatches)
      ..where((row) => row.gameKey.equals(gameKeyValue))
      ..orderBy([(row) => OrderingTerm.desc(row.updatedAt)])
      ..limit(1);
    return (await query.getSingleOrNull())?.serializedState;
  }

  Future<void> deleteGameSnapshot(String gameKeyValue) =>
      (delete(savedMatches)..where((row) => row.gameKey.equals(gameKeyValue))).go();

  Future<void> saveHistoryEntry({
    required String idValue,
    required String gameKeyValue,
    required String payloadValue,
    required DateTime finishedAtValue,
  }) =>
      into(matchHistoryRows).insertOnConflictUpdate(
        MatchHistoryRowsCompanion.insert(
          id: idValue,
          gameKey: gameKeyValue,
          payload: payloadValue,
          finishedAt: finishedAtValue.toUtc(),
        ),
      );

  Future<List<LocalHistoryEntry>> readHistoryEntries() async {
    final query = select(matchHistoryRows)
      ..orderBy([(row) => OrderingTerm.desc(row.finishedAt)]);
    final rows = await query.get();
    return [
      for (final row in rows)
        LocalHistoryEntry(
          id: row.id,
          gameKey: row.gameKey,
          payload: row.payload,
          finishedAt: row.finishedAt.toUtc(),
        ),
    ];
  }

  Future<void> deleteHistoryEntry(String idValue) =>
      (delete(matchHistoryRows)..where((row) => row.id.equals(idValue))).go();


  Future<List<LocalMockMessageEntry>> readMockMessages(String conversationIdValue) async {
    final query = select(mockMessages)
      ..where((row) => row.conversationId.equals(conversationIdValue))
      ..orderBy([(row) => OrderingTerm.asc(row.createdAt)]);
    final rows = await query.get();
    return [
      for (final row in rows)
        LocalMockMessageEntry(
          id: row.id,
          conversationId: row.conversationId,
          payload: row.payload,
          createdAt: row.createdAt.toUtc(),
        ),
    ];
  }

  Future<void> saveMockMessage({
    required String idValue,
    required String conversationIdValue,
    required String payloadValue,
    required DateTime createdAtValue,
  }) =>
      into(mockMessages).insertOnConflictUpdate(
        MockMessagesCompanion.insert(
          id: idValue,
          conversationId: conversationIdValue,
          payload: payloadValue,
          createdAt: createdAtValue.toUtc(),
        ),
      );

  Future<void> deleteMockMessage(String idValue) =>
      (delete(mockMessages)..where((row) => row.id.equals(idValue))).go();

  Future<void> clearLocalData() => transaction(() async {
        await delete(mockMessages).go();
        await delete(matchHistoryRows).go();
        await delete(savedMatches).go();
        await delete(settingsRows).go();
      });
}

LazyDatabase _openConnection() => LazyDatabase(() async {
      final dir = await getApplicationDocumentsDirectory();
      return NativeDatabase.createInBackground(
        File(p.join(dir.path, 'nostalgia_club.sqlite')),
      );
    });
