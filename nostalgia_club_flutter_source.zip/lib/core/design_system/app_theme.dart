import 'package:flutter/material.dart';
import 'package:nostalgia_club/core/design_system/app_colors.dart';

abstract final class AppTheme {
  static ThemeData get dark {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.brass,
      brightness: Brightness.dark,
      surface: AppColors.charcoal,
      error: AppColors.danger,
    ).copyWith(
      primary: AppColors.brass,
      onPrimary: AppColors.voidBlack,
      secondary: AppColors.brassBright,
      surface: AppColors.charcoal,
      onSurface: AppColors.parchment,
      outline: AppColors.brass.withValues(alpha: 0.28),
    );

    return ThemeData(
      brightness: Brightness.dark,
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: AppColors.voidBlack,
      splashFactory: InkSparkle.splashFactory,
      textTheme: const TextTheme(
        displaySmall: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, height: 1.2),
        headlineMedium: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, height: 1.35),
        titleLarge: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, height: 1.4),
        titleMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, height: 1.45),
        bodyLarge: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, height: 1.65),
        bodyMedium: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, height: 1.6),
        labelLarge: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, height: 1.3),
      ),
      dividerColor: AppColors.brass.withValues(alpha: 0.18),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.raised,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: AppColors.brass.withValues(alpha: 0.18)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: AppColors.brass.withValues(alpha: 0.18)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: const BorderSide(color: AppColors.brass, width: 1.5),
        ),
      ),
    );
  }

  static ThemeData get highContrast {
    final base = dark;
    return base.copyWith(
      colorScheme: base.colorScheme.copyWith(
        primary: AppColors.brassBright,
        secondary: AppColors.parchment,
        outline: AppColors.parchment.withValues(alpha: 0.62),
        onSurface: Colors.white,
      ),
      dividerColor: AppColors.parchment.withValues(alpha: 0.35),
    );
  }

}
