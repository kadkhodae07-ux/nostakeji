import 'package:flutter/animation.dart';

abstract final class AppMotion {
  static const quick = Duration(milliseconds: 140);
  static const standard = Duration(milliseconds: 240);
  static const deliberate = Duration(milliseconds: 420);
  static const curve = Curves.easeOutCubic;
}
