import 'package:flutter/material.dart';

abstract final class AppColors {
  static const voidBlack = Color(0xFF090A0D);
  static const charcoal = Color(0xFF12151A);
  static const raised = Color(0xFF1B1F26);
  static const panel = Color(0xFF242A32);
  static const panelSoft = Color(0xFF2B323C);
  static const brass = Color(0xFFC7A665);
  static const brassBright = Color(0xFFE3C98B);
  static const parchment = Color(0xFFF1E7D2);
  static const muted = Color(0xFFA9A399);
  static const success = Color(0xFF67B88A);
  static const danger = Color(0xFFD56A66);
  static const info = Color(0xFF6F9FC8);
  static const chess = Color(0xFF9B7A55);
  static const morris = Color(0xFFB56F5A);
  static const xox = Color(0xFF5D9A92);
  static const game2048 = Color(0xFFC18D45);
  static const snakes = Color(0xFF6A9E68);
  static const ludo = Color(0xFF6F75B7);
}
