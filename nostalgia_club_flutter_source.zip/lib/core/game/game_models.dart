import 'package:freezed_annotation/freezed_annotation.dart';

part 'game_models.freezed.dart';
part 'game_models.g.dart';

enum MatchLifecycle { initializing, waiting, playing, paused, finished, cancelled }
enum MatchOutcome { win, loss, draw, cancelled }
enum BotDifficulty { easy, medium, hard }
enum OpponentType { localHuman, localBot, onlineHuman, mock }

@freezed
class GamePlayer with _$GamePlayer {
  const factory GamePlayer({
    required String id,
    required String displayName,
    required int seat,
    required OpponentType type,
    String? colorKey,
    @Default(false) bool isWinner,
  }) = _GamePlayer;

  factory GamePlayer.fromJson(Map<String, dynamic> json) => _$GamePlayerFromJson(json);
}

@freezed
class MatchRecord with _$MatchRecord {
  const factory MatchRecord({
    required String id,
    required String gameKey,
    required DateTime startedAt,
    required DateTime finishedAt,
    required MatchOutcome outcome,
    required int durationSeconds,
    required List<GamePlayer> players,
    @Default(0) int score,
    String? serializedFinalState,
  }) = _MatchRecord;

  factory MatchRecord.fromJson(Map<String, dynamic> json) => _$MatchRecordFromJson(json);
}

abstract interface class SerializableGameState {
  String serialize();
  String stateHash();
}

abstract interface class GameMove {}

abstract interface class GameEngine<TState extends SerializableGameState, TMove extends GameMove> {
  TState get state;
  List<TMove> legalMoves();
  bool isLegal(TMove move);
  TState apply(TMove move);
  TState undo();
  void restore(TState state);
}

abstract interface class GameBot<TState, TMove> {
  Future<TMove> chooseMove(TState state, BotDifficulty difficulty);
}
