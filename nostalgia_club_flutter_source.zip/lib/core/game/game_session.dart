import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:nostalgia_club/core/game/game_models.dart';

class GameSession<TState extends SerializableGameState, TMove extends GameMove> {
  GameSession({
    required this.matchId,
    required this.gameKey,
    required this.players,
    required this.initialState,
  }) : _snapshots = [initialState];

  final String matchId;
  final String gameKey;
  final List<GamePlayer> players;
  final TState initialState;
  final List<TState> _snapshots;
  final List<TMove> _moves = [];
  MatchLifecycle lifecycle = MatchLifecycle.initializing;
  DateTime? startedAt;
  DateTime? finishedAt;

  List<TState> get snapshots => List.unmodifiable(_snapshots);
  List<TMove> get moves => List.unmodifiable(_moves);
  TState get latest => _snapshots.last;

  void start() {
    startedAt ??= DateTime.now().toUtc();
    lifecycle = MatchLifecycle.playing;
  }

  void commit(TMove move, TState state) {
    if (lifecycle != MatchLifecycle.playing) {
      throw StateError('Cannot commit move while lifecycle is $lifecycle');
    }
    _moves.add(move);
    _snapshots.add(state);
  }

  TState undo() {
    if (_snapshots.length <= 1) {throw StateError('No snapshot to undo');}
    _moves.removeLast();
    _snapshots.removeLast();
    return latest;
  }

  void pause() => lifecycle = MatchLifecycle.paused;
  void resume() => lifecycle = MatchLifecycle.playing;

  void finish() {
    lifecycle = MatchLifecycle.finished;
    finishedAt = DateTime.now().toUtc();
  }

  String integrityHash() {
    final payload = jsonEncode({
      'matchId': matchId,
      'gameKey': gameKey,
      'stateHash': latest.stateHash(),
      'moveCount': _moves.length,
    });
    return sha256.convert(utf8.encode(payload)).toString();
  }
}
