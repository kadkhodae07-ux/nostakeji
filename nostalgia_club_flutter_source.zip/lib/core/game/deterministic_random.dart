class DeterministicRandom {
  DeterministicRandom(int seed) : _state = seed & 0x7fffffff;

  int _state;
  int get state => _state;

  int nextInt(int max) {
    if (max <= 0) {throw ArgumentError.value(max, 'max', 'Must be positive');}
    _state = (1103515245 * _state + 12345) & 0x7fffffff;
    return _state % max;
  }

  double nextDouble() => nextInt(1 << 24) / (1 << 24);
}
