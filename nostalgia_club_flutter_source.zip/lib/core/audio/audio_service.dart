import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';

class AudioService {
  AudioService._();
  static final instance = AudioService._();

  final AudioPlayer _effects = AudioPlayer();
  final AudioPlayer _music = AudioPlayer();
  bool effectsEnabled = true;
  bool musicEnabled = true;
  bool hapticsEnabled = true;
  bool _musicStarted = false;

  Future<void> playTap() async {
    await _play('tap.wav');
    if (hapticsEnabled) await HapticFeedback.selectionClick();
  }

  Future<void> playMove() async {
    await _play('move.wav');
    if (hapticsEnabled) await HapticFeedback.lightImpact();
  }

  Future<void> playDice() async {
    await _play('dice.wav');
    if (hapticsEnabled) await HapticFeedback.mediumImpact();
  }

  Future<void> playWin() async {
    await _play('win.wav');
    if (hapticsEnabled) await HapticFeedback.heavyImpact();
  }

  Future<void> playLoss() async {
    await _play('loss.wav');
    if (hapticsEnabled) await HapticFeedback.vibrate();
  }

  Future<void> setEffectsEnabled(bool enabled) async {
    effectsEnabled = enabled;
    if (!enabled) await _effects.stop();
  }

  Future<void> setMusicEnabled(bool enabled) async {
    musicEnabled = enabled;
    if (!enabled) {
      await _music.pause();
      return;
    }
    await _music.setReleaseMode(ReleaseMode.loop);
    if (_musicStarted) {
      await _music.resume();
    } else {
      _musicStarted = true;
      await _music.play(AssetSource('audio/ambient.wav'), volume: 0.28);
    }
  }

  Future<void> setHapticsEnabled(bool enabled) async {
    hapticsEnabled = enabled;
  }

  Future<void> _play(String name) async {
    if (!effectsEnabled) return;
    await _effects.stop();
    await _effects.play(AssetSource('audio/$name'));
  }

  Future<void> dispose() async {
    await _effects.dispose();
    await _music.dispose();
  }
}
