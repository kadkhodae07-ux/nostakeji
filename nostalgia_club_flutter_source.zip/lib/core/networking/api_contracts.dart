abstract final class ApiRoutes {
  static const authGuest = '/v1/auth/guest';
  static const profile = '/v1/profile';
  static const friends = '/v1/friends';
  static const matchmaking = '/v1/matchmaking';
  static const rooms = '/v1/rooms';
  static const chat = '/v1/chat';
  static const leaderboard = '/v1/leaderboard';
  static const notifications = '/v1/notifications';
}

abstract final class SocketEvents {
  static const connection = 'connection';
  static const authentication = 'authentication';
  static const presenceUpdate = 'presence:update';
  static const roomCreate = 'room:create';
  static const roomJoin = 'room:join';
  static const roomLeave = 'room:leave';
  static const matchReady = 'match:ready';
  static const matchStart = 'match:start';
  static const matchMove = 'match:move';
  static const matchState = 'match:state';
  static const matchFinish = 'match:finish';
  static const matchRematch = 'match:rematch';
  static const chatSend = 'chat:send';
  static const chatMessage = 'chat:message';
  static const chatRead = 'chat:read';
  static const friendRequest = 'friend:request';
  static const friendAccepted = 'friend:accepted';
  static const notificationNew = 'notification:new';
}
