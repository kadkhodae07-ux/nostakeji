import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:nostalgia_club/features/authentication/presentation/guest_entry_screen.dart';
import 'package:nostalgia_club/features/chat/presentation/chat_list_screen.dart';
import 'package:nostalgia_club/features/chat/presentation/conversation_screen.dart';
import 'package:nostalgia_club/features/chess/presentation/chess_screen.dart';
import 'package:nostalgia_club/features/friends/presentation/friends_screen.dart';
import 'package:nostalgia_club/features/game_2048/presentation/game_2048_screen.dart';
import 'package:nostalgia_club/features/game_catalog/presentation/game_catalog_screen.dart';
import 'package:nostalgia_club/features/game_catalog/presentation/game_detail_screen.dart';
import 'package:nostalgia_club/features/game_catalog/presentation/player_setup_screen.dart';
import 'package:nostalgia_club/features/game_catalog/presentation/tutorial/game_rules_screen.dart';
import 'package:nostalgia_club/features/game_catalog/presentation/tutorial/game_tutorial_screen.dart';
import 'package:nostalgia_club/features/home/presentation/home_screen.dart';
import 'package:nostalgia_club/features/leaderboard/presentation/leaderboard_screen.dart';
import 'package:nostalgia_club/features/ludo/presentation/ludo_screen.dart';
import 'package:nostalgia_club/features/match_history/presentation/match_history_screen.dart';
import 'package:nostalgia_club/features/nine_mens_morris/presentation/nine_mens_morris_screen.dart';
import 'package:nostalgia_club/features/notifications/presentation/notifications_screen.dart';
import 'package:nostalgia_club/features/onboarding/presentation/onboarding_screen.dart';
import 'package:nostalgia_club/features/profile/presentation/profile_screen.dart';
import 'package:nostalgia_club/features/settings/presentation/settings_screen.dart';
import 'package:nostalgia_club/features/shell/presentation/main_shell.dart';
import 'package:nostalgia_club/features/snakes_and_ladders/presentation/snakes_ladders_screen.dart';
import 'package:nostalgia_club/features/splash/presentation/splash_screen.dart';
import 'package:nostalgia_club/features/tic_tac_toe/presentation/tic_tac_toe_screen.dart';
import 'package:nostalgia_club/shared/widgets/app_background.dart';
import 'package:nostalgia_club/shared/widgets/state_view.dart';

final _rootNavigatorKey = GlobalKey<NavigatorState>();

final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: '/',
    routes: [
      GoRoute(path: '/', builder: (context, state) => const SplashScreen()),
      GoRoute(path: '/onboarding', builder: (context, state) => const OnboardingScreen()),
      GoRoute(path: '/guest', builder: (context, state) => const GuestEntryScreen()),
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) => MainShell(navigationShell: navigationShell),
        branches: [
          StatefulShellBranch(routes: [GoRoute(path: '/home', builder: (context, state) => const HomeScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: '/games', builder: (context, state) => const GameCatalogScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: '/chat', builder: (context, state) => const ChatListScreen())]),
          StatefulShellBranch(routes: [GoRoute(path: '/profile', builder: (context, state) => const ProfileScreen())]),
        ],
      ),
      GoRoute(path: '/game-detail/:gameKey', builder: (context, state) => GameDetailScreen(gameKey: state.pathParameters['gameKey']!)),
      GoRoute(path: '/player-setup/:gameKey', builder: (context, state) => PlayerSetupScreen(gameKey: state.pathParameters['gameKey']!)),
      GoRoute(path: '/tutorial/:gameKey', builder: (context, state) => GameTutorialScreen(gameKey: state.pathParameters['gameKey']!)),
      GoRoute(path: '/rules/:gameKey', builder: (context, state) => GameRulesScreen(gameKey: state.pathParameters['gameKey']!)),
      GoRoute(path: '/game/chess', builder: (context, state) => const ChessScreen()),
      GoRoute(path: '/game/morris', builder: (context, state) => const NineMensMorrisScreen()),
      GoRoute(path: '/game/xox', builder: (context, state) => const TicTacToeScreen()),
      GoRoute(path: '/game/2048', builder: (context, state) => const Game2048Screen()),
      GoRoute(path: '/game/snakes', builder: (context, state) => const SnakesLaddersScreen()),
      GoRoute(path: '/game/ludo', builder: (context, state) => const LudoScreen()),
      GoRoute(path: '/conversation/:id', builder: (context, state) => ConversationScreen(conversationId: state.pathParameters['id']!)),
      GoRoute(path: '/friends', builder: (context, state) => const FriendsScreen()),
      GoRoute(path: '/leaderboard', builder: (context, state) => const LeaderboardScreen()),
      GoRoute(path: '/history', builder: (context, state) => const MatchHistoryScreen()),
      GoRoute(path: '/notifications', builder: (context, state) => const NotificationsScreen()),
      GoRoute(path: '/settings', builder: (context, state) => const SettingsScreen()),
    ],
    errorBuilder: (context, state) => AppBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: StateView(
              icon: 'warning',
              title: 'مسیر پیدا نشد',
              description: state.error?.toString() ?? 'این صفحه در مسیر‌یابی ثبت نشده است.',
              actionLabel: 'بازگشت به خانه',
              onAction: () => context.go('/home'),
            ),
          ),
        ),
      ),
    ),
  );
});
