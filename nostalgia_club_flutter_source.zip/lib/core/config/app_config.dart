class AppConfig {
  const AppConfig._();

  static const appNameFa = 'باشگاه نوستالژی';
  static const appNameEn = 'Nostalgia Club';
  static const packageName = 'com.example.nostalgia_club';
  static const studioName = 'Classic Forge Studio';
  static const version = '0.1.1+2';
  static const mockMode = bool.fromEnvironment('MOCK_MODE', defaultValue: true);
  static const appEnvironment = String.fromEnvironment('APP_ENV', defaultValue: 'development');
}
