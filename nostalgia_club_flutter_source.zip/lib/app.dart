import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nostalgia_club/core/design_system/app_theme.dart';
import 'package:nostalgia_club/core/routing/app_router.dart';
import 'package:nostalgia_club/features/settings/domain/settings_controller.dart';

class NostalgiaClubApp extends ConsumerWidget {
  const NostalgiaClubApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(appRouterProvider);
    final settings = ref.watch(settingsProvider);
    return MaterialApp.router(
      debugShowCheckedModeBanner: false,
      title: 'باشگاه نوستالژی',
      theme: settings.themeVariant == 'highContrast' ? AppTheme.highContrast : AppTheme.dark,
      locale: const Locale('fa'),
      supportedLocales: const [Locale('fa'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      routerConfig: router,
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: MediaQuery(
          data: MediaQuery.of(context).copyWith(
            disableAnimations: settings.reducedMotion || MediaQuery.of(context).disableAnimations,
            textScaler: MediaQuery.textScalerOf(context).clamp(
              minScaleFactor: 0.9,
              maxScaleFactor: 1.35,
            ),
          ),
          child: child ?? const SizedBox.shrink(),
        ),
      ),
    );
  }
}
