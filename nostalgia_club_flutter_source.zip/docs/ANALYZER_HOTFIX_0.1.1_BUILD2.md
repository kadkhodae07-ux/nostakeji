# Analyzer Hotfix — 0.1.1+2

این اصلاح بر اساس اجرای واقعی Flutter 3.27.4 و Dart 3.6.2 در GitHub Actions انجام شده است.

## خطاهای رفع‌شده

- جایگزینی پارامتر نامعتبر `Container.minWidth` با `BoxConstraints`.
- اضافه‌شدن حالت `loading` واقعی به `StateView` برای گفتگو و تاریخچه.
- حذف Import بلااستفاده صفحه منچ.
- اصلاح داده‌های Mock گفتگو که از index داخل یک Const List استفاده می‌کردند.
- تبدیل سازنده تست Drift به Super Parameter استاندارد.
- افزودن آکولاد به Flow Controlها برای رعایت Lint و کاهش خطای نگهداری.
- اصلاح String Interpolation غیرضروری.
- اصلاح موارد Const قابل تشخیص در UI، تست‌ها و Painterها.
- همگام‌سازی نسخه پروژه روی `0.1.1+2`.

## کنترل انجام‌شده در محیط تولید فایل

- بررسی Syntax تمام فایل‌های Dart با Parser.
- اجرای `tool/quality_check.py`.
- بررسی نبود Cache، Build، Keystore و فایل حساس در ZIP.

اجرای نهایی `flutter analyze` و `flutter test` باید توسط Workflow روی ZIP جدید انجام شود؛ این محیط Flutter SDK محلی ندارد.
