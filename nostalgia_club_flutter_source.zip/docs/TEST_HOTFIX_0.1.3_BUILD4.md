# Test Hotfix 0.1.3+4

## علت‌های ریشه‌ای

1. Getter مربوط به FEN از `$positionKey()` استفاده می‌کرد که در interpolation به tear-off متد تبدیل می‌شد. به `${positionKey()}` اصلاح شد.
2. SQLite/Drift پرچم UTC را هنگام بازیابی نگه نمی‌داشت. تمام DateTimeهای تاریخچه و پیام‌ها هنگام نوشتن و خواندن به UTC نرمال شدند.
3. صفحه Home روی عرض 360 چهار Overflow داشت: وضعیت آفلاین، هدر بخش بازی‌ها و متن‌های Hero. Layout با Expanded/Flexible، ellipsis، اندازه واکنش‌گرا و ارتفاع محتوایی بازطراحی شد.
4. تست RTL برای عرض‌های 320، 360 و 600 گسترش یافت تا Regression بازنگردد.
