# Design System

## هویت

هویت بصری بر پایه باشگاه بازی‌های کلاسیک مدرن طراحی شده است: چوب تیره، فلز، برنج، پارچه تیره، نور کنترل‌شده و عمق محدود.

## رنگ‌ها

- `voidBlack`: پس‌زمینه عمیق
- `charcoal`: سطح اصلی
- `raised` و `panel`: پنل‌های چندلایه
- `brass` و `brassBright`: Accent اصلی
- `parchment`: متن و سطوح روشن
- رنگ اختصاصی بازی‌ها: Chess، Morris، XOX، 2048، Snakes و Ludo

رنگ تنها نشانگر وضعیت نیست؛ متن، شکل، Border و Icon نیز وضعیت را منتقل می‌کنند.

## Radius و Spacing

Spacing بر مبنای 4/8/12/16/24/32/48 و Radius بر مبنای 10/16/24 تعریف شده است. ناحیه لمس عناصر تعاملی حداقل 44 تا 52 پیکسل است.

## تایپوگرافی

برای جلوگیری از همراه‌کردن فایل فونت دارای مجوز نامشخص، پروژه از فونت سیستم با وزن‌ها و Line Height کنترل‌شده استفاده می‌کند. فونت فارسی دارای مجوز را می‌توان در Theme جایگزین کرد.

## Iconography

- 59 فایل SVG اختصاصی
- ViewBox استاندارد 24×24
- Stroke و وزن بصری یکپارچه
- ColorFilter برای نسخه روشن و تیره
- عدم استفاده از Material Icons، Cupertino Icons، Font Awesome یا Emoji به‌عنوان آیکن UI

## Motion

- Quick: 140ms
- Standard: 240ms
- Deliberate: 420ms
- Curve اصلی: Ease-out cubic
- گزینه Reduced Motion در تنظیمات تعریف شده است.

## UI States

`StateView` برای Error، Empty، Offline، Locked و Retry آماده است. Mock Mode با Badge مستقل و قابل غیرفعال‌سازی در Release نمایش داده می‌شود.
