# قرارداد API و Socket آینده

## اصل امنیتی

سرور نسخه آنلاین باید Authoritative باشد. کلاینت تنها Intent حرکت را ارسال می‌کند. سرور Rule Engine معادل را اجرا، Sequence و State Hash را بررسی و Snapshot معتبر را منتشر می‌کند.

## REST پیشنهادی

- `POST /v1/auth/guest`
- `GET/PATCH /v1/profile`
- `GET/POST/DELETE /v1/friends`
- `POST /v1/matchmaking`
- `POST/GET /v1/rooms`
- `GET/POST /v1/chat`
- `GET /v1/leaderboard`
- `GET/PATCH /v1/notifications`

هیچ Base URL در نسخه فعلی تنظیم نشده است.

## Socket Events

- `connection`
- `authentication`
- `presence:update`
- `room:create`, `room:join`, `room:leave`
- `match:ready`, `match:start`, `match:move`, `match:state`, `match:finish`, `match:rematch`
- `chat:send`, `chat:message`, `chat:read`
- `friend:request`, `friend:accepted`
- `notification:new`

## Match Move Payload

```json
{
  "matchId": "uuid",
  "sequence": 18,
  "expectedStateHash": "sha256",
  "move": {
    "type": "game-specific",
    "payload": {}
  },
  "clientTimestamp": "ISO-8601"
}
```

## Match State Payload

```json
{
  "matchId": "uuid",
  "sequence": 19,
  "stateHash": "sha256",
  "snapshot": {},
  "serverTimestamp": "ISO-8601"
}
```
