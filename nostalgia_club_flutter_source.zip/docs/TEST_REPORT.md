# گزارش تست

## تست‌های موجود

- TicTacToe: برد، مساوی و Block توسط Minimax
- 2048: چهار Edge Case اصلی ادغام و عدم Spawn در حرکت نامعتبر
- Nine Men’s Morris: تشکیل Mill و محدودیت حذف مهره داخل Mill
- Snakes & Ladders: مختصات رفت‌وبرگشتی، Exact Finish و یک Transition
- Ludo: خروج با 6، Exact Finish و Start Offset
- Chess: 20 حرکت اولیه، En-passant target، Fool’s Mate، قلعه و En-passant
- Serialization و State Hash برای شش بازی
- Widget/RTL/Overflow smoke test
- Golden harness برای Home در 390×844

## آخرین اجرای CI و Hotfix

- GitHub Actions با Flutter 3.27.4 و Dart 3.6.2 اجرا شد و خطاهای Analyzer نسخه 0.1.0+1 را گزارش کرد.
- خطاهای گزارش‌شده در Hotfix `0.1.1+2` اصلاح شدند.
- `tool/quality_check.py` روی سورس اصلاح‌شده موفق است.
- Syntax تمام فایل‌های Dart با Parser بررسی شده است.
- نتیجه نهایی Analyzer، Test و APK باید با اجرای Workflow روی ZIP جدید تأیید شود.

تا قبل از اجرای CI روی ZIP جدید، موفقیت نهایی Analyzer یا APK ادعا نمی‌شود.
