# گزارش تست

## تست‌های موجود

- TicTacToe: برد، مساوی و Block توسط Minimax
- 2048: چهار Edge Case اصلی ادغام و عدم Spawn در حرکت نامعتبر
- Nine Men’s Morris: تشکیل Mill و محدودیت حذف مهره داخل Mill
- Snakes & Ladders: مختصات رفت‌وبرگشتی، Exact Finish و یک Transition
- Ludo: خروج با 6، Exact Finish و Start Offset
- Chess: 20 حرکت اولیه، En-passant target، Fool’s Mate، قلعه و En-passant
- Serialization و State Hash برای شش بازی
- Widget/RTL/Overflow smoke test
- Golden harness برای Home در 390×844

## اجرای محیط فعلی

- `tool/quality_check.py`: اجرا و نتیجه در Manifest نهایی ثبت می‌شود.
- Flutter Analyzer/Test: قابل اجرا نبود، چون Flutter SDK در محیط وجود نداشت.
- GitHub Workflow: این مراحل را اجباری و Fail-fast اجرا می‌کند.

هیچ ادعایی مبنی بر موفقیت Analyzer یا APK محلی بدون اجرای واقعی ثبت نشده است.
