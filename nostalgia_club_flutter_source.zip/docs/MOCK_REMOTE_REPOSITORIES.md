# Mock و Remote Repository

## Local

برای مسابقه آفلاین، State، Move History و Snapshot در دستگاه نگهداری می‌شوند. Drift برای ذخیره دائمی آماده است.

## Mock

داده‌های کاربران، گفتگوها، پیام‌ها، اعلان‌ها و رتبه‌بندی در `shared/mock` متمرکز شده‌اند. هیچ داده‌ای داخل Widgetهای متعدد پراکنده نشده است.

## Remote

Remote Repository قرارداد کامل دارد، اما در نسخه آفلاین `UnsupportedError` می‌دهد. جایگزینی Mock با Remote باید فقط از Provider/DI انجام شود و Presentation تغییر نکند.

## Mock Mode

`--dart-define=MOCK_MODE=true` Badge توسعه را فعال می‌کند. Workflow Release آن را False قرار می‌دهد.
