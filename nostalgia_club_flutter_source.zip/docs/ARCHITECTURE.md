# معماری پروژه

## اصول

پروژه از Feature-first Clean Architecture استفاده می‌کند. مرز اصلی وابستگی به شکل زیر است:

```text
Presentation -> Use Case / Controller -> Domain Engine -> Repository Interface
                                              ^
Data Local / Mock / Remote Implementation ----|
```

هیچ Widget اجازه تغییر مستقیم Board State را ندارد. Widget فقط `GameMove` ایجاد می‌کند؛ Engine آن را با `isLegal` یا `legalMoves` اعتبارسنجی و سپس State جدید را بازمی‌گرداند.

## Game Core مشترک

`core/game` مسئول مفاهیم مشترک است:

- Match Lifecycle
- Player و Opponent Type
- Game Session
- Snapshot و History
- State Hash
- Undo
- Random Seed
- Bot Interface

قوانین تخصصی در Game Core ادغام نشده‌اند تا اشتراک مصنوعی و Coupling ایجاد نشود.

## وضعیت قابل Serialization

تمام Stateهای بازی `SerializableGameState` را پیاده‌سازی می‌کنند. این تصمیم موارد زیر را ممکن می‌سازد:

- ذخیره خودکار
- Restore
- Replay
- Regression Test
- State Hash
- انتقال State Snapshot در نسخه آنلاین

## State Management

Riverpod برای State عمومی، تنظیمات و Dependency Injection استفاده می‌شود. Stateهای حساس و پرتکرار تخته داخل Engineهای مستقل نگهداری و توسط Controller/Screen مدیریت می‌شوند. در توسعه بعدی می‌توان هر Engine را پشت `Notifier` یا `AsyncNotifier` قرار داد بدون تغییر Domain.

## Routing

GoRouter با `StatefulShellRoute.indexedStack` برای چهار بخش خانه، بازی‌ها، چت و پروفایل استفاده شده است. صفحات بازی خارج از Shell باز می‌شوند تا فضای کامل نمایشگر در اختیار تخته باشد.

## Persistence

Drift جداول زیر را تعریف می‌کند:

- SettingsRows
- SavedMatches
- MatchHistoryRows
- MockMessages

MigrationStrategy غیرتخریبی است و نسخه‌های بعدی باید Migration صریح اضافه کنند.

## Networking

`LocalMatchRepository` و `MockMatchRepository` فعال‌اند. `RemoteMatchRepository` عمداً درخواست شبکه انجام نمی‌دهد و با `UnsupportedError` متوقف می‌شود. این رفتار از اتصال تصادفی به Endpoint جعلی جلوگیری می‌کند.

## Performance

- تخته‌های سنگین با CustomPainter رندر می‌شوند.
- محاسبات ربات از UI جدا هستند و Interface آن Future-based است.
- Assetهای SVG و WAV محلی‌اند.
- انیمیشن‌ها کوتاه و State-driven هستند.
- برای توسعه موتور شطرنج با عمق بیشتر، اجرای جست‌وجو در Isolate توصیه شده است.
