# وضعیت قابلیت‌ها

## پیاده‌سازی‌شده

- شش موتور بازی و صفحه قابل‌بازی
- Bot Interface و ربات‌های محلی
- Design System و 59 آیکن SVG
- شش فایل صوتی WAV شامل پنج افکت و یک موسیقی محیطی
- RTL و Layout واکنش‌گرا
- Splash، Onboarding، Guest Login، Home، Catalog و Player Setup
- Profile، Friends، Chat، Notifications، Leaderboard، History و Settings
- Tutorial و Rules هر بازی
- Drift schema و Migration Strategy
- Local/Mock/Remote repository contract
- API و Socket contract
- Unit، Serialization، Widget، RTL و Golden harness
- GitHub Actions برای Bootstrap، Codegen، Analyze، Test و APK

## Mock

- احراز هویت آنلاین
- پروفایل آنلاین
- دوستان و Presence
- Chat آنلاین
- اعلان و رتبه‌بندی
- Matchmaking و اتاق خصوصی

## آماده اتصال

- Match Repository
- API Route constants
- Socket Event constants
- Serializable State، Snapshot و State Hash
- Mock Mode switch

## محدودیت تحویل این محیط

Flutter SDK در محیط تولید فایل نصب نبود؛ بنابراین `flutter analyze`، `flutter test` و APK محلی اجرا نشدند. Workflow این مراحل را روی Flutter Stable اجرا می‌کند و در صورت خطا متوقف می‌شود. Structural Quality Check در محیط فعلی اجرا شده است.
