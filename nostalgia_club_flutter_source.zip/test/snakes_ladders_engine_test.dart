import 'package:flutter_test/flutter_test.dart';
import 'package:nostalgia_club/features/snakes_and_ladders/domain/snakes_ladders_engine.dart';

void main() {
  group('SnakesLaddersEngine', () {
    test('uses boustrophedon coordinates', () {
      expect(SnakesLaddersEngine.columnForCell(1), 0);
      expect(SnakesLaddersEngine.columnForCell(10), 9);
      expect(SnakesLaddersEngine.columnForCell(11), 9);
      expect(SnakesLaddersEngine.columnForCell(20), 0);
    });

    test('exact finish blocks overshoot', () {
      final state = SnakesLaddersState(positions: const [99, 0], currentPlayer: 0, rankings: const [], seed: 3, status: RaceStatus.playing);
      final engine = SnakesLaddersEngine(initial: state);
      engine.apply(const SnakesLaddersMove.roll());
      expect(engine.state.lastRoll, 5);
      expect(engine.state.positions[0], 99);
    });

    test('applies only one configured transition', () {
      final state = SnakesLaddersState(positions: const [0, 0], currentPlayer: 0, rankings: const [], seed: 1, status: RaceStatus.playing);
      final engine = SnakesLaddersEngine(initial: state, config: const SnakesLaddersConfig(transitions: {1: 5, 5: 99}));
      engine.apply(const SnakesLaddersMove.roll());
      expect(engine.state.positions[0], 5);
    });
  });
}
