import 'package:flutter_test/flutter_test.dart';
import 'package:nostalgia_club/features/game_2048/domain/game_2048_engine.dart';

void main() {
  group('2048 merge rules', () {
    test('2 2 2 2 -> 4 4', () => expect(Game2048Engine.mergeRowForTest([2, 2, 2, 2]), [4, 4, 0, 0]));
    test('2 2 4 4 -> 4 8', () => expect(Game2048Engine.mergeRowForTest([2, 2, 4, 4]), [4, 8, 0, 0]));
    test('4 4 4 0 -> 8 4', () => expect(Game2048Engine.mergeRowForTest([4, 4, 4, 0]), [8, 4, 0, 0]));
    test('2 2 2 0 -> 4 2', () => expect(Game2048Engine.mergeRowForTest([2, 2, 2, 0]), [4, 2, 0, 0]));
    test('does not spawn after invalid movement', () {
      const state = Game2048State(cells: const [2, 4, 8, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], score: 0, bestScore: 0, seed: 1, status: Game2048Status.playing, undoRemaining: 3);
      final engine = Game2048Engine.fromState(state);
      engine.apply(const Game2048Move(SwipeDirection.left));
      expect(engine.state.cells, state.cells);
      expect(engine.state.seed, state.seed);
    });
  });
}
