import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:nostalgia_club/features/chess/domain/chess_engine.dart';
import 'package:nostalgia_club/features/game_2048/domain/game_2048_engine.dart';
import 'package:nostalgia_club/features/ludo/domain/ludo_engine.dart';
import 'package:nostalgia_club/features/nine_mens_morris/domain/nine_mens_morris_engine.dart';
import 'package:nostalgia_club/features/snakes_and_ladders/domain/snakes_ladders_engine.dart';
import 'package:nostalgia_club/features/tic_tac_toe/domain/tic_tac_toe_engine.dart';

void main() {
  test('all game states survive JSON serialization', () {
    final states = [
      ChessState.initial(),
      Game2048Engine(seed: 1).state,
      LudoState.initial(players: 4),
      MorrisState.initial(),
      SnakesLaddersState.initial(players: 4),
      TicTacToeState.initial(),
    ];
    for (final state in states) {
      expect(jsonDecode(state.serialize()), isA<Map<String, dynamic>>());
      expect(state.stateHash(), hasLength(64));
    }
  });
}
