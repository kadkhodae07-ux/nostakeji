import 'package:flutter_test/flutter_test.dart';
import 'package:nostalgia_club/core/game/game_models.dart';
import 'package:nostalgia_club/features/tic_tac_toe/domain/tic_tac_toe_engine.dart';

void main() {
  group('TicTacToeEngine', () {
    test('detects a horizontal win', () {
      final engine = TicTacToeEngine();
      for (final index in [0, 3, 1, 4, 2]) {
        engine.apply(TicMove(index));
      }
      expect(engine.state.status, TicStatus.won);
      expect(engine.state.winner, TicMark.x);
      expect(engine.state.winningLine, [0, 1, 2]);
    });

    test('detects a draw', () {
      final engine = TicTacToeEngine();
      for (final index in [0, 1, 2, 4, 3, 5, 7, 6, 8]) {
        engine.apply(TicMove(index));
      }
      expect(engine.state.status, TicStatus.draw);
    });

    test('hard bot blocks immediate loss', () async {
      final state = TicTacToeState(
        board: const [TicMark.x, TicMark.x, null, null, TicMark.o, null, null, null, null],
        turn: TicMark.o,
        status: TicStatus.playing,
      );
      final move = await const TicTacToeBot().chooseMove(state, BotDifficulty.hard);
      expect(move.index, 2);
    });
  });
}
