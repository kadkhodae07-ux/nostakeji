import 'package:flutter_test/flutter_test.dart';
import 'package:nostalgia_club/features/chess/domain/chess_engine.dart';

void main() {
  group('ChessEngine', () {
    test('initial position has 20 legal moves', () {
      expect(ChessEngine().legalMoves().length, 20);
    });

    test('e2-e4 sets en-passant target e3', () {
      final engine = ChessEngine();
      engine.apply(ChessMove(from: ChessEngine.squareFromName('e2'), to: ChessEngine.squareFromName('e4')));
      expect(engine.state.enPassantTarget, ChessEngine.squareFromName('e3'));
      expect(engine.state.fen, contains(' e3 '));
    });

    test('detects Fool’s Mate', () {
      final engine = ChessEngine();
      void move(String from, String to) => engine.apply(ChessMove(from: ChessEngine.squareFromName(from), to: ChessEngine.squareFromName(to)));
      move('f2', 'f3');
      move('e7', 'e5');
      move('g2', 'g4');
      move('d8', 'h4');
      expect(engine.state.result, ChessResult.blackWin);
      expect(engine.state.resultReason, 'checkmate');
    });

    test('allows legal king-side castling', () {
      final engine = ChessEngine(ChessEngine.fromFen('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1'));
      final moves = engine.legalMovesFrom(ChessEngine.squareFromName('e1'));
      expect(moves.any((move) => move.isCastle && ChessEngine.squareName(move.to) == 'g1'), isTrue);
      expect(moves.any((move) => move.isCastle && ChessEngine.squareName(move.to) == 'c1'), isTrue);
    });

    test('supports en-passant capture', () {
      final engine = ChessEngine(ChessEngine.fromFen('4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1'));
      final moves = engine.legalMovesFrom(ChessEngine.squareFromName('e5'));
      expect(moves.any((move) => move.isEnPassant && ChessEngine.squareName(move.to) == 'd6'), isTrue);
    });
  });
}
