import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:nostalgia_club/core/storage/app_database.dart';

void main() {
  late AppDatabase database;

  setUp(() {
    database = AppDatabase.forTesting(NativeDatabase.memory());
  });

  tearDown(() => database.close());

  test('persists settings and game snapshots', () async {
    await database.writeSetting('sound', 'false');
    expect(await database.readSetting('sound'), 'false');

    await database.saveGameSnapshot(
      gameKeyValue: '2048',
      serializedStateValue: '{"score":42}',
      stateHashValue: 'hash',
    );
    expect(await database.readGameSnapshot('2048'), '{"score":42}');

    await database.deleteGameSnapshot('2048');
    expect(await database.readGameSnapshot('2048'), isNull);
  });

  test('persists and clears match history', () async {
    final finishedAt = DateTime.utc(2026, 7, 17, 12);
    await database.saveHistoryEntry(
      idValue: 'chess:one',
      gameKeyValue: 'chess',
      payloadValue: '{"result":"برد"}',
      finishedAtValue: finishedAt,
    );

    final entries = await database.readHistoryEntries();
    expect(entries, hasLength(1));
    expect(entries.single.gameKey, 'chess');
    expect(entries.single.finishedAt, finishedAt);

    await database.clearLocalData();
    expect(await database.readHistoryEntries(), isEmpty);
    expect(await database.readSetting('sound'), isNull);
  });

  test('persists, updates and deletes mock chat messages', () async {
    final createdAt = DateTime.utc(2026, 7, 17, 13);
    await database.saveMockMessage(
      idValue: 'chat:1',
      conversationIdValue: 'conversation-1',
      payloadValue: '{"text":"سلام"}',
      createdAtValue: createdAt,
    );

    var messages = await database.readMockMessages('conversation-1');
    expect(messages, hasLength(1));
    expect(messages.single.payload, contains('سلام'));

    await database.saveMockMessage(
      idValue: 'chat:1',
      conversationIdValue: 'conversation-1',
      payloadValue: '{"text":"ویرایش"}',
      createdAtValue: createdAt,
    );
    messages = await database.readMockMessages('conversation-1');
    expect(messages.single.payload, contains('ویرایش'));

    await database.deleteMockMessage('chat:1');
    expect(await database.readMockMessages('conversation-1'), isEmpty);
  });

}
