import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:nostalgia_club/features/home/presentation/home_screen.dart';

const runGoldens = bool.fromEnvironment('RUN_GOLDENS');

void main() {
  testWidgets('home visual baseline', (tester) async {
    await tester.binding.setSurfaceSize(const Size(390, 844));
    await tester.pumpWidget(const MaterialApp(home: Directionality(textDirection: TextDirection.rtl, child: Scaffold(body: HomeScreen()))));
    await tester.pumpAndSettle();
    await expectLater(find.byType(HomeScreen), matchesGoldenFile('baselines/home_390x844.png'));
    await tester.binding.setSurfaceSize(null);
  }, skip: !runGoldens);
}
