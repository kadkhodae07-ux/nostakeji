import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:nostalgia_club/features/home/presentation/home_screen.dart';

void main() {
  testWidgets('home screen renders in RTL without overflow', (tester) async {
    addTearDown(() => tester.binding.setSurfaceSize(null));

    for (final size in const <Size>[
      Size(320, 700),
      Size(360, 800),
      Size(600, 900),
    ]) {
      await tester.binding.setSurfaceSize(size);
      await tester.pumpWidget(
        const MaterialApp(
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Scaffold(body: HomeScreen()),
          ),
        ),
      );
      await tester.pump();
      expect(
        tester.takeException(),
        isNull,
        reason: 'HomeScreen overflowed at ${size.width}×${size.height}',
      );
      expect(find.text('بازی‌های باشگاه'), findsOneWidget);
    }
  });
}
