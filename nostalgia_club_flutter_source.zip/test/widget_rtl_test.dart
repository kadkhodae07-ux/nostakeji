import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:nostalgia_club/features/home/presentation/home_screen.dart';

void main() {
  testWidgets('home screen renders in RTL without overflow', (tester) async {
    await tester.binding.setSurfaceSize(const Size(360, 800));
    await tester.pumpWidget(const MaterialApp(home: Directionality(textDirection: TextDirection.rtl, child: Scaffold(body: HomeScreen()))));
    await tester.pump();
    expect(tester.takeException(), isNull);
    expect(find.text('بازی‌های باشگاه'), findsOneWidget);
    await tester.binding.setSurfaceSize(null);
  });
}
