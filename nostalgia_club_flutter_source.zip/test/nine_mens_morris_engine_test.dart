import 'package:flutter_test/flutter_test.dart';
import 'package:nostalgia_club/features/nine_mens_morris/domain/nine_mens_morris_engine.dart';

void main() {
  group('NineMensMorrisEngine', () {
    test('forming a mill requires a removal', () {
      final engine = NineMensMorrisEngine();
      engine.apply(const MorrisMove(action: MorrisAction.place, to: 0));
      engine.apply(const MorrisMove(action: MorrisAction.place, to: 3));
      engine.apply(const MorrisMove(action: MorrisAction.place, to: 1));
      engine.apply(const MorrisMove(action: MorrisAction.place, to: 4));
      engine.apply(const MorrisMove(action: MorrisAction.place, to: 2));
      expect(engine.state.pendingRemoval, isTrue);
      expect(engine.state.activePlayer, 0);
      expect(engine.legalMoves().every((move) => move.action == MorrisAction.remove), isTrue);
    });

    test('piece in mill cannot be removed while an outside piece exists', () {
      final board = List<int?>.filled(24, null)
        ..[0] = 1
        ..[1] = 1
        ..[2] = 1
        ..[3] = 1
        ..[9] = 0;
      final state = MorrisState(board: board, toPlace: const [0, 0], activePlayer: 0, pendingRemoval: true, noCapturePly: 0, positionCounts: const {});
      final engine = NineMensMorrisEngine(state);
      final targets = engine.legalMoves().map((move) => move.to).toList();
      expect(targets, [3]);
    });
  });
}
