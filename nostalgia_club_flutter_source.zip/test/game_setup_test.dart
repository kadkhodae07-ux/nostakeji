import 'package:flutter_test/flutter_test.dart';
import 'package:nostalgia_club/core/game/game_models.dart';
import 'package:nostalgia_club/features/game_catalog/domain/game_setup.dart';

void main() {
  test('default setup matches each game category', () {
    expect(GameSetupConfig.defaultsFor('2048').playerCount, 1);
    expect(GameSetupConfig.defaultsFor('chess').playerCount, 2);
    expect(GameSetupConfig.defaultsFor('ludo').playerCount, 4);
    expect(GameSetupConfig.defaultsFor('snakes').withBot, isTrue);
  });

  test('setup controller stores selected players and difficulty', () {
    final controller = GameSetupController();
    const config = GameSetupConfig(
      playerCount: 3,
      withBot: true,
      difficulty: BotDifficulty.hard,
      playerNames: ['محمد', 'ربات ۱', 'ربات ۲'],
    );
    controller.save('ludo', config);
    expect(controller.read('ludo').playerCount, 3);
    expect(controller.read('ludo').difficulty, BotDifficulty.hard);
  });
}
