import 'package:flutter_test/flutter_test.dart';
import 'package:nostalgia_club/features/ludo/domain/ludo_engine.dart';

void main() {
  group('LudoEngine', () {
    test('base token exits only on six in classic profile', () {
      final engine = LudoEngine(initial: LudoState.initial(players: 2, seed: 4));
      engine.apply(const LudoMove.roll());
      expect(engine.state.dice, 6);
      expect(engine.legalMoves().length, 4);
      engine.apply(const LudoMove.token(0));
      expect(engine.state.tokens.first.steps, 0);
    });

    test('cannot overshoot exact finish', () {
      final initial = LudoState.initial(players: 2, seed: 5);
      final tokens = List<LudoToken>.from(initial.tokens);
      tokens[0] = tokens[0].copyWith(steps: 57);
      final state = initial.copyWith(tokens: tokens, status: LudoStatus.waitingForToken, dice: 3);
      final engine = LudoEngine(initial: state);
      expect(engine.legalMoves().where((move) => move.tokenIndex == 0), isEmpty);
    });

    test('global paths are offset per player', () {
      expect(LudoEngine.globalTrackPosition(0, 0), 0);
      expect(LudoEngine.globalTrackPosition(1, 0), 13);
      expect(LudoEngine.globalTrackPosition(3, 20), 7);
    });
  });
}
